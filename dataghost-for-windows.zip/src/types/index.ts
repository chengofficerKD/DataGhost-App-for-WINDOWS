export type DomainCategory =
  | 'Primary'
  | 'Auth'
  | 'Tracking'
  | 'API'
  | 'Service'
  | 'Analytics'
  | 'Essential'
  | 'Unknown';

export interface LegitimacyResult {
  domain: string;
  hostname: string;
  isLegit: boolean;
  isThreat: boolean;
  threatType: string | null;
  threatReason: string;
  category: string;
  registrationYear: number | null;
  registrationDate?: string;
  ageDays?: number;
  checks: {
    dns: 'clean' | 'blocked' | 'unknown';
    rdap: 'registered' | 'checked' | 'unknown' | 'error';
    transport: 'secure' | 'unencrypted';
  };
  verifiedSources: string[];
  protocol: 'https:' | 'http:';
  riskScore: number; // 0 (safest) to 100 (high threat)
  hasLoginForm?: boolean;
  isFormTargetCrossOrigin?: boolean;
  primaryFormTarget?: string | null;
}

export interface GraphNode {
  id: string;
  host: string;
  category: DomainCategory;
  count: number;
  isSecure: boolean;
  isPrimary: boolean;
  x: number;
  y: number;
  radius: number;
  color: string;
  isBlocked?: boolean;
}

export interface GraphConnection {
  key: string;
  from: string;
  to: string;
  category: DomainCategory;
  count: number;
  isSecure: boolean;
  color?: string;
  isBlocked?: boolean;
}

export interface DataPulse {
  fromX: number;
  fromY: number;
  toX: number;
  toY: number;
  progress: number;
  speed: number;
  color: string;
}

export interface PostRequest {
  id: string;
  timestamp: number;
  url: string;
  host: string;
  path: string;
  method: 'POST' | 'PUT' | 'GET';
  isSecure: boolean;
  category: DomainCategory;
  payloadType?: string;
  riskAlert?: string | null;
  isBlocked?: boolean;
}

export interface BreachRecord {
  name: string;
  title: string;
  domain: string;
  breachDate: string;
  dataClasses?: string[];
  description?: string;
  pwnCount?: number;
  isVerified?: boolean;
}

export interface VaultSite {
  domain: string;
  status: 'safe' | 'breached' | 'scheduled' | 'unknown' | 'checking';
  lastChecked: number | null;
  nextCheckAt: number | null;
  breaches: BreachRecord[];
  autoDetected: boolean;
  lastDetectedAt?: number;
  notifiedBreach?: boolean;
  checkError?: string | null;
  accountUsername?: string;
}

export interface WindowsToast {
  id: string;
  title: string;
  message: string;
  type: 'threat' | 'breach' | 'info' | 'success';
  timestamp: number;
  domain?: string;
}

export interface TrafficPreset {
  id: string;
  name: string;
  description: string;
  primaryDomain: string;
  protocol: 'https:' | 'http:';
  nodes: { host: string; category: DomainCategory; count: number; isSecure: boolean; isBlocked?: boolean }[];
  connections: { from: string; to: string; category: DomainCategory }[];
  posts: { path: string; host: string; isSecure: boolean; category: DomainCategory; payloadType: string }[];
  hasLogin?: boolean;
  loginTarget?: string;
}

export interface TrackerShieldSettings {
  enabled: boolean;
  mode: 'balanced' | 'strict';
  blockedDomains: string[];
  whitelistedDomains: string[];
  totalBlockedCount: number;
  dataSavedBytes: number;
}

// ── 1. Scammer Contact Detector ──
export type ScamThreatLevel = 'critical' | 'suspicious' | 'low' | 'clean';
export type ScamCategory =
  | 'tech_support_fraud'
  | 'bank_impersonation'
  | 'crypto_pig_butchering'
  | 'phishing_sms'
  | 'advance_fee'
  | 'telemarketing_voip'
  | 'unknown';

export interface ScamContactRecord {
  id: string;
  target: string; // phone number, email, or handle
  type: 'phone' | 'email' | 'crypto_address' | 'text_message';
  threatLevel: ScamThreatLevel;
  riskScore: number; // 0 to 100
  scamCategory: ScamCategory;
  carrierOrDomain?: string;
  isVoip?: boolean;
  reportsCount: number;
  lastReported?: string;
  notes: string;
  redFlags: string[];
}

export interface ScamAnalysisResult {
  target: string;
  type: 'phone' | 'email' | 'crypto_address' | 'text_message';
  threatLevel: ScamThreatLevel;
  riskScore: number;
  category: ScamCategory;
  summary: string;
  redFlags: string[];
  carrierDetails?: string;
  recommendations: string[];
  sampleTranscripts?: string[];
}

// ── 2. Data Trace Shredder & Deletion Assistant ──
export interface DataTraceItem {
  id: string;
  domain: string;
  dataTypesExposed: ('Passwords' | 'Email' | 'Payment Card' | 'Phone' | 'Full Name' | 'IP Address' | 'Cookies')[];
  exposureDate: string;
  isHttpUnencrypted: boolean;
  erasureStatus: 'not_requested' | 'request_sent' | 'erased' | 'declined';
  lastRequestDate?: string;
  notes?: string;
}

export interface ErasureRequestTemplate {
  legalBasis: 'GDPR_ART_17' | 'CCPA_SEC_1798' | 'GENERIC_ABUSE';
  subject: string;
  recipientEmail: string;
  body: string;
}

// ── 3. Malware & Spyware Inspector ──
export type MalwareSeverity = 'critical' | 'high' | 'medium' | 'clean';
export type ThreatType =
  | 'trojan_backdoor'
  | 'keylogger_spyware'
  | 'crypto_miner'
  | 'dns_hijacker'
  | 'startup_persistence'
  | 'browser_redirector'
  | 'open_listening_port';

export interface MalwareThreat {
  id: string;
  name: string;
  type: ThreatType;
  severity: MalwareSeverity;
  location: string;
  description: string;
  status: 'active' | 'quarantined' | 'removed';
  processPid?: number;
  hashSha256?: string;
  recommendation: string;
}

export interface MalwareScanState {
  isScanning: boolean;
  scanProgress: number; // 0 to 100
  currentScanPath: string;
  scanPhase: 'memory' | 'registry' | 'tasks' | 'ports' | 'extensions' | 'completed';
  threatsFound: MalwareThreat[];
  lastScanTimestamp: number | null;
  itemsScanned: number;
  systemStatus: 'healthy' | 'at_risk' | 'infected';
}

// ── 4. Privacy & Hardware Eavesdropping Monitor ──
export interface HardwarePrivacyStatus {
  cameraLocked: boolean;
  micLocked: boolean;
  locationLocked: boolean;
  activeAppUsingMic?: string | null;
  activeAppUsingCam?: string | null;
  recentAppPermissions: {
    app: string;
    type: 'camera' | 'microphone' | 'location';
    timestamp: number;
    blocked: boolean;
  }[];
}


