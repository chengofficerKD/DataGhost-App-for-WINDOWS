import React, { useState, useEffect } from 'react';
import { WindowsTitleBar } from './components/WindowsTitleBar';
import { WindowsSidebar, NavTab } from './components/WindowsSidebar';
import { WindowsActionCenterToast } from './components/WindowsActionCenterToast';
import { DashboardView } from './components/DashboardView';
import { InformantView } from './components/InformantView';
import { DataDetectiveGraphView } from './components/DataDetectiveGraphView';
import { TrackerBlockerView } from './components/TrackerBlockerView';
import { ScamDetectorView } from './components/ScamDetectorView';
import { DataTraceShredderView } from './components/DataTraceShredderView';
import { MalwareInspectorView } from './components/MalwareInspectorView';
import { PrivacyShieldView } from './components/PrivacyShieldView';
import { BreachVaultView } from './components/BreachVaultView';
import { TrafficInspectorView } from './components/TrafficInspectorView';
import { SecurityGuideView } from './components/SecurityGuideView';
import { CompactWidgetView } from './components/CompactWidgetView';
import {
  LegitimacyResult,
  TrafficPreset,
  VaultSite,
  WindowsToast,
  TrackerShieldSettings,
  ScamContactRecord,
  DataTraceItem,
  MalwareScanState,
  HardwarePrivacyStatus
} from './types';
import { verifyWebsiteLegitimacy } from './services/legitimacyEngine';
import {
  checkAllVaultSites,
  findSiteBreaches,
  getStoredVaultSites,
  saveStoredVaultSites,
  verifyVaultDomainDns,
  fetchBreachCatalog
} from './services/vaultService';
import {
  getStoredTrackerSettings,
  saveStoredTrackerSettings,
  isDomainBlocked
} from './services/trackerBlockerService';
import {
  getStoredScamContacts,
  saveStoredScamContacts
} from './services/scamDetectorService';
import {
  getStoredDataTraces,
  saveStoredDataTraces
} from './services/traceEraserService';
import {
  getStoredMalwareState,
  saveStoredMalwareState
} from './services/malwareScannerService';
import {
  getStoredPrivacyStatus,
  saveStoredPrivacyStatus
} from './services/privacyShieldService';
import { TRAFFIC_PRESETS, buildRecentAuditList } from './services/trafficSimulator';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTab>('dashboard');
  const [isWidgetMode, setIsWidgetMode] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [isMaximized, setIsMaximized] = useState(false);

  // Core Data State
  const [vaultSites, setVaultSites] = useState<VaultSite[]>(getStoredVaultSites());
  const [trackerSettings, setTrackerSettings] = useState<TrackerShieldSettings>(getStoredTrackerSettings());
  const [scamContacts, setScamContacts] = useState<ScamContactRecord[]>(getStoredScamContacts());
  const [dataTraces, setDataTraces] = useState<DataTraceItem[]>(getStoredDataTraces());
  const [malwareState, setMalwareState] = useState<MalwareScanState>(getStoredMalwareState());
  const [privacyStatus, setPrivacyStatus] = useState<HardwarePrivacyStatus>(getStoredPrivacyStatus());
  const [activePreset, setActivePreset] = useState<TrafficPreset>(TRAFFIC_PRESETS[0]);
  const [currentLegitimacy, setCurrentLegitimacy] = useState<LegitimacyResult | null>(null);
  const [isLoadingLegitimacy, setIsLoadingLegitimacy] = useState(false);
  const [recentAudits, setRecentAudits] = useState(buildRecentAuditList());
  const [toasts, setToasts] = useState<WindowsToast[]>([]);
  const [isCheckingVault, setIsCheckingVault] = useState(false);

  // Sync theme
  useEffect(() => {
    const root = document.documentElement;
    if (isDarkMode) {
      root.classList.add('dark');
      root.classList.remove('light');
    } else {
      root.classList.add('light');
      root.classList.remove('dark');
    }
  }, [isDarkMode]);

  // Initial audit of default preset
  useEffect(() => {
    handleAuditDomain(activePreset.primaryDomain);
  }, []);

  const triggerToast = (toast: Omit<WindowsToast, 'id' | 'timestamp'>) => {
    const newToast: WindowsToast = {
      ...toast,
      id: `toast_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      timestamp: Date.now()
    };
    setToasts((prev) => [...prev, newToast]);

    // Auto dismiss after 6 seconds
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== newToast.id));
    }, 6000);
  };

  const handleAuditDomain = async (inputDomain: string) => {
    setIsLoadingLegitimacy(true);
    try {
      const result = await verifyWebsiteLegitimacy(inputDomain);
      setCurrentLegitimacy(result);

      // Add to recent audits
      setRecentAudits((prev) => [
        {
          domain: result.domain,
          timestamp: Date.now(),
          isThreat: result.isThreat,
          category: result.category
        },
        ...prev.filter((item) => item.domain !== result.domain).slice(0, 7)
      ]);

      // If threat found, send Windows notification toast
      if (result.isThreat) {
        triggerToast({
          type: 'threat',
          title: `Untrusted Domain Detected: ${result.domain}`,
          message: result.threatReason || 'High-risk security threat reported by security filters.',
          domain: result.domain
        });
      }
    } finally {
      setIsLoadingLegitimacy(false);
    }
  };

  // Tracker Blocker Handlers
  const handleUpdateTrackerSettings = (newSettings: TrackerShieldSettings) => {
    setTrackerSettings(newSettings);
    saveStoredTrackerSettings(newSettings);
  };

  const handleToggleBlockDomain = (domain: string) => {
    const cleanDomain = domain.toLowerCase().trim();
    const isCurrentlyBlocked = isDomainBlocked(cleanDomain, 'Tracking', trackerSettings);

    if (isCurrentlyBlocked) {
      // Unblock: remove from blockedDomains, add to whitelistedDomains
      const updated: TrackerShieldSettings = {
        ...trackerSettings,
        blockedDomains: trackerSettings.blockedDomains.filter((d) => d !== cleanDomain),
        whitelistedDomains: [...new Set([cleanDomain, ...trackerSettings.whitelistedDomains])]
      };
      setTrackerSettings(updated);
      saveStoredTrackerSettings(updated);

      triggerToast({
        type: 'info',
        title: `Tracker Allowed: ${cleanDomain}`,
        message: `Traffic to ${cleanDomain} is now allowed through the firewall.`,
        domain: cleanDomain
      });
    } else {
      // Block: add to blockedDomains, remove from whitelistedDomains, increment stats
      const updated: TrackerShieldSettings = {
        ...trackerSettings,
        blockedDomains: [...new Set([cleanDomain, ...trackerSettings.blockedDomains])],
        whitelistedDomains: trackerSettings.whitelistedDomains.filter((d) => d !== cleanDomain),
        totalBlockedCount: trackerSettings.totalBlockedCount + 1,
        dataSavedBytes: trackerSettings.dataSavedBytes + 35 * 1024
      };
      setTrackerSettings(updated);
      saveStoredTrackerSettings(updated);

      triggerToast({
        type: 'success',
        title: `Tracker Intercepted: ${cleanDomain}`,
        message: `Outbound beacons and tracking scripts to ${cleanDomain} are now severed.`,
        domain: cleanDomain
      });
    }
  };

  const handleToggleTrackerShield = () => {
    const updated: TrackerShieldSettings = {
      ...trackerSettings,
      enabled: !trackerSettings.enabled
    };
    setTrackerSettings(updated);
    saveStoredTrackerSettings(updated);

    triggerToast({
      type: updated.enabled ? 'success' : 'info',
      title: updated.enabled ? 'Tracker Shield Activated' : 'Tracker Shield Paused',
      message: updated.enabled
        ? 'Real-time privacy firewall is actively blocking tracking networks.'
        : 'Tracker blocking paused temporarily.'
    });
  };

  // Vault Handlers
  const handleAddSiteToVault = async (domain: string): Promise<{ success: boolean; message: string }> => {
    const verification = await verifyVaultDomainDns(domain);
    if (!verification.valid || !verification.domain) {
      return { success: false, message: verification.error || 'Domain verification failed.' };
    }

    const cleanDomain = verification.domain;
    if (vaultSites.some((s) => s.domain === cleanDomain)) {
      return { success: false, message: `The domain "${cleanDomain}" is already in your Vault.` };
    }

    const { catalog } = await fetchBreachCatalog();
    const breaches = catalog ? findSiteBreaches(cleanDomain, catalog) : [];
    const isBreached = breaches.length > 0;

    const newSite: VaultSite = {
      domain: cleanDomain,
      status: isBreached ? 'breached' : 'safe',
      lastChecked: Date.now(),
      nextCheckAt: Date.now() + 24 * 60 * 60 * 1000,
      autoDetected: false,
      breaches,
      notifiedBreach: isBreached
    };

    const updated = [newSite, ...vaultSites];
    setVaultSites(updated);
    saveStoredVaultSites(updated);

    if (isBreached) {
      triggerToast({
        type: 'breach',
        title: `Known Site Breach: ${cleanDomain}`,
        message: `${breaches.length} security breach recorded in HIBP database. Change your password if reused.`,
        domain: cleanDomain
      });
    }

    return {
      success: true,
      message: `Verified and added "${cleanDomain}" to Breach Vault monitoring.`
    };
  };

  const handleRemoveSiteFromVault = (domain: string) => {
    const updated = vaultSites.filter((s) => s.domain !== domain);
    setVaultSites(updated);
    saveStoredVaultSites(updated);
  };

  const handleCheckAllVaultSites = async () => {
    if (isCheckingVault || vaultSites.length === 0) return;
    setIsCheckingVault(true);

    try {
      const updated = await checkAllVaultSites(vaultSites);
      setVaultSites(updated);

      const newlyBreached = updated.filter((s) => s.status === 'breached' && !s.notifiedBreach);
      if (newlyBreached.length > 0) {
        newlyBreached.forEach((s) => {
          s.notifiedBreach = true;
          triggerToast({
            type: 'breach',
            title: `Site Breach Alert: ${s.domain}`,
            message: `Breach detected for ${s.domain}. Review credentials promptly.`,
            domain: s.domain
          });
        });
        saveStoredVaultSites(updated);
      }
    } finally {
      setIsCheckingVault(false);
    }
  };

  // Scammer Contact Handlers
  const handleAddScamContact = (contact: ScamContactRecord) => {
    const updated = [contact, ...scamContacts.filter((c) => c.id !== contact.id)];
    setScamContacts(updated);
    saveStoredScamContacts(updated);
    triggerToast({
      type: 'threat',
      title: 'Scam Contact Recorded',
      message: `Added ${contact.target} to Windows Scammer Registry.`,
      domain: contact.target
    });
  };

  const handleRemoveScamContact = (id: string) => {
    const updated = scamContacts.filter((c) => c.id !== id);
    setScamContacts(updated);
    saveStoredScamContacts(updated);
  };

  // Data Trace Shredder Handlers
  const handleAddDataTrace = (trace: DataTraceItem) => {
    const updated = [trace, ...dataTraces.filter((t) => t.id !== trace.id)];
    setDataTraces(updated);
    saveStoredDataTraces(updated);
  };

  const handleRemoveDataTrace = (id: string) => {
    const updated = dataTraces.filter((t) => t.id !== id);
    setDataTraces(updated);
    saveStoredDataTraces(updated);
  };

  const handleUpdateTraceStatus = (id: string, status: DataTraceItem['erasureStatus']) => {
    const updated = dataTraces.map((t) =>
      t.id === id
        ? {
            ...t,
            erasureStatus: status,
            lastRequestDate: status === 'request_sent' ? new Date().toISOString().split('T')[0] : t.lastRequestDate
          }
        : t
    );
    setDataTraces(updated);
    saveStoredDataTraces(updated);
  };

  // Malware & Privacy Handlers
  const handleUpdateMalwareState = (newState: MalwareScanState) => {
    setMalwareState(newState);
    saveStoredMalwareState(newState);
  };

  const handleUpdatePrivacyStatus = (newStatus: HardwarePrivacyStatus) => {
    setPrivacyStatus(newStatus);
    saveStoredPrivacyStatus(newStatus);
  };

  const handleSelectPreset = (preset: TrafficPreset) => {
    setActivePreset(preset);
    handleAuditDomain(preset.primaryDomain);
  };

  const handleToastAction = (toast: WindowsToast) => {
    if (toast.type === 'breach') {
      setActiveTab('vault');
    } else if (toast.title.includes('Tracker')) {
      setActiveTab('blocker');
    } else {
      setActiveTab('informant');
    }
  };

  const breachedCount = vaultSites.filter((s) => s.status === 'breached').length;
  const threatCount = currentLegitimacy?.isThreat ? 1 : 0;
  const activeMalwareCount = malwareState.threatsFound.filter((t) => t.status === 'active').length;

  return (
    <div
      className={`w-screen h-screen flex flex-col overflow-hidden bg-[#0d0e11] text-[#f2f3f5] font-sans transition-all ${
        isMaximized ? 'p-0' : 'p-0 sm:p-2 sm:bg-[#07080a]'
      }`}
    >
      {/* Outer Windows App Shell Frame */}
      <div
        className={`w-full h-full flex flex-col overflow-hidden bg-[#0d0e11] ${
          isMaximized ? '' : 'sm:rounded-xl sm:border sm:border-white/10 sm:shadow-2xl'
        }`}
      >
        {/* Windows 11 Title Bar */}
        <WindowsTitleBar
          isDarkMode={isDarkMode}
          onToggleDarkMode={() => setIsDarkMode(!isDarkMode)}
          isWidgetMode={isWidgetMode}
          onToggleWidgetMode={() => setIsWidgetMode(!isWidgetMode)}
          isMaximized={isMaximized}
          onToggleMaximize={() => setIsMaximized(!isMaximized)}
          activeTab={activeTab}
        />

        {/* Body Workspace */}
        {isWidgetMode ? (
          /* Compact Widget Companion View */
          <CompactWidgetView
            onExpandToFullApp={() => setIsWidgetMode(false)}
            currentLegitimacy={currentLegitimacy}
            activePreset={activePreset}
            vaultSites={vaultSites}
            onOpenGraph={() => {
              setIsWidgetMode(false);
              setActiveTab('detective');
            }}
            onOpenVault={() => {
              setIsWidgetMode(false);
              setActiveTab('vault');
            }}
            onAuditDomain={(dom) => {
              handleAuditDomain(dom);
              setIsWidgetMode(false);
              setActiveTab('informant');
            }}
            trackerSettings={trackerSettings}
            onOpenBlocker={() => {
              setIsWidgetMode(false);
              setActiveTab('blocker');
            }}
          />
        ) : (
          /* Full Desktop Application View */
          <div className="flex-1 flex overflow-hidden min-h-0">
            {/* Sidebar Navigation */}
            <WindowsSidebar
              activeTab={activeTab}
              onSelectTab={setActiveTab}
              breachCount={breachedCount}
              threatCount={threatCount}
              blockedTrackerCount={trackerSettings.totalBlockedCount}
              malwareCount={activeMalwareCount}
            />

            {/* Main Content Area */}
            <main className="flex-1 flex flex-col overflow-hidden min-w-0 bg-[#0d0e11]">
              {activeTab === 'dashboard' && (
                <DashboardView
                  vaultSites={vaultSites}
                  activePreset={activePreset}
                  onSelectPreset={handleSelectPreset}
                  onAuditDomain={handleAuditDomain}
                  onNavigateTab={setActiveTab}
                  recentAudits={recentAudits}
                  currentLegitimacy={currentLegitimacy}
                  trackerSettings={trackerSettings}
                  malwareThreatCount={activeMalwareCount}
                  traceCount={dataTraces.length}
                  scamContactCount={scamContacts.length}
                />
              )}

              {activeTab === 'informant' && (
                <InformantView
                  currentResult={currentLegitimacy}
                  onAuditDomain={handleAuditDomain}
                  isLoading={isLoadingLegitimacy}
                  onAddToVault={handleAddSiteToVault}
                  onOpenInDetective={(dom) => {
                    handleAuditDomain(dom);
                    setActiveTab('detective');
                  }}
                  vaultSites={vaultSites}
                />
              )}

              {activeTab === 'detective' && (
                <DataDetectiveGraphView
                  activePreset={activePreset}
                  onSelectPreset={handleSelectPreset}
                  onAuditDomain={handleAuditDomain}
                  onNavigateTab={setActiveTab}
                  trackerSettings={trackerSettings}
                  onToggleBlockDomain={handleToggleBlockDomain}
                  onToggleTrackerShield={handleToggleTrackerShield}
                />
              )}

              {activeTab === 'blocker' && (
                <TrackerBlockerView
                  settings={trackerSettings}
                  onUpdateSettings={handleUpdateTrackerSettings}
                  onNavigateTab={setActiveTab}
                />
              )}

              {activeTab === 'scam' && (
                <ScamDetectorView
                  scamContacts={scamContacts}
                  onAddContact={handleAddScamContact}
                  onRemoveContact={handleRemoveScamContact}
                />
              )}

              {activeTab === 'trace' && (
                <DataTraceShredderView
                  traces={dataTraces}
                  onAddTrace={handleAddDataTrace}
                  onRemoveTrace={handleRemoveDataTrace}
                  onUpdateTraceStatus={handleUpdateTraceStatus}
                />
              )}

              {activeTab === 'malware' && (
                <MalwareInspectorView
                  scanState={malwareState}
                  onUpdateScanState={handleUpdateMalwareState}
                />
              )}

              {activeTab === 'privacy' && (
                <PrivacyShieldView
                  privacyStatus={privacyStatus}
                  onUpdatePrivacyStatus={handleUpdatePrivacyStatus}
                />
              )}

              {activeTab === 'vault' && (
                <BreachVaultView
                  vaultSites={vaultSites}
                  onAddSite={handleAddSiteToVault}
                  onCheckAll={handleCheckAllVaultSites}
                  onRemoveSite={handleRemoveSiteFromVault}
                  isChecking={isCheckingVault}
                />
              )}

              {activeTab === 'inspector' && (
                <TrafficInspectorView
                  activePreset={activePreset}
                  onAuditDomain={handleAuditDomain}
                  onNavigateTab={setActiveTab}
                  trackerSettings={trackerSettings}
                  onToggleBlockDomain={handleToggleBlockDomain}
                />
              )}

              {activeTab === 'guide' && <SecurityGuideView />}
            </main>
          </div>
        )}

        {/* Windows 11 Action Center Notification Toasts */}
        <WindowsActionCenterToast
          toasts={toasts}
          onDismiss={(id) => setToasts((prev) => prev.filter((t) => t.id !== id))}
          onAction={handleToastAction}
        />
      </div>
    </div>
  );
}
