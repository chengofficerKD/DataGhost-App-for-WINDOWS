import { ScamAnalysisResult, ScamCategory, ScamContactRecord, ScamThreatLevel } from '../types';

const SCAM_CONTACTS_STORAGE_KEY = 'dataghost_scam_contacts_v1';

// Known VOIP / Disposable / Spammer prefixes and domains
const DISPOSABLE_EMAIL_PROVIDERS = new Set([
  'tempmail.com', 'guerrillamail.com', 'mailinator.com', '10minutemail.com',
  'sharklasers.com', 'throwawaymail.com', 'dispostable.com', 'yopmail.com',
  'fakeinbox.com', 'trashmail.com', 'getairmail.com'
]);

const SUSPICIOUS_EMAIL_KEYWORDS = [
  'microsoft-support', 'apple-security', 'paypal-verification', 'chase-security',
  'irs-tax-refund', 'amazon-order-verify', 'binance-auth', 'usps-delivery-hold',
  'account-locked', 'security-alert', 'crypto-bonus', 'wallet-confirm'
];

const SCAM_MESSAGE_KEYWORDS = [
  { trigger: 'anydesk', category: 'tech_support_fraud' as ScamCategory, desc: 'Requests remote desktop software (AnyDesk) to access your computer.' },
  { trigger: 'teamviewer', category: 'tech_support_fraud' as ScamCategory, desc: 'Requests remote access tools to take over your PC.' },
  { trigger: 'quick assist', category: 'tech_support_fraud' as ScamCategory, desc: 'Windows Quick Assist impersonation scheme.' },
  { trigger: 'gift card', category: 'advance_fee' as ScamCategory, desc: 'Demands payment via Apple, Target, or Google Play gift cards.' },
  { trigger: 'target card', category: 'advance_fee' as ScamCategory, desc: 'Demands retail gift cards (irreversible payment).' },
  { trigger: 'wire transfer', category: 'bank_impersonation' as ScamCategory, desc: 'Urgent wire transfer instructions.' },
  { trigger: 'bitcoin atm', category: 'crypto_pig_butchering' as ScamCategory, desc: 'Directs victim to deposit physical cash into a Bitcoin ATM machine.' },
  { trigger: 'co-signer', category: 'advance_fee' as ScamCategory, desc: 'Loan co-signing / advance fee advance scheme.' },
  { trigger: 'account suspended', category: 'bank_impersonation' as ScamCategory, desc: 'Manufactured urgency claiming imminent account lockout.' },
  { trigger: 'usps package', category: 'phishing_sms' as ScamCategory, desc: 'Smishing claiming an undelivered parcel requiring immediate address update.' },
  { trigger: 'customs fee', category: 'advance_fee' as ScamCategory, desc: 'Demands customs fee or parcel clearance fee.' },
  { trigger: 'whatsapp me', category: 'crypto_pig_butchering' as ScamCategory, desc: 'Diverts communication to encrypted channels for Pig Butchering investment fraud.' }
];

const DEFAULT_KNOWN_SCAMMERS: ScamContactRecord[] = [
  {
    id: 'scam_1',
    target: '+1 (800) 419-7431',
    type: 'phone',
    threatLevel: 'critical',
    riskScore: 98,
    scamCategory: 'tech_support_fraud',
    carrierOrDomain: 'Bandwidth.com (VOIP Throwaway)',
    isVoip: true,
    reportsCount: 1420,
    lastReported: '2026-11-10',
    notes: 'Impersonates Microsoft Windows Security Support. Claims computer is infected with Trojan virus to demand $399 remote cleanup fee.',
    redFlags: [
      'Spoofed VOIP phone line with no verified physical carrier',
      'Over 1,400 user complaints on FTC / Consumer databases',
      'Demands installation of remote control tools (AnyDesk)'
    ]
  },
  {
    id: 'scam_2',
    target: 'security-alert@microsoft-verification-live.online',
    type: 'email',
    threatLevel: 'critical',
    riskScore: 95,
    scamCategory: 'tech_support_fraud',
    carrierOrDomain: 'microsoft-verification-live.online (Lookalike Domain)',
    isVoip: false,
    reportsCount: 310,
    lastReported: '2026-11-11',
    notes: 'Typosquatting phishing email impersonating Microsoft 365. Contains deceptive invoice for $499 auto-renewal.',
    redFlags: [
      'Domain was registered 12 days ago in Iceland',
      'Failed SPF and DKIM sender identity authentication',
      'Contains fake customer service hotline directing to overseas call center'
    ]
  },
  {
    id: 'scam_3',
    target: '+1 (415) 890-3491',
    type: 'phone',
    threatLevel: 'critical',
    riskScore: 92,
    scamCategory: 'phishing_sms',
    carrierOrDomain: 'TextNow / Twilio Virtual Line',
    isVoip: true,
    reportsCount: 884,
    lastReported: '2026-11-12',
    notes: 'Sends USPS / FedEx smishing text: "Your package is held at depot due to incomplete address. Click usps-tracking-hub.top".',
    redFlags: [
      'Mass automated virtual SMS sender',
      'Links to known phishing domain flagged by Cloudflare DoH',
      'Demands credit card payment for redelivery fee'
    ]
  },
  {
    id: 'scam_4',
    target: '0x71C...8491aF (USDT ERC-20)',
    type: 'crypto_address',
    threatLevel: 'critical',
    riskScore: 99,
    scamCategory: 'crypto_pig_butchering',
    carrierOrDomain: 'Ethereum Blockchain Blacklist',
    isVoip: false,
    reportsCount: 64,
    lastReported: '2026-11-08',
    notes: 'Identified Pig Butchering romance investment wallet. Over $1.2M USDT drained from victims.',
    redFlags: [
      'Blacklisted on Chainalysis & ScamSniffer security feeds',
      'Rapid exfiltration to Tornado Cash mixer contracts'
    ]
  }
];

export function getStoredScamContacts(): ScamContactRecord[] {
  try {
    const raw = localStorage.getItem(SCAM_CONTACTS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch {}
  return DEFAULT_KNOWN_SCAMMERS;
}

export function saveStoredScamContacts(contacts: ScamContactRecord[]): void {
  try {
    localStorage.setItem(SCAM_CONTACTS_STORAGE_KEY, JSON.stringify(contacts));
  } catch {}
}

export function analyzeContactOrMessage(input: string): ScamAnalysisResult {
  const clean = input.trim();
  const lower = clean.toLowerCase();

  // 1. Detect Input Type
  const isEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(clean);
  const isPhone = /^(\+?\d{1,4}[-.\s]?)?(\(?\d{3}\)?[-.\s]?)?[\d]{3}[-.\s]?[\d]{4}$/.test(clean.replace(/\s+/g, ' '));
  const isCrypto = /^(0x[a-fA-F0-9]{40}|[13][a-km-zA-HJ-NP-Z1-9]{25,34}|bc1[a-zA-HJ-NP-Z0-9]{39,59}|[1-9A-HJ-NP-Za-km-z]{32,44})$/.test(clean);
  const isMessage = clean.length > 30 && !isEmail && !isCrypto;

  const targetType = isEmail ? 'email' : isPhone ? 'phone' : isCrypto ? 'crypto_address' : 'text_message';

  let riskScore = 15;
  let threatLevel: ScamThreatLevel = 'clean';
  let category: ScamCategory = 'unknown';
  const redFlags: string[] = [];
  const recommendations: string[] = [];
  let summary = 'No high-risk scam patterns detected.';
  let carrierDetails = 'Standard Registered Carrier / Identity';

  // Check against known local scam contacts database
  const contacts = getStoredScamContacts();
  const matchedKnown = contacts.find((c) => c.target.toLowerCase() === lower || lower.includes(c.target.toLowerCase()));
  if (matchedKnown) {
    return {
      target: clean,
      type: matchedKnown.type,
      threatLevel: matchedKnown.threatLevel,
      riskScore: matchedKnown.riskScore,
      category: matchedKnown.scamCategory,
      summary: matchedKnown.notes,
      redFlags: matchedKnown.redFlags,
      carrierDetails: matchedKnown.carrierOrDomain,
      recommendations: [
        'Do not reply, call back, or click any links from this contact.',
        'Block this number/sender immediately in your Windows and phone settings.',
        'Report this scammer to the FTC (reportfraud.ftc.gov) or IC3 (ic3.gov).'
      ]
    };
  }

  // Email Analysis
  if (isEmail) {
    const domain = lower.split('@')[1];
    if (DISPOSABLE_EMAIL_PROVIDERS.has(domain)) {
      riskScore += 60;
      redFlags.push(`Uses disposable temporary inbox provider (${domain}) to evade tracking.`);
      category = 'phishing_sms';
    }
    if (SUSPICIOUS_EMAIL_KEYWORDS.some((kw) => domain.includes(kw))) {
      riskScore += 75;
      redFlags.push(`Domain contains high-risk brand impersonation keywords (${domain}).`);
      category = 'tech_support_fraud';
    }
    if (domain.endsWith('.xyz') || domain.endsWith('.top') || domain.endsWith('.online') || domain.endsWith('.live')) {
      riskScore += 25;
      redFlags.push(`Uses cheap disposable TLD (.${domain.split('.').pop()}) commonly associated with phishing campaigns.`);
    }
  }

  // Phone Analysis
  if (isPhone) {
    if (clean.startsWith('+1800') || clean.startsWith('+1888') || clean.startsWith('800') || clean.startsWith('888') || clean.startsWith('855')) {
      riskScore += 30;
      carrierDetails = 'Toll-Free Virtual VOIP Line';
      redFlags.push('Toll-free virtual number frequently rented by unauthorized overseas call centers.');
    } else {
      carrierDetails = 'Virtual PBX / VOIP Provider (Twilio/Bandwidth)';
    }
  }

  // Message Text Trigger Analysis
  if (isMessage || clean.length > 20) {
    for (const kw of SCAM_MESSAGE_KEYWORDS) {
      if (lower.includes(kw.trigger)) {
        riskScore += 35;
        category = kw.category;
        redFlags.push(kw.desc);
      }
    }
  }

  // Calculate Threat Level
  if (riskScore >= 75) {
    threatLevel = 'critical';
    summary = 'HIGH-RISK SCAM DETECTED! This contact matches aggressive consumer fraud and phishing patterns.';
    recommendations.push('Do NOT send money, crypto, or gift cards under any circumstances.');
    recommendations.push('Never allow this person to connect to your computer via AnyDesk, TeamViewer, or Quick Assist.');
    recommendations.push('Block this contact and report to the FTC (Federal Trade Commission) or your local police cyber division.');
  } else if (riskScore >= 45) {
    threatLevel = 'suspicious';
    summary = 'SUSPICIOUS CONTACT: Shows multiple signs of deceptive spoofing or automated telemarketing.';
    recommendations.push('Verify identity independently through official public telephone numbers, not the contact info provided in the message.');
    recommendations.push('Do not disclose any verification codes, SSN, or banking passwords.');
  } else {
    threatLevel = 'clean';
    summary = 'No verified scam complaints or deceptive patterns identified for this contact.';
    recommendations.push('Standard caution: Never share sensitive passwords or verification codes over phone or email.');
  }

  return {
    target: clean,
    type: targetType,
    threatLevel,
    riskScore: Math.min(100, Math.max(0, riskScore)),
    category,
    summary,
    redFlags: redFlags.length > 0 ? redFlags : ['No overt malicious triggers identified in public databases.'],
    carrierDetails,
    recommendations
  };
}
