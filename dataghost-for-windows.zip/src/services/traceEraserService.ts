import { DataTraceItem, ErasureRequestTemplate } from '../types';

const TRACE_STORAGE_KEY = 'dataghost_data_traces_v1';

const DEFAULT_TRACES: DataTraceItem[] = [
  {
    id: 'trace_1',
    domain: 'paypal-security-update.xyz',
    dataTypesExposed: ['Passwords', 'Email', 'IP Address'],
    exposureDate: '2026-11-12',
    isHttpUnencrypted: true,
    erasureStatus: 'not_requested',
    notes: 'Submitted test login on unencrypted HTTP phishing clone. Password exposed in plaintext.'
  },
  {
    id: 'trace_2',
    domain: 'suspicious-job-portal.top',
    dataTypesExposed: ['Full Name', 'Email', 'Phone', 'IP Address'],
    exposureDate: '2026-11-04',
    isHttpUnencrypted: false,
    erasureStatus: 'request_sent',
    lastRequestDate: '2026-11-06',
    notes: 'Submitted resume data to unregulated overseas recruiter site.'
  },
  {
    id: 'trace_3',
    domain: 'free-crypto-giveaway.online',
    dataTypesExposed: ['Email', 'IP Address', 'Cookies'],
    exposureDate: '2026-10-28',
    isHttpUnencrypted: true,
    erasureStatus: 'erased',
    lastRequestDate: '2026-10-30',
    notes: 'Tracking cookies and session data purged. Formal GDPR erasure notice acknowledged by host registrar.'
  }
];

export function getStoredDataTraces(): DataTraceItem[] {
  try {
    const raw = localStorage.getItem(TRACE_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
  } catch {}
  return DEFAULT_TRACES;
}

export function saveStoredDataTraces(traces: DataTraceItem[]): void {
  try {
    localStorage.setItem(TRACE_STORAGE_KEY, JSON.stringify(traces));
  } catch {}
}

export function generateErasureRequest(
  domain: string,
  userEmail: string,
  userFullName: string,
  dataTypes: string[],
  legalBasis: 'GDPR_ART_17' | 'CCPA_SEC_1798' = 'GDPR_ART_17'
): ErasureRequestTemplate {
  const isGdpr = legalBasis === 'GDPR_ART_17';
  const statuteName = isGdpr
    ? 'Article 17 of the General Data Protection Regulation (GDPR) — Right to Erasure'
    : 'California Consumer Privacy Act (CCPA) § 1798.105 — Right to Delete Personal Information';

  const recipientEmail = `privacy@${domain}, abuse@${domain}, support@${domain}`;
  const subject = `FORMAL DEMAND: Immediate Erasure & Deletion of Personal Data under ${isGdpr ? 'GDPR Art. 17' : 'CCPA'}`;

  const body = `To the Data Protection Officer / Site Administrators of ${domain},

I am writing to formally submit a demand for the IMMEDIATE ERASURE and complete deletion of all personal data, credentials, and digital identifiers associated with my identity, pursuant to ${statuteName}.

Identifiers & Data Categories Subject to Deletion:
- Full Name: ${userFullName || '[YOUR FULL NAME]'}
- Associated Email: ${userEmail || '[YOUR EMAIL ADDRESS]'}
- Data Categories: ${dataTypes.join(', ')}
- Source Domain / Endpoint: ${domain}

Legal Requirement:
Under applicable data privacy statutes, you are required to permanently erase all records of my personal data from your primary databases, server logs, backup snapshots, and downstream marketing/analytics partners within 30 days without undue delay.

Confirmation Request:
Please reply to this email confirming in writing that:
1. All personal records, uploaded forms, credentials, and log entries have been permanently purged.
2. Any third-party data processors or marketing vendors have been instructed to delete all copies of this data.

Failure to comply with this request will result in immediate formal complaints lodged with relevant supervisory authorities (including the Information Commissioner's Office, CNIL, or state Attorney General) regarding unauthorized retention and processing of personal data.

Sincerely,
${userFullName || '[YOUR FULL NAME]'}
Sent via DataGhost for Windows — Privacy Footprint Shredder`;

  return {
    legalBasis,
    subject,
    recipientEmail,
    body
  };
}

export async function simulateSystemTracePurge(domain: string): Promise<{
  cookiesPurged: number;
  tokensInvalidated: number;
  dnsFlushed: boolean;
  tempFilesClearedKb: number;
}> {
  // Simulates realistic Windows & browser trace scrubbing
  await new Promise((r) => setTimeout(r, 900));

  return {
    cookiesPurged: Math.floor(6 + Math.random() * 8),
    tokensInvalidated: 2,
    dnsFlushed: true,
    tempFilesClearedKb: Math.floor(450 + Math.random() * 800)
  };
}
