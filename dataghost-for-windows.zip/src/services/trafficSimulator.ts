import { DomainCategory, PostRequest, TrafficPreset } from '../types';

export const CATEGORY_COLORS: Record<DomainCategory, string> = {
  Primary: '#8ab4f8',
  Auth: '#55d6be',
  Tracking: '#fdd663',
  API: '#ffad66',
  Service: '#81c995',
  Analytics: '#65d8ff',
  Essential: '#a7e8a1',
  Unknown: '#a0a2aa'
};

export const TRAFFIC_PRESETS: TrafficPreset[] = [
  {
    id: 'ecommerce',
    name: 'E-Commerce Store (Shopify / Multi-Trackers)',
    description: 'Realistic modern shopping platform with payment gateway, ad trackers, analytics, and CDNs.',
    primaryDomain: 'nordicstore.com',
    protocol: 'https:',
    nodes: [
      { host: 'nordicstore.com', category: 'Primary', count: 18, isSecure: true },
      { host: 'cdn.shopify.com', category: 'Essential', count: 42, isSecure: true },
      { host: 'api.stripe.com', category: 'Service', count: 9, isSecure: true },
      { host: 'google-analytics.com', category: 'Analytics', count: 24, isSecure: true },
      { host: 'analytics.tiktok.com', category: 'Tracking', count: 31, isSecure: true },
      { host: 'connect.facebook.net', category: 'Tracking', count: 27, isSecure: true },
      { host: 'fonts.googleapis.com', category: 'Essential', count: 6, isSecure: true },
      { host: 'auth.shopify.com', category: 'Auth', count: 5, isSecure: true },
      { host: 'bat.bing.com', category: 'Tracking', count: 12, isSecure: true },
      { host: 'clarity.ms', category: 'Analytics', count: 19, isSecure: true }
    ],
    connections: [
      { from: 'nordicstore.com', to: 'cdn.shopify.com', category: 'Essential' },
      { from: 'nordicstore.com', to: 'api.stripe.com', category: 'Service' },
      { from: 'nordicstore.com', to: 'google-analytics.com', category: 'Analytics' },
      { from: 'nordicstore.com', to: 'analytics.tiktok.com', category: 'Tracking' },
      { from: 'nordicstore.com', to: 'connect.facebook.net', category: 'Tracking' },
      { from: 'nordicstore.com', to: 'fonts.googleapis.com', category: 'Essential' },
      { from: 'nordicstore.com', to: 'auth.shopify.com', category: 'Auth' },
      { from: 'nordicstore.com', to: 'bat.bing.com', category: 'Tracking' },
      { from: 'nordicstore.com', to: 'clarity.ms', category: 'Analytics' }
    ],
    posts: [
      { path: '/api/cart/update', host: 'nordicstore.com', isSecure: true, category: 'Primary', payloadType: 'Cart State' },
      { path: '/v1/tokens', host: 'api.stripe.com', isSecure: true, category: 'Service', payloadType: 'Payment Token' },
      { path: '/events/checkout_view', host: 'analytics.tiktok.com', isSecure: true, category: 'Tracking', payloadType: 'Ad Telemetry' },
      { path: '/g/collect', host: 'google-analytics.com', isSecure: true, category: 'Analytics', payloadType: 'User Session' }
    ],
    hasLogin: false
  },
  {
    id: 'crypto_broker',
    name: 'Financial Trading Portal (xm.com / Strict TLS)',
    description: 'High-security financial broker with verified registry, identity auth, and encrypted feeds.',
    primaryDomain: 'xm.com',
    protocol: 'https:',
    nodes: [
      { host: 'xm.com', category: 'Primary', count: 28, isSecure: true },
      { host: 'secure.xm.com', category: 'Auth', count: 14, isSecure: true },
      { host: 'trading-api.xm.com', category: 'API', count: 52, isSecure: true },
      { host: 'cloudflare.com', category: 'Essential', count: 16, isSecure: true },
      { host: 'stream.xm.com', category: 'API', count: 88, isSecure: true },
      { host: 'veriff.me', category: 'Auth', count: 8, isSecure: true },
      { host: 'datadoghq.com', category: 'Service', count: 11, isSecure: true }
    ],
    connections: [
      { from: 'xm.com', to: 'secure.xm.com', category: 'Auth' },
      { from: 'xm.com', to: 'trading-api.xm.com', category: 'API' },
      { from: 'xm.com', to: 'cloudflare.com', category: 'Essential' },
      { from: 'xm.com', to: 'stream.xm.com', category: 'API' },
      { from: 'secure.xm.com', to: 'veriff.me', category: 'Auth' },
      { from: 'xm.com', to: 'datadoghq.com', category: 'Service' }
    ],
    posts: [
      { path: '/auth/session/token', host: 'secure.xm.com', isSecure: true, category: 'Auth', payloadType: 'Encrypted Credential' },
      { path: '/v2/orders/market', host: 'trading-api.xm.com', isSecure: true, category: 'API', payloadType: 'Order Payload' }
    ],
    hasLogin: true,
    loginTarget: 'secure.xm.com'
  },
  {
    id: 'phishing_threat',
    name: 'Suspicious Phishing Clone (Insecure HTTP / Foreign Target)',
    description: 'Simulates a throwaway lookalike attack site sending unencrypted credentials to an external host.',
    primaryDomain: 'paypal-security-update.xyz',
    protocol: 'http:',
    nodes: [
      { host: 'paypal-security-update.xyz', category: 'Primary', count: 7, isSecure: false },
      { host: 'exfiltration-collector.top', category: 'Unknown', count: 19, isSecure: false },
      { host: '194.87.12.91', category: 'Unknown', count: 12, isSecure: false },
      { host: 'font-cdn.ru', category: 'Essential', count: 4, isSecure: false }
    ],
    connections: [
      { from: 'paypal-security-update.xyz', to: 'exfiltration-collector.top', category: 'Unknown' },
      { from: 'paypal-security-update.xyz', to: '194.87.12.91', category: 'Unknown' },
      { from: 'paypal-security-update.xyz', to: 'font-cdn.ru', category: 'Essential' }
    ],
    posts: [
      {
        path: '/steal/creds.php',
        host: 'exfiltration-collector.top',
        isSecure: false,
        category: 'Unknown',
        payloadType: 'Plaintext Password & SSN'
      },
      {
        path: '/log.php',
        host: '194.87.12.91',
        isSecure: false,
        category: 'Unknown',
        payloadType: 'Victim IP & Keystrokes'
      }
    ],
    hasLogin: true,
    loginTarget: 'exfiltration-collector.top'
  },
  {
    id: 'saas_platform',
    name: 'Developer Cloud Console (GitHub / Zero Trackers)',
    description: 'Clean developer workspace with authentication, API hubs, and zero commercial ad networks.',
    primaryDomain: 'github.com',
    protocol: 'https:',
    nodes: [
      { host: 'github.com', category: 'Primary', count: 34, isSecure: true },
      { host: 'api.github.com', category: 'API', count: 65, isSecure: true },
      { host: 'github.githubassets.com', category: 'Essential', count: 44, isSecure: true },
      { host: 'avatars.githubusercontent.com', category: 'Essential', count: 22, isSecure: true },
      { host: 'collector.github.com', category: 'Analytics', count: 8, isSecure: true }
    ],
    connections: [
      { from: 'github.com', to: 'api.github.com', category: 'API' },
      { from: 'github.com', to: 'github.githubassets.com', category: 'Essential' },
      { from: 'github.com', to: 'avatars.githubusercontent.com', category: 'Essential' },
      { from: 'github.com', to: 'collector.github.com', category: 'Analytics' }
    ],
    posts: [
      { path: '/api/graphql', host: 'api.github.com', isSecure: true, category: 'API', payloadType: 'GraphQL Mutation' },
      { path: '/collector', host: 'collector.github.com', isSecure: true, category: 'Analytics', payloadType: 'Usage Event' }
    ],
    hasLogin: true,
    loginTarget: 'github.com'
  }
];

export function buildRecentAuditList() {
  return [
    { domain: 'google.com', timestamp: Date.now() - 1000 * 60 * 12, isThreat: false, category: 'Search & Technology' },
    { domain: 'xm.com', timestamp: Date.now() - 1000 * 60 * 45, isThreat: false, category: 'Financial Trading / Broker' },
    { domain: 'paypal-security-update.xyz', timestamp: Date.now() - 1000 * 60 * 95, isThreat: true, category: 'Phishing Threat' },
    { domain: 'github.com', timestamp: Date.now() - 1000 * 60 * 180, isThreat: false, category: 'Software Development' },
    { domain: 'netflix.com', timestamp: Date.now() - 1000 * 60 * 240, isThreat: false, category: 'Digital Media & Streaming' }
  ];
}
