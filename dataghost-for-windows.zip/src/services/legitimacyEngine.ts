import { DomainCategory, LegitimacyResult } from '../types';

export const MULTI_PART_SUFFIXES = new Set([
  'co.uk', 'org.uk', 'gov.uk', 'ac.uk', 'me.uk',
  'com.au', 'net.au', 'org.au', 'edu.au', 'gov.au',
  'co.nz', 'net.nz', 'org.nz',
  'co.jp', 'ne.jp', 'or.jp',
  'com.br', 'org.br', 'net.br',
  'co.in', 'net.in', 'org.in', 'gen.in',
  'com.sg', 'edu.sg', 'gov.sg',
  'com.mx', 'org.mx',
  'co.za', 'org.za',
  'com.tr', 'edu.tr',
  'com.hk', 'org.hk'
]);

export function getPrimaryDomain(hostname: string): string {
  if (!hostname) return '';
  hostname = hostname.toLowerCase().trim();

  // Strip ports, protocols, or path if passed accidentally
  try {
    if (hostname.includes('://')) {
      hostname = new URL(hostname).hostname;
    } else if (hostname.includes('/')) {
      hostname = hostname.split('/')[0];
    }
  } catch {}

  hostname = hostname.split(':')[0];

  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(hostname) || hostname.includes(':')) {
    return hostname;
  }

  const parts = hostname.split('.');
  if (parts.length <= 2) return hostname;

  const lastTwo = parts.slice(-2).join('.');
  if (MULTI_PART_SUFFIXES.has(lastTwo) && parts.length >= 3) {
    return parts.slice(-3).join('.');
  }

  return parts.slice(-2).join('.');
}

export const KNOWN_CATEGORIES: Record<string, { category: string; verified: boolean; type?: DomainCategory }> = {
  // Financial & Trading
  'xm.com': { category: 'Financial Trading / Broker', verified: true, type: 'Service' },
  'binance.com': { category: 'Cryptocurrency Exchange', verified: true, type: 'Service' },
  'coinbase.com': { category: 'Cryptocurrency Platform', verified: true, type: 'Service' },
  'etoro.com': { category: 'Trading & Investing', verified: true, type: 'Service' },
  'robinhood.com': { category: 'Financial Services', verified: true, type: 'Service' },
  'interactivebrokers.com': { category: 'Online Brokerage', verified: true, type: 'Service' },
  'ig.com': { category: 'Financial Trading', verified: true, type: 'Service' },
  'plus500.com': { category: 'Financial Trading', verified: true, type: 'Service' },
  'oanda.com': { category: 'Currency Trading', verified: true, type: 'Service' },
  'paypal.com': { category: 'Payment Services', verified: true, type: 'Service' },
  'stripe.com': { category: 'Payment Processing', verified: true, type: 'Service' },

  // Tech & Cloud
  'google.com': { category: 'Search & Technology', verified: true, type: 'Primary' },
  'github.com': { category: 'Software Development', verified: true, type: 'Service' },
  'apple.com': { category: 'Consumer Technology', verified: true, type: 'Service' },
  'microsoft.com': { category: 'Software & Cloud', verified: true, type: 'Service' },
  'cloudflare.com': { category: 'Cloud Infrastructure', verified: true, type: 'Essential' },
  'amazon.com': { category: 'E-Commerce & Cloud', verified: true, type: 'Primary' },
  'gitlab.com': { category: 'Software Development', verified: true, type: 'Service' },

  // Social & Communication
  'facebook.com': { category: 'Social Network', verified: true, type: 'Service' },
  'twitter.com': { category: 'Social Network', verified: true, type: 'Service' },
  'x.com': { category: 'Social Network', verified: true, type: 'Service' },
  'linkedin.com': { category: 'Professional Network', verified: true, type: 'Service' },
  'reddit.com': { category: 'Community Forum', verified: true, type: 'Service' },
  'discord.com': { category: 'Communications', verified: true, type: 'Service' },
  'netflix.com': { category: 'Digital Media & Streaming', verified: true, type: 'Service' }
};

const domainReputationCache = new Map<string, LegitimacyResult>();

export async function verifyWebsiteLegitimacy(inputUrlOrHost: string): Promise<LegitimacyResult> {
  let hostname = inputUrlOrHost.trim().toLowerCase();
  let protocol: 'https:' | 'http:' = 'https:';

  try {
    if (hostname.startsWith('http://')) {
      protocol = 'http:';
      hostname = new URL(hostname).hostname;
    } else if (hostname.startsWith('https://')) {
      protocol = 'https:';
      hostname = new URL(hostname).hostname;
    } else if (hostname.includes('/')) {
      hostname = hostname.split('/')[0];
    }
  } catch {}

  const primary = getPrimaryDomain(hostname);
  if (!primary) {
    return {
      domain: hostname,
      hostname,
      isLegit: false,
      isThreat: true,
      threatType: 'invalid_domain',
      threatReason: 'Invalid hostname format or missing top-level domain.',
      category: 'Invalid Host',
      registrationYear: null,
      checks: { dns: 'unknown', rdap: 'unknown', transport: 'secure' },
      verifiedSources: [],
      protocol,
      riskScore: 90
    };
  }

  const cacheKey = `${protocol}_${primary}`;
  if (domainReputationCache.has(cacheKey)) {
    return domainReputationCache.get(cacheKey)!;
  }

  const result: LegitimacyResult = {
    domain: primary,
    hostname,
    isLegit: true,
    isThreat: false,
    threatType: null,
    threatReason: '',
    category: 'General Web',
    registrationYear: null,
    checks: { dns: 'unknown', rdap: 'unknown', transport: protocol === 'https:' ? 'secure' : 'unencrypted' },
    verifiedSources: [],
    protocol,
    riskScore: protocol === 'http:' ? 65 : 10
  };

  // 1. Check Known Category Registry
  if (KNOWN_CATEGORIES[primary]) {
    result.category = KNOWN_CATEGORIES[primary].category;
    result.isLegit = true;
    result.verifiedSources.push('Verified Industry Registry');
    result.riskScore = Math.max(0, result.riskScore - 20);
  }

  // 2. Query Cloudflare 1.1.1.1 for Families Security Threat Filter
  try {
    const cfRes = await fetch(`https://security.cloudflare-dns.com/dns-query?name=${encodeURIComponent(primary)}&type=A`, {
      headers: { 'Accept': 'application/dns-json' }
    });
    if (cfRes.ok) {
      const cfData = await cfRes.json();
      if (cfData.Answer && Array.isArray(cfData.Answer)) {
        const isBlocked = cfData.Answer.some((a: { data: string }) => a.data === '0.0.0.0' || a.data === '127.0.0.1');
        if (isBlocked) {
          result.checks.dns = 'blocked';
          result.isThreat = true;
          result.threatType = 'malware_phishing';
          result.threatReason = 'Domain is actively blocked by Cloudflare Security Threat Intelligence database.';
          result.riskScore = 95;
        } else {
          result.checks.dns = 'clean';
          result.verifiedSources.push('Cloudflare Security DNS (Filtered)');
        }
      } else if (cfData.Status === 0) {
        result.checks.dns = 'clean';
        result.verifiedSources.push('Cloudflare Security DNS');
      }
    }
  } catch {
    result.checks.dns = 'unknown';
  }

  // 3. Query Open ICANN RDAP Database for Registration History & Age
  try {
    const rdapRes = await fetch(`https://rdap.org/domain/${encodeURIComponent(primary)}`, {
      headers: { 'Accept': 'application/json, application/rdap+json' }
    });
    if (rdapRes.ok) {
      const rdapData = await rdapRes.json();
      result.checks.rdap = 'checked';
      if (rdapData.events && Array.isArray(rdapData.events)) {
        const regEvent = rdapData.events.find((e: { eventAction: string }) => e.eventAction === 'registration');
        if (regEvent && regEvent.eventDate) {
          result.checks.rdap = 'registered';
          const regDate = new Date(regEvent.eventDate);
          result.registrationYear = regDate.getFullYear();
          result.registrationDate = regDate.toISOString().split('T')[0];
          const ageDays = (Date.now() - regDate.getTime()) / (1000 * 60 * 60 * 24);
          result.ageDays = Math.round(ageDays);
          const ageYears = new Date().getFullYear() - result.registrationYear;

          if (ageYears >= 2) {
            result.isLegit = true;
            result.verifiedSources.push(`ICANN RDAP (Registered ${result.registrationYear})`);
            result.riskScore = Math.max(5, result.riskScore - 15);
          } else if (ageDays < 30) {
            result.isThreat = true;
            result.threatType = 'new_domain_risk';
            result.threatReason = `Domain was registered only ${Math.round(ageDays)} days ago. Newly registered domains carry high disposable phishing and scam risk.`;
            result.riskScore = Math.max(result.riskScore, 85);
          }
        }
      }
    }
  } catch {
    result.checks.rdap = 'unknown';
  }

  // 4. Local Heuristic Checks
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(hostname)) {
    result.isThreat = true;
    result.threatType = 'raw_ip';
    result.threatReason = 'Host is a raw numerical IP address rather than a verified registered domain.';
    result.riskScore = Math.max(result.riskScore, 80);
  }

  // Plaintext HTTP penalty
  if (protocol === 'http:') {
    result.isThreat = true;
    if (!result.threatReason) {
      result.threatType = 'insecure_http';
      result.threatReason = 'Connection is unencrypted HTTP. Any login credentials or data in transit can be eavesdropped on the local network.';
    }
    result.riskScore = Math.max(result.riskScore, 75);
  }

  domainReputationCache.set(cacheKey, result);
  return result;
}
