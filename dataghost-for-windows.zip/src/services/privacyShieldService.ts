import { HardwarePrivacyStatus } from '../types';

const PRIVACY_STORAGE_KEY = 'dataghost_privacy_shield_v1';

const DEFAULT_PRIVACY_STATUS: HardwarePrivacyStatus = {
  cameraLocked: false,
  micLocked: false,
  locationLocked: true,
  activeAppUsingMic: null,
  activeAppUsingCam: null,
  recentAppPermissions: [
    {
      app: 'Edge / Chrome Browser',
      type: 'location',
      timestamp: Date.now() - 1000 * 60 * 18,
      blocked: true
    },
    {
      app: 'Windows Voice Recorder',
      type: 'microphone',
      timestamp: Date.now() - 1000 * 60 * 45,
      blocked: false
    },
    {
      app: 'Suspicious_Background_Process.exe',
      type: 'camera',
      timestamp: Date.now() - 1000 * 60 * 120,
      blocked: true
    }
  ]
};

export function getStoredPrivacyStatus(): HardwarePrivacyStatus {
  try {
    const raw = localStorage.getItem(PRIVACY_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return { ...DEFAULT_PRIVACY_STATUS, ...parsed };
    }
  } catch {}
  return DEFAULT_PRIVACY_STATUS;
}

export function saveStoredPrivacyStatus(status: HardwarePrivacyStatus): void {
  try {
    localStorage.setItem(PRIVACY_STORAGE_KEY, JSON.stringify(status));
  } catch {}
}
