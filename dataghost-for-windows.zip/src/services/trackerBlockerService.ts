import { TrackerShieldSettings, DomainCategory } from '../types';
import { getPrimaryDomain } from './legitimacyEngine';

const TRACKER_STORAGE_KEY = 'dataghost_tracker_shield_v1';

export const KNOWN_TRACKER_DOMAINS = new Set([
  'analytics.tiktok.com',
  'connect.facebook.net',
  'bat.bing.com',
  'clarity.ms',
  'google-analytics.com',
  'doubleclick.net',
  'googletagmanager.com',
  'criteo.com',
  'hotjar.com',
  'scorecardresearch.com',
  'adroll.com',
  'taboola.com',
  'outbrain.com',
  'ads-twitter.com',
  'pixel.wp.com',
  'quantserve.com',
  'moatads.com'
]);

export const DEFAULT_TRACKER_SETTINGS: TrackerShieldSettings = {
  enabled: true,
  mode: 'balanced',
  blockedDomains: [
    'analytics.tiktok.com',
    'connect.facebook.net',
    'bat.bing.com',
    'clarity.ms',
    'doubleclick.net'
  ],
  whitelistedDomains: [],
  totalBlockedCount: 384,
  dataSavedBytes: 8.4 * 1024 * 1024 // 8.4 MB
};

export function getStoredTrackerSettings(): TrackerShieldSettings {
  try {
    const raw = localStorage.getItem(TRACKER_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return {
        ...DEFAULT_TRACKER_SETTINGS,
        ...parsed
      };
    }
  } catch {}
  return DEFAULT_TRACKER_SETTINGS;
}

export function saveStoredTrackerSettings(settings: TrackerShieldSettings): void {
  try {
    localStorage.setItem(TRACKER_STORAGE_KEY, JSON.stringify(settings));
  } catch {}
}

export function isDomainBlocked(
  hostname: string,
  category: DomainCategory,
  settings: TrackerShieldSettings
): boolean {
  if (!settings.enabled) return false;

  const cleanHost = hostname.toLowerCase().trim();
  const primary = getPrimaryDomain(cleanHost);

  // If explicitly whitelisted, never block
  if (settings.whitelistedDomains.includes(cleanHost) || settings.whitelistedDomains.includes(primary)) {
    return false;
  }

  // If explicitly in user's blocked domains
  if (settings.blockedDomains.includes(cleanHost) || settings.blockedDomains.includes(primary)) {
    return true;
  }

  // Balanced mode: Block all confirmed Tracking category and known ad networks
  if (category === 'Tracking' || KNOWN_TRACKER_DOMAINS.has(cleanHost) || KNOWN_TRACKER_DOMAINS.has(primary)) {
    return true;
  }

  // Strict mode: additionally block third-party Analytics
  if (settings.mode === 'strict' && category === 'Analytics') {
    return true;
  }

  return false;
}

export function formatDataSaved(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
