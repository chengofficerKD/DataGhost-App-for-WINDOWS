import React, { useState } from 'react';
import {
  ShieldCheck,
  ShieldAlert,
  KeyRound,
  Network,
  Search,
  ExternalLink,
  ArrowRight,
  Sparkles,
  Zap,
  Globe,
  Radio,
  Lock,
  LockOpen,
  Bug,
  UserX,
  Flame,
  CameraOff
} from 'lucide-react';
import { VaultSite, LegitimacyResult, TrafficPreset, TrackerShieldSettings } from '../types';
import { TRAFFIC_PRESETS } from '../services/trafficSimulator';
import { NavTab } from './WindowsSidebar';

interface DashboardViewProps {
  vaultSites: VaultSite[];
  activePreset: TrafficPreset;
  onSelectPreset: (preset: TrafficPreset) => void;
  onAuditDomain: (domain: string) => void;
  onNavigateTab: (tab: NavTab) => void;
  recentAudits: { domain: string; timestamp: number; isThreat: boolean; category: string }[];
  currentLegitimacy: LegitimacyResult | null;
  trackerSettings: TrackerShieldSettings;
  malwareThreatCount?: number;
  traceCount?: number;
  scamContactCount?: number;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  vaultSites,
  activePreset,
  onSelectPreset,
  onAuditDomain,
  onNavigateTab,
  recentAudits,
  currentLegitimacy,
  trackerSettings,
  malwareThreatCount = 0,
  traceCount = 0,
  scamContactCount = 0
}) => {
  const [quickInput, setQuickInput] = useState('');

  const breachedSites = vaultSites.filter((s) => s.status === 'breached');
  const safeSites = vaultSites.filter((s) => s.status === 'safe');
  const totalDestinations = activePreset.nodes.length;
  const trackerCount = activePreset.nodes.filter((n) => n.category === 'Tracking').length;

  const handleQuickSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickInput.trim()) return;
    onAuditDomain(quickInput.trim());
    onNavigateTab('informant');
  };

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-[#0d0e11] text-[#f2f3f5]">
      {/* Top Welcome / Posture Banner */}
      <div className="bg-[#121316] border border-white/8 rounded-xl p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="text-xs uppercase tracking-wider text-[#8ab4f8] font-semibold">
              Windows Privacy Guardian
            </span>
            <span className="text-white/20">·</span>
            <span className="text-xs text-white/50">Multi-Database Active Engine</span>
          </div>
          <h1 className="text-xl font-bold tracking-tight text-white">System Security Posture: Optimal</h1>
          <p className="text-xs text-white/60 max-w-xl">
            Real-time Cloudflare Security DoH threat filtering, ICANN RDAP domain registration intelligence,
            Have I Been Pwned public breach audits, and native Tracker Shield blocking.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigateTab('blocker')}
            className="px-3.5 py-2 bg-[#81c995] text-black hover:bg-[#9fe0b0] font-semibold text-xs rounded-lg transition-colors flex items-center gap-1.5"
          >
            <ShieldCheck className="w-4 h-4" />
            <span>Tracker Shield</span>
          </button>
          <button
            onClick={() => onNavigateTab('detective')}
            className="px-3.5 py-2 bg-white/5 hover:bg-white/10 text-white font-medium text-xs rounded-lg border border-white/10 transition-colors flex items-center gap-1.5"
          >
            <Network className="w-4 h-4" />
            <span>Open Brain Map</span>
          </button>
        </div>
      </div>

      {/* Quick URL Scanner Bar */}
      <div className="bg-[#18191d] border border-white/8 rounded-xl p-4 space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-white/80 flex items-center gap-1.5">
            <Search className="w-3.5 h-3.5 text-[#8ab4f8]" />
            <span>Quick Legitimacy Inspector</span>
          </span>
          <span className="text-[11px] text-white/40">Enter any web address or company domain</span>
        </div>

        <form onSubmit={handleQuickSubmit} className="flex gap-2">
          <div className="relative flex-1">
            <input
              type="text"
              value={quickInput}
              onChange={(e) => setQuickInput(e.target.value)}
              placeholder="e.g. xm.com, paypal.com, or suspicious-login.top"
              className="w-full h-10 bg-[#0d0e11] border border-white/10 rounded-lg px-3.5 text-xs text-white font-mono placeholder:text-white/30 focus:outline-none focus:border-[#8ab4f8] transition-colors"
            />
          </div>
          <button
            type="submit"
            className="h-10 px-5 bg-[#8ab4f8] hover:bg-[#aecbfa] text-black text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5"
          >
            <span>Scan Domain</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </form>

        <div className="flex flex-wrap items-center gap-2 pt-1 text-xs">
          <span className="text-white/40 text-[11px]">Popular Quick Tests:</span>
          {['xm.com', 'binance.com', 'paypal.com', 'github.com', 'suspicious-login-update.top'].map((preset) => (
            <button
              key={preset}
              onClick={() => {
                onAuditDomain(preset);
                onNavigateTab('informant');
              }}
              className="text-[11px] font-mono px-2 py-0.5 rounded bg-white/5 hover:bg-white/10 text-white/70 hover:text-white border border-white/6 transition-colors"
            >
              {preset}
            </button>
          ))}
        </div>
      </div>

      {/* KPI Stats Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="bg-[#121316] border border-white/8 rounded-xl p-3.5 space-y-1">
          <div className="flex items-center justify-between text-white/50 text-xs">
            <span>Monitored Sites</span>
            <KeyRound className="w-4 h-4 text-[#8ab4f8]" />
          </div>
          <div className="text-2xl font-bold font-mono text-white tabular-nums">{vaultSites.length}</div>
          <div className="text-[11px] text-white/40 flex items-center gap-1">
            <span>In Breach Vault</span>
          </div>
        </div>

        <div className="bg-[#121316] border border-white/8 rounded-xl p-3.5 space-y-1">
          <div className="flex items-center justify-between text-white/50 text-xs">
            <span>Verified Safe</span>
            <ShieldCheck className="w-4 h-4 text-[#81c995]" />
          </div>
          <div className="text-2xl font-bold font-mono text-[#81c995] tabular-nums">{safeSites.length}</div>
          <div className="text-[11px] text-white/40">Clean in HIBP database</div>
        </div>

        <div className="bg-[#121316] border border-white/8 rounded-xl p-3.5 space-y-1">
          <div className="flex items-center justify-between text-white/50 text-xs">
            <span>Breached Sites</span>
            <ShieldAlert className="w-4 h-4 text-[#f28b82]" />
          </div>
          <div className="text-2xl font-bold font-mono text-[#f28b82] tabular-nums">{breachedSites.length}</div>
          <div className="text-[11px] text-[#f28b82]/80">Require password change</div>
        </div>

        <div
          onClick={() => onNavigateTab('blocker')}
          className="bg-[#121316] hover:bg-[#18191d] border border-white/8 hover:border-[#81c995]/30 rounded-xl p-3.5 space-y-1 cursor-pointer transition-colors"
        >
          <div className="flex items-center justify-between text-white/50 text-xs">
            <span>Trackers Blocked</span>
            <ShieldCheck className="w-4 h-4 text-[#81c995]" />
          </div>
          <div className="text-2xl font-bold font-mono text-[#81c995] tabular-nums">
            {trackerSettings.totalBlockedCount}
          </div>
          <div className="text-[11px] text-white/40 flex items-center justify-between">
            <span>{trackerSettings.enabled ? 'Shield: Active' : 'Shield: Paused'}</span>
            <span className="text-[#8ab4f8] text-[10px]">Manage →</span>
          </div>
        </div>
      </div>

      {/* Windows Advanced Defense Center Cards */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xs uppercase tracking-wider text-[#8ab4f8] font-semibold">
              Countermeasures & System Shields
            </span>
            <span className="text-white/20">·</span>
            <span className="text-[11px] text-white/40">Windows Real-Time Protections</span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          {/* Card 1: Malware Inspector */}
          <div
            onClick={() => onNavigateTab('malware')}
            className="p-4 bg-[#121316] hover:bg-[#18191d] border border-white/8 hover:border-[#f28b82]/40 rounded-xl cursor-pointer transition-all space-y-3 group"
          >
            <div className="flex items-center justify-between">
              <div className="w-8 h-8 rounded-lg bg-[#f28b82]/10 border border-[#f28b82]/20 flex items-center justify-center text-[#f28b82]">
                <Bug className="w-4 h-4" />
              </div>
              {malwareThreatCount > 0 ? (
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#f28b82]/20 text-[#f28b82] font-semibold border border-[#f28b82]/30">
                  {malwareThreatCount} Threat{malwareThreatCount > 1 ? 's' : ''}
                </span>
              ) : (
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#81c995]/20 text-[#81c995] font-semibold border border-[#81c995]/30">
                  System Clean
                </span>
              )}
            </div>
            <div>
              <h4 className="text-xs font-semibold text-white group-hover:text-[#8ab4f8] transition-colors">
                Malware & Spyware Inspector
              </h4>
              <p className="text-[11px] text-white/50 line-clamp-2 mt-0.5">
                Scan memory hooks, scheduled persistence tasks, trojan ports, and suspicious temporary binaries.
              </p>
            </div>
            <div className="text-[10px] text-[#8ab4f8] font-medium flex items-center gap-1 pt-1">
              <span>Inspect Device</span>
              <span>→</span>
            </div>
          </div>

          {/* Card 2: Scammer Detector */}
          <div
            onClick={() => onNavigateTab('scam')}
            className="p-4 bg-[#121316] hover:bg-[#18191d] border border-white/8 hover:border-[#fdd663]/40 rounded-xl cursor-pointer transition-all space-y-3 group"
          >
            <div className="flex items-center justify-between">
              <div className="w-8 h-8 rounded-lg bg-[#fdd663]/10 border border-[#fdd663]/20 flex items-center justify-center text-[#fdd663]">
                <UserX className="w-4 h-4" />
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#fdd663]/20 text-[#fdd663] font-semibold border border-[#fdd663]/30">
                {scamContactCount} Flagged
              </span>
            </div>
            <div>
              <h4 className="text-xs font-semibold text-white group-hover:text-[#8ab4f8] transition-colors">
                Scammer Contact Detector
              </h4>
              <p className="text-[11px] text-white/50 line-clamp-2 mt-0.5">
                Check suspicious phone numbers, VOIP throwaways, tech support fraud emails, and crypto wallets.
              </p>
            </div>
            <div className="text-[10px] text-[#8ab4f8] font-medium flex items-center gap-1 pt-1">
              <span>Analyze Contact</span>
              <span>→</span>
            </div>
          </div>

          {/* Card 3: Data Trace Shredder */}
          <div
            onClick={() => onNavigateTab('trace')}
            className="p-4 bg-[#121316] hover:bg-[#18191d] border border-white/8 hover:border-[#81c995]/40 rounded-xl cursor-pointer transition-all space-y-3 group"
          >
            <div className="flex items-center justify-between">
              <div className="w-8 h-8 rounded-lg bg-[#81c995]/10 border border-[#81c995]/20 flex items-center justify-center text-[#81c995]">
                <Flame className="w-4 h-4" />
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#81c995]/20 text-[#81c995] font-semibold border border-[#81c995]/30">
                {traceCount} Sites
              </span>
            </div>
            <div>
              <h4 className="text-xs font-semibold text-white group-hover:text-[#8ab4f8] transition-colors">
                Data Trace Shredder
              </h4>
              <p className="text-[11px] text-white/50 line-clamp-2 mt-0.5">
                Shred local session traces, flush Windows DNS cache, and draft formal GDPR Art. 17 erasure demands.
              </p>
            </div>
            <div className="text-[10px] text-[#8ab4f8] font-medium flex items-center gap-1 pt-1">
              <span>Purge & Erase</span>
              <span>→</span>
            </div>
          </div>

          {/* Card 4: Camera & Mic Shield */}
          <div
            onClick={() => onNavigateTab('privacy')}
            className="p-4 bg-[#121316] hover:bg-[#18191d] border border-white/8 hover:border-[#8ab4f8]/40 rounded-xl cursor-pointer transition-all space-y-3 group"
          >
            <div className="flex items-center justify-between">
              <div className="w-8 h-8 rounded-lg bg-[#8ab4f8]/10 border border-[#8ab4f8]/20 flex items-center justify-center text-[#8ab4f8]">
                <CameraOff className="w-4 h-4" />
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#8ab4f8]/20 text-[#8ab4f8] font-semibold border border-[#8ab4f8]/30">
                Hardware Guard
              </span>
            </div>
            <div>
              <h4 className="text-xs font-semibold text-white group-hover:text-[#8ab4f8] transition-colors">
                Sensor & Mic Killswitch
              </h4>
              <p className="text-[11px] text-white/50 line-clamp-2 mt-0.5">
                Hardware-level microphone and camera killswitches with unauthorized application access audit logging.
              </p>
            </div>
            <div className="text-[10px] text-[#8ab4f8] font-medium flex items-center gap-1 pt-1">
              <span>Sensor Controls</span>
              <span>→</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Split: Active Traffic Topology & Recent Audits */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Active Traffic Topology Snapshot */}
        <div className="lg:col-span-2 bg-[#121316] border border-white/8 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-semibold text-white">Live Data Detective Snapshot</h3>
              <p className="text-xs text-white/50">
                Active destination nodes mapped from outbound browser network requests
              </p>
            </div>
            <button
              onClick={() => onNavigateTab('detective')}
              className="text-xs text-[#8ab4f8] hover:underline flex items-center gap-1 font-medium"
            >
              <span>Full Interactive Canvas</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Scenario Selector */}
          <div className="flex flex-wrap gap-1.5 p-1 bg-[#18191d] rounded-lg border border-white/6">
            {TRAFFIC_PRESETS.map((p) => (
              <button
                key={p.id}
                onClick={() => onSelectPreset(p)}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                  activePreset.id === p.id
                    ? 'bg-white/10 text-white shadow-sm font-semibold'
                    : 'text-white/60 hover:text-white'
                }`}
              >
                {p.name.split(' (')[0]}
              </button>
            ))}
          </div>

          {/* Active Preset Summary */}
          <div className="p-3 bg-[#18191d] rounded-lg border border-white/6 flex items-center justify-between">
            <div className="space-y-0.5">
              <div className="text-xs font-semibold text-white flex items-center gap-2">
                <span>{activePreset.primaryDomain}</span>
                <span
                  className={`text-[10px] px-2 py-0.2 rounded-full font-mono ${
                    activePreset.protocol === 'https:'
                      ? 'bg-[#81c995]/15 text-[#81c995]'
                      : 'bg-[#f28b82]/15 text-[#f28b82]'
                  }`}
                >
                  {activePreset.protocol.toUpperCase()}
                </span>
              </div>
              <p className="text-[11px] text-white/50">{activePreset.description}</p>
            </div>
            <div className="text-right">
              <span className="text-xs font-mono font-semibold text-[#8ab4f8]">{activePreset.nodes.length}</span>
              <span className="text-[11px] text-white/40 block">Destinations</span>
            </div>
          </div>

          {/* Destination Nodes Chips */}
          <div className="space-y-1.5">
            <span className="text-[11px] font-semibold text-white/40 uppercase tracking-wider">
              Intercepted Destinations:
            </span>
            <div className="flex flex-wrap gap-1.5">
              {activePreset.nodes.map((node) => (
                <div
                  key={node.host}
                  className="px-2.5 py-1 bg-[#18191d] rounded border border-white/6 flex items-center gap-1.5 text-xs"
                >
                  <span
                    className="w-2 h-2 rounded-full"
                    style={{
                      backgroundColor:
                        node.category === 'Primary'
                          ? '#8ab4f8'
                          : node.category === 'Tracking'
                          ? '#fdd663'
                          : node.category === 'Auth'
                          ? '#55d6be'
                          : node.category === 'Service'
                          ? '#81c995'
                          : '#a0a2aa'
                    }}
                  ></span>
                  <span className="font-mono text-[11px] text-white/90">{node.host}</span>
                  <span className="text-[10px] text-white/40 font-mono">({node.count})</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right: Breach Alerts & Recent Scans */}
        <div className="space-y-6">
          {/* Breach Vault Summary Card */}
          <div className="bg-[#121316] border border-white/8 rounded-xl p-5 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                <KeyRound className="w-4 h-4 text-[#8ab4f8]" />
                <span>Vault Monitor</span>
              </h3>
              <button
                onClick={() => onNavigateTab('vault')}
                className="text-xs text-[#8ab4f8] hover:underline"
              >
                Manage
              </button>
            </div>

            {breachedSites.length > 0 ? (
              <div className="p-3 bg-[#f28b82]/10 border border-[#f28b82]/25 rounded-lg space-y-2">
                <div className="flex items-center gap-2 text-xs font-semibold text-[#f28b82]">
                  <ShieldAlert className="w-4 h-4 shrink-0" />
                  <span>{breachedSites.length} Monitored Site(s) Breached</span>
                </div>
                <p className="text-[11px] text-white/70">
                  Public breach catalogues list security incidents for:{' '}
                  <strong className="text-white font-mono">
                    {breachedSites.map((s) => s.domain).join(', ')}
                  </strong>
                </p>
                <button
                  onClick={() => onNavigateTab('vault')}
                  className="w-full py-1.5 bg-[#f28b82] hover:bg-[#ff9d94] text-black text-xs font-semibold rounded transition-colors text-center"
                >
                  View Remediation Steps
                </button>
              </div>
            ) : (
              <div className="p-3 bg-[#81c995]/10 border border-[#81c995]/25 rounded-lg text-xs text-[#81c995]">
                ✓ All monitored domains currently clear in known breach databases.
              </div>
            )}

            <div className="text-[11px] text-white/40 space-y-1">
              <div>• Domains saved automatically upon password form entry.</div>
              <div>• Password values are never read or transmitted.</div>
            </div>
          </div>

          {/* Recent Audits */}
          <div className="bg-[#121316] border border-white/8 rounded-xl p-5 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold text-white">Recent Audits</h3>
              <button
                onClick={() => onNavigateTab('informant')}
                className="text-xs text-[#8ab4f8] hover:underline"
              >
                Scan New
              </button>
            </div>

            <div className="space-y-2">
              {recentAudits.map((item) => (
                <div
                  key={item.domain}
                  onClick={() => {
                    onAuditDomain(item.domain);
                    onNavigateTab('informant');
                  }}
                  className="p-2.5 bg-[#18191d] hover:bg-[#202127] border border-white/6 rounded-lg flex items-center justify-between cursor-pointer transition-colors"
                >
                  <div className="space-y-0.5">
                    <div className="text-xs font-mono font-medium text-white">{item.domain}</div>
                    <div className="text-[10px] text-white/40">{item.category}</div>
                  </div>
                  <div>
                    {item.isThreat ? (
                      <span className="text-[10px] px-2 py-0.5 rounded bg-[#f28b82]/20 text-[#f28b82] font-semibold border border-[#f28b82]/30">
                        Threat
                      </span>
                    ) : (
                      <span className="text-[10px] px-2 py-0.5 rounded bg-[#81c995]/20 text-[#81c995] font-semibold border border-[#81c995]/30">
                        Clean
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
