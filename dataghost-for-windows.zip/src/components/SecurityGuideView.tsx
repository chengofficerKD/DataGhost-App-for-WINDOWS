import React from 'react';
import {
  ShieldCheck,
  KeyRound,
  Lock,
  Globe,
  CheckCircle2,
  AlertTriangle,
  ExternalLink,
  Laptop
} from 'lucide-react';

export const SecurityGuideView: React.FC = () => {
  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-[#0d0e11] text-[#f2f3f5]">
      {/* Header */}
      <div className="space-y-1">
        <div className="flex items-center gap-2">
          <span className="text-xs uppercase tracking-wider text-[#8ab4f8] font-semibold">
            Windows Security & Privacy
          </span>
          <span className="text-white/20">·</span>
          <span className="text-xs text-white/50">User Guide</span>
        </div>
        <h2 className="text-xl font-bold tracking-tight text-white">
          Practical Windows Privacy & Security Playbook
        </h2>
        <p className="text-xs text-white/60">
          User-friendly tips and configuration steps to harden your Windows PC against credential leaks and tracking.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Guide 1: Windows 11 DNS-over-HTTPS */}
        <div className="bg-[#121316] border border-white/8 rounded-xl p-5 space-y-3">
          <div className="flex items-center gap-2.5 text-[#8ab4f8]">
            <Globe className="w-5 h-5" />
            <h3 className="text-sm font-bold text-white">1. Enable Native DNS-over-HTTPS in Windows 11</h3>
          </div>
          <p className="text-xs text-white/70 leading-relaxed">
            By default, your Windows PC sends unencrypted DNS queries to your internet service provider.
            Windows 11 supports native encrypted DNS:
          </p>
          <div className="p-3 bg-[#18191d] rounded-lg border border-white/6 font-mono text-[11px] text-white/80 space-y-1">
            <div>1. Open Windows <strong>Settings</strong> (Win + I)</div>
            <div>2. Go to <strong>Network & internet</strong> → <strong>Wi-Fi</strong> or <strong>Ethernet</strong></div>
            <div>3. Click <strong>Hardware properties</strong> → Edit <strong>DNS server assignment</strong></div>
            <div>4. Switch to <strong>Manual</strong> → IPv4 On</div>
            <div>5. Set Preferred DNS: <strong>1.1.1.3</strong> (Cloudflare Security with malware blocking)</div>
            <div>6. Set DNS encryption: <strong>Encrypted only (DNS over HTTPS)</strong></div>
          </div>
        </div>

        {/* Guide 2: Windows Hello & Passkeys */}
        <div className="bg-[#121316] border border-white/8 rounded-xl p-5 space-y-3">
          <div className="flex items-center gap-2.5 text-[#55d6be]">
            <KeyRound className="w-5 h-5" />
            <h3 className="text-sm font-bold text-white">2. Replace Reused Passwords with Windows Passkeys</h3>
          </div>
          <p className="text-xs text-white/70 leading-relaxed">
            Passkeys use public-key cryptography stored securely in your Windows TPM chip. Passkeys cannot be
            phished because they are cryptographically tied to the verified domain name.
          </p>
          <ul className="space-y-1.5 text-xs text-white/80">
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#81c995] shrink-0 mt-0.5" />
              <span>Enable Windows Hello PIN or Biometrics in Windows Settings → Accounts.</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#81c995] shrink-0 mt-0.5" />
              <span>On supported sites (Google, GitHub, PayPal, Microsoft), select "Create a passkey".</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#81c995] shrink-0 mt-0.5" />
              <span>Windows saves the passkey locally — no password to memorize or leak.</span>
            </li>
          </ul>
        </div>

        {/* Guide 3: What to do when a site is breached */}
        <div className="bg-[#121316] border border-white/8 rounded-xl p-5 space-y-3">
          <div className="flex items-center gap-2.5 text-[#fdd663]">
            <AlertTriangle className="w-5 h-5" />
            <h3 className="text-sm font-bold text-white">3. What to Do If a Site in Vault is Breached</h3>
          </div>
          <p className="text-xs text-white/70 leading-relaxed">
            DataGhost monitors your domains against public records. When a breach is listed:
          </p>
          <div className="space-y-2 text-xs text-white/80">
            <div className="p-2.5 bg-[#18191d] rounded-lg border border-white/6">
              <strong className="text-white block">Step 1: Check Password Reuse</strong>
              <span className="text-white/60 text-[11px]">
                The biggest risk is credential stuffing: attackers taking credentials from one breached site
                and trying them on your email or banking accounts.
              </span>
            </div>
            <div className="p-2.5 bg-[#18191d] rounded-lg border border-white/6">
              <strong className="text-white block">Step 2: Change Password & Activate 2FA</strong>
              <span className="text-white/60 text-[11px]">
                Use a unique, randomized password generated by a trusted manager (Bitwarden, 1Password, or Edge/Chrome).
              </span>
            </div>
          </div>
        </div>

        {/* Guide 4: How DataGhost Protects Privacy */}
        <div className="bg-[#121316] border border-white/8 rounded-xl p-5 space-y-3">
          <div className="flex items-center gap-2.5 text-[#81c995]">
            <ShieldCheck className="w-5 h-5" />
            <h3 className="text-sm font-bold text-white">4. DataGhost Privacy Invariants</h3>
          </div>
          <p className="text-xs text-white/70 leading-relaxed">
            DataGhost is built with privacy-first engineering principles:
          </p>
          <ul className="space-y-2 text-xs text-white/80">
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#81c995] shrink-0 mt-0.5" />
              <span><strong>Zero Password Reading:</strong> We only track hostnames (e.g. netflix.com). Password input fields and contents are never accessed.</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#81c995] shrink-0 mt-0.5" />
              <span><strong>Local Storage:</strong> All vault sites and preferences are stored locally on your machine.</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle2 className="w-4 h-4 text-[#81c995] shrink-0 mt-0.5" />
              <span><strong>Local Breach Matching:</strong> The public breach catalogue is downloaded and compared locally; your list of sites is not sent to external servers.</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};
