import React, { useState } from 'react';
import {
  KeyRound,
  ShieldCheck,
  ShieldAlert,
  Plus,
  RefreshCw,
  ExternalLink,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  Download,
  Info,
  X,
  Lock,
  ChevronRight,
  Filter
} from 'lucide-react';
import { BreachRecord, VaultSite } from '../types';

interface BreachVaultViewProps {
  vaultSites: VaultSite[];
  onAddSite: (domain: string) => Promise<{ success: boolean; message: string }>;
  onCheckAll: () => Promise<void>;
  onRemoveSite: (domain: string) => void;
  isChecking: boolean;
}

export const BreachVaultView: React.FC<BreachVaultViewProps> = ({
  vaultSites,
  onAddSite,
  onCheckAll,
  onRemoveSite,
  isChecking
}) => {
  const [inputDomain, setInputDomain] = useState('');
  const [filterMode, setFilterMode] = useState<'all' | 'breached' | 'safe'>('all');
  const [selectedBreachedSite, setSelectedBreachedSite] = useState<VaultSite | null>(null);
  const [actionFeedback, setActionFeedback] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const breachedSites = vaultSites.filter((s) => s.status === 'breached');
  const safeSites = vaultSites.filter((s) => s.status === 'safe');

  const filteredSites = vaultSites.filter((s) => {
    if (filterMode === 'breached') return s.status === 'breached';
    if (filterMode === 'safe') return s.status === 'safe';
    return true;
  });

  const handleAddSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputDomain.trim()) return;

    setIsSubmitting(true);
    setActionFeedback('Verifying domain syntax and public DNS...');
    const result = await onAddSite(inputDomain.trim());
    setIsSubmitting(false);

    if (result.success) {
      setInputDomain('');
      setActionFeedback(`✓ ${result.message}`);
    } else {
      setActionFeedback(`⚠️ ${result.message}`);
    }

    setTimeout(() => setActionFeedback(null), 5000);
  };

  const exportVaultReport = () => {
    const reportData = vaultSites.map((s) => ({
      domain: s.domain,
      status: s.status,
      type: s.autoDetected ? 'AUTO_DETECTED' : 'MANUAL',
      lastChecked: s.lastChecked ? new Date(s.lastChecked).toISOString() : 'Never',
      breachesCount: s.breaches.length,
      breachesList: s.breaches.map((b) => b.title || b.name).join('; ')
    }));

    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `dataghost-vault-report-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-[#0d0e11] text-[#f2f3f5]">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="text-xs uppercase tracking-wider text-[#8ab4f8] font-semibold">
              Breach Vault
            </span>
            <span className="text-white/20">·</span>
            <span className="text-xs text-white/50">Password Site Monitor</span>
          </div>
          <h2 className="text-xl font-bold tracking-tight text-white">Monitored Account Domains</h2>
          <p className="text-xs text-white/60">
            Stores site domains only. Password values are never read or stored. Cross-referenced against
            Have I Been Pwned public breach records.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={exportVaultReport}
            className="px-3 py-2 bg-white/5 hover:bg-white/10 text-white text-xs font-medium rounded-lg border border-white/10 transition-colors flex items-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Report</span>
          </button>
          <button
            onClick={onCheckAll}
            disabled={isChecking}
            className="px-3.5 py-2 bg-[#8ab4f8] hover:bg-[#aecbfa] text-black text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isChecking ? 'animate-spin' : ''}`} />
            <span>{isChecking ? 'Scanning Catalog...' : 'Check All Sites Now'}</span>
          </button>
        </div>
      </div>

      {/* Breach Alert Banner */}
      {breachedSites.length > 0 && (
        <div className="bg-[#f28b82]/10 border border-[#f28b82]/30 rounded-xl p-4 flex items-start gap-3.5">
          <div className="w-8 h-8 rounded-lg bg-[#f28b82]/20 flex items-center justify-center text-[#f28b82] shrink-0 mt-0.5">
            <ShieldAlert className="w-4 h-4" />
          </div>
          <div className="space-y-1 flex-1">
            <h4 className="text-xs font-bold text-[#f28b82] uppercase tracking-wider">
              {breachedSites.length} Known Site Breach{breachedSites.length > 1 ? 'es' : ''} Detected
            </h4>
            <p className="text-xs text-white/80 leading-relaxed">
              Public security disclosures record historical data breaches for:{' '}
              <strong className="text-white font-mono">
                {breachedSites.map((s) => s.domain).join(', ')}
              </strong>
              . If you have active accounts on these services, review credentials and ensure passwords are not reused elsewhere.
            </p>
          </div>
        </div>
      )}

      {/* Add Domain Bar */}
      <div className="bg-[#121316] border border-white/8 rounded-xl p-4 space-y-2">
        <span className="text-xs font-semibold text-white/80 block">
          Add Site to Vault Monitoring
        </span>
        <form onSubmit={handleAddSubmit} className="flex gap-2">
          <div className="relative flex-1">
            <input
              type="text"
              value={inputDomain}
              onChange={(e) => setInputDomain(e.target.value)}
              placeholder="e.g. netflix.com, github.com, or adobe.com"
              className="w-full h-10 bg-[#0d0e11] border border-white/10 rounded-lg px-3.5 text-xs text-white font-mono placeholder:text-white/30 focus:outline-none focus:border-[#8ab4f8] transition-colors"
            />
          </div>
          <button
            type="submit"
            disabled={isSubmitting}
            className="h-10 px-5 bg-[#8ab4f8] hover:bg-[#aecbfa] text-black text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 disabled:opacity-50"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Domain</span>
          </button>
        </form>

        {actionFeedback && (
          <div className="text-xs text-[#8ab4f8] pt-1 flex items-center gap-1.5 font-mono">
            <Info className="w-3.5 h-3.5" />
            <span>{actionFeedback}</span>
          </div>
        )}
      </div>

      {/* Monitored Sites Header & Filters */}
      <div className="flex items-center justify-between pt-2">
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold uppercase tracking-wider text-white/60">
            Monitored Sites
          </span>
          <span className="text-xs font-mono text-white/40">({filteredSites.length})</span>
        </div>

        <div className="flex items-center gap-1 p-1 bg-[#121316] rounded-lg border border-white/8 text-xs">
          <button
            onClick={() => setFilterMode('all')}
            className={`px-2.5 py-1 rounded transition-colors ${
              filterMode === 'all' ? 'bg-white/10 text-white font-semibold' : 'text-white/50 hover:text-white'
            }`}
          >
            All ({vaultSites.length})
          </button>
          <button
            onClick={() => setFilterMode('breached')}
            className={`px-2.5 py-1 rounded transition-colors ${
              filterMode === 'breached'
                ? 'bg-[#f28b82]/20 text-[#f28b82] font-semibold'
                : 'text-white/50 hover:text-white'
            }`}
          >
            Breached ({breachedSites.length})
          </button>
          <button
            onClick={() => setFilterMode('safe')}
            className={`px-2.5 py-1 rounded transition-colors ${
              filterMode === 'safe'
                ? 'bg-[#81c995]/20 text-[#81c995] font-semibold'
                : 'text-white/50 hover:text-white'
            }`}
          >
            Clean ({safeSites.length})
          </button>
        </div>
      </div>

      {/* Sites List */}
      <div className="space-y-2.5">
        {filteredSites.map((site) => {
          const isBreached = site.status === 'breached';
          const isSafe = site.status === 'safe';
          const isCheckingSite = site.status === 'checking';

          return (
            <div
              key={site.domain}
              className={`p-4 rounded-xl border transition-all flex flex-col md:flex-row md:items-center justify-between gap-3 ${
                isBreached
                  ? 'bg-[#18191d] border-[#f28b82]/30 hover:border-[#f28b82]/50'
                  : 'bg-[#121316] border-white/8 hover:border-white/15'
              }`}
            >
              <div className="flex items-start gap-3 min-w-0">
                <div
                  className={`w-3 h-3 rounded-full mt-1.5 shrink-0 ${
                    isCheckingSite
                      ? 'bg-white/40 animate-pulse'
                      : isBreached
                      ? 'bg-[#f28b82]'
                      : isSafe
                      ? 'bg-[#81c995]'
                      : 'bg-white/30'
                  }`}
                ></div>

                <div className="space-y-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-mono font-bold text-white truncate">
                      {site.domain}
                    </span>
                    <span
                      className={`text-[9px] px-1.5 py-0.2 rounded font-semibold uppercase ${
                        site.autoDetected
                          ? 'bg-[#8ab4f8]/15 text-[#8ab4f8]'
                          : 'bg-white/10 text-white/60'
                      }`}
                    >
                      {site.autoDetected ? 'AUTO' : 'MANUAL'}
                    </span>
                  </div>

                  <div className="text-xs text-white/60">
                    {isCheckingSite ? (
                      <span className="text-white/40">Checking breach database...</span>
                    ) : isBreached ? (
                      <span className="text-[#f28b82] font-medium">
                        {site.breaches.length} verified site breach
                        {site.breaches.length > 1 ? 'es' : ''} listed in HIBP database
                      </span>
                    ) : isSafe ? (
                      <span className="text-[#81c995]">No verified site breach listed</span>
                    ) : (
                      <span className="text-white/40">Scheduled for routine check</span>
                    )}
                  </div>

                  {/* Breach Chips */}
                  {isBreached && site.breaches.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 pt-1">
                      {site.breaches.map((b) => (
                        <span
                          key={b.name}
                          className="text-[10px] px-2 py-0.5 rounded bg-[#f28b82]/15 text-[#f28b82] border border-[#f28b82]/25 font-mono"
                        >
                          {b.title || b.name} ({b.breachDate.split('-')[0]})
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 shrink-0 self-end md:self-center">
                {isBreached && (
                  <button
                    onClick={() => setSelectedBreachedSite(site)}
                    className="px-3 py-1.5 bg-[#f28b82]/20 hover:bg-[#f28b82]/30 text-[#f28b82] text-xs font-semibold rounded-lg border border-[#f28b82]/30 transition-colors flex items-center gap-1"
                  >
                    <span>Remediate</span>
                    <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                )}
                <a
                  href={`https://${site.domain}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-1.5 hover:bg-white/10 text-white/40 hover:text-white rounded transition-colors"
                  title="Visit Website"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
                <button
                  onClick={() => onRemoveSite(site.domain)}
                  className="p-1.5 hover:bg-white/10 text-white/40 hover:text-[#f28b82] rounded transition-colors"
                  title="Remove from Vault"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Breach Remediation Modal */}
      {selectedBreachedSite && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#18191d] border border-white/15 rounded-xl max-w-lg w-full p-5 space-y-4 shadow-2xl animate-in zoom-in-95 duration-150">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-[#f28b82]">
                  Security Incident Report
                </span>
                <h3 className="text-base font-bold text-white font-mono">
                  {selectedBreachedSite.domain}
                </h3>
              </div>
              <button
                onClick={() => setSelectedBreachedSite(null)}
                className="text-white/40 hover:text-white p-1 rounded"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3">
              {selectedBreachedSite.breaches.map((b) => (
                <div key={b.name} className="p-3 bg-[#121316] rounded-lg border border-white/8 space-y-1.5 text-xs">
                  <div className="flex justify-between font-semibold text-white">
                    <span>{b.title || b.name}</span>
                    <span className="text-white/40 font-mono">{b.breachDate}</span>
                  </div>
                  <p className="text-white/70 text-[11px] leading-relaxed">
                    {b.description || 'Breach recorded in security database.'}
                  </p>
                  {b.dataClasses && (
                    <div className="pt-1">
                      <span className="text-[10px] text-white/40 block mb-1">Compromised Data:</span>
                      <div className="flex flex-wrap gap-1">
                        {b.dataClasses.map((dc) => (
                          <span
                            key={dc}
                            className="text-[9px] px-1.5 py-0.2 rounded bg-white/5 text-white/70 border border-white/6"
                          >
                            {dc}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>

            <div className="p-3 bg-[#f28b82]/10 border border-[#f28b82]/20 rounded-lg space-y-1.5 text-xs">
              <strong className="text-[#f28b82] block">Recommended Action Checklist:</strong>
              <ol className="list-decimal pl-4 space-y-1 text-white/80 text-[11px]">
                <li>Change your password for this service immediately.</li>
                <li>If you reused this password on any other service, change those immediately as well.</li>
                <li>Enable Two-Factor Authentication (2FA / Windows Hello / Authenticator App).</li>
              </ol>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setSelectedBreachedSite(null)}
                className="px-4 py-2 bg-white/10 hover:bg-white/15 text-white text-xs font-medium rounded-lg transition-colors"
              >
                Close
              </button>
              <a
                href={`https://${selectedBreachedSite.domain}`}
                target="_blank"
                rel="noopener noreferrer"
                className="px-4 py-2 bg-[#8ab4f8] hover:bg-[#aecbfa] text-black text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5"
              >
                <span>Visit {selectedBreachedSite.domain}</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
