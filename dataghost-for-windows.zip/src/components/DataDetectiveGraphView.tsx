import React, { useRef, useEffect, useState } from 'react';
import {
  RotateCcw,
  ZoomIn,
  ZoomOut,
  X,
  Filter,
  Lock,
  LockOpen,
  Send,
  Network,
  Activity,
  ChevronDown,
  Layers,
  ShieldCheck,
  ShieldAlert,
  ExternalLink,
  Ban,
  CheckCircle2
} from 'lucide-react';
import { DomainCategory, GraphConnection, GraphNode, DataPulse, TrafficPreset, PostRequest, TrackerShieldSettings } from '../types';
import { CATEGORY_COLORS, TRAFFIC_PRESETS } from '../services/trafficSimulator';
import { isDomainBlocked } from '../services/trackerBlockerService';

interface DataDetectiveGraphViewProps {
  activePreset: TrafficPreset;
  onSelectPreset: (preset: TrafficPreset) => void;
  onAuditDomain: (domain: string) => void;
  onNavigateTab: (tab: 'dashboard' | 'informant' | 'detective' | 'vault' | 'inspector' | 'guide' | 'blocker') => void;
  trackerSettings: TrackerShieldSettings;
  onToggleBlockDomain: (domain: string) => void;
  onToggleTrackerShield: () => void;
}

export const DataDetectiveGraphView: React.FC<DataDetectiveGraphViewProps> = ({
  activePreset,
  onSelectPreset,
  onAuditDomain,
  onNavigateTab,
  trackerSettings,
  onToggleBlockDomain,
  onToggleTrackerShield
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // View mode: 'map' (uncluttered full canvas) or 'stream' (clean request log)
  const [viewMode, setViewMode] = useState<'map' | 'stream'>('map');

  // Graph state
  const [nodes, setNodes] = useState<GraphNode[]>([]);
  const [connections, setConnections] = useState<GraphConnection[]>([]);
  const [pulses, setPulses] = useState<DataPulse[]>([]);
  const [selectedNode, setSelectedNode] = useState<GraphNode | null>(null);
  const [hoveredNode, setHoveredNode] = useState<GraphNode | null>(null);

  // Filter dropdown state
  const [showFilterMenu, setShowFilterMenu] = useState(false);
  const [activeCategories, setActiveCategories] = useState<Record<DomainCategory, boolean>>({
    Primary: true,
    Auth: true,
    Tracking: true,
    API: true,
    Service: true,
    Analytics: true,
    Essential: true,
    Unknown: true
  });

  // Canvas Transform (Pan & Zoom)
  const [scale, setScale] = useState(1.0);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const isDraggingRef = useRef(false);
  const dragStartRef = useRef({ x: 0, y: 0 });

  // Outbound posts from preset, annotated with tracker shield blocking
  const posts: PostRequest[] = activePreset.posts.map((p, i) => {
    const isBlocked = isDomainBlocked(p.host, p.category, trackerSettings);
    return {
      id: `post_${i}`,
      timestamp: Date.now() - (i + 1) * 3500,
      url: `${activePreset.protocol}//${p.host}${p.path}`,
      host: p.host,
      path: p.path,
      method: 'POST',
      isSecure: p.isSecure,
      category: p.category,
      payloadType: isBlocked ? 'Blocked (0 bytes transmitted)' : p.payloadType,
      riskAlert: isBlocked ? 'Blocked by Tracker Shield' : (!p.isSecure ? 'Plaintext Form / Credential Leak' : null),
      isBlocked
    };
  });

  // Layout calculation
  useEffect(() => {
    if (!canvasRef.current) return;
    const canvas = canvasRef.current;
    const rect = canvas.getBoundingClientRect();
    const cx = rect.width / 2;
    const cy = rect.height / 2;

    const primaryHost = activePreset.primaryDomain;
    const newNodes: GraphNode[] = [];
    const newConnections: GraphConnection[] = [];

    // 1. Center Primary Hub Node
    const primaryNode: GraphNode = {
      id: primaryHost,
      host: primaryHost,
      category: 'Primary',
      count: 24,
      isSecure: activePreset.protocol === 'https:',
      isPrimary: true,
      x: cx,
      y: cy,
      radius: 17,
      color: CATEGORY_COLORS['Primary'],
      isBlocked: false
    };
    newNodes.push(primaryNode);

    // 2. Surrounding Destination Nodes
    const otherNodes = activePreset.nodes.filter((n) => n.host !== primaryHost);
    const count = otherNodes.length;
    const minDim = Math.min(rect.width, rect.height);
    const baseDist = Math.max(100, Math.min(220, minDim * 0.38));

    otherNodes.forEach((n, i) => {
      const angle = (i / Math.max(1, count)) * Math.PI * 2 - Math.PI / 2;
      const dist = baseDist + (i % 2) * 35;
      const isBlocked = isDomainBlocked(n.host, n.category, trackerSettings);
      const color = isBlocked ? '#f28b82' : (CATEGORY_COLORS[n.category] || CATEGORY_COLORS['Unknown']);

      const node: GraphNode = {
        id: n.host,
        host: n.host,
        category: n.category,
        count: n.count,
        isSecure: n.isSecure,
        isPrimary: false,
        x: cx + Math.cos(angle) * dist,
        y: cy + Math.sin(angle) * dist,
        radius: Math.min(13, 6 + Math.log2(n.count || 1) * 1.8),
        color,
        isBlocked
      };
      newNodes.push(node);
    });

    // 3. Connections
    activePreset.connections.forEach((c) => {
      const destNode = newNodes.find((n) => n.host === c.to);
      const isBlocked = destNode?.isBlocked || false;
      newConnections.push({
        key: `${c.from}->${c.to}`,
        from: c.from,
        to: c.to,
        category: c.category,
        count: 1,
        isSecure: activePreset.protocol === 'https:',
        color: isBlocked ? 'rgba(242, 139, 130, 0.25)' : (CATEGORY_COLORS[c.category] || CATEGORY_COLORS['Unknown']),
        isBlocked
      });
    });

    setNodes(newNodes);
    setConnections(newConnections);

    // If selected node exists, update its blocked status
    if (selectedNode) {
      const updatedSel = newNodes.find((n) => n.host === selectedNode.host);
      if (updatedSel) setSelectedNode(updatedSel);
    }
  }, [activePreset, trackerSettings]);

  // Gentle packet pulses (only along unblocked connections)
  useEffect(() => {
    const pulseInterval = setInterval(() => {
      if (nodes.length < 2 || connections.length === 0 || viewMode !== 'map') return;
      const activeConnections = connections.filter((c) => !c.isBlocked);
      if (activeConnections.length === 0) return;

      const randomConn = activeConnections[Math.floor(Math.random() * activeConnections.length)];
      const source = nodes.find((n) => n.host === randomConn.from);
      const dest = nodes.find((n) => n.host === randomConn.to);

      if (source && dest && !dest.isBlocked) {
        setPulses((prev) => [
          ...prev.slice(-6),
          {
            fromX: source.x,
            fromY: source.y,
            toX: dest.x,
            toY: dest.y,
            progress: 0,
            speed: 0.016 + Math.random() * 0.008,
            color: dest.color
          }
        ]);
      }
    }, 700);

    return () => clearInterval(pulseInterval);
  }, [nodes, connections, viewMode]);

  // 60fps Clean Vector Canvas Render Loop
  useEffect(() => {
    if (viewMode !== 'map') return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;

    const render = () => {
      const dpr = window.devicePixelRatio || 1;
      const rect = canvas.getBoundingClientRect();

      if (
        canvas.width !== Math.round(rect.width * dpr) ||
        canvas.height !== Math.round(rect.height * dpr)
      ) {
        canvas.width = Math.round(rect.width * dpr);
        canvas.height = Math.round(rect.height * dpr);
      }

      // 1. Clear Hardware Buffer cleanly
      ctx.save();
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.restore();

      // 2. Set coordinate transform
      ctx.save();
      ctx.scale(dpr, dpr);
      ctx.translate(pan.x, pan.y);
      ctx.scale(scale, scale);

      // Visible nodes map
      const visibleNodesMap = new Map<string, GraphNode>();
      nodes.forEach((n) => {
        if (activeCategories[n.category]) {
          visibleNodesMap.set(n.host, n);
        }
      });

      // 3. Draw Connections
      connections.forEach((c) => {
        const fromNode = visibleNodesMap.get(c.from);
        const toNode = visibleNodesMap.get(c.to);
        if (!fromNode || !toNode) return;

        ctx.beginPath();
        ctx.moveTo(fromNode.x, fromNode.y);
        ctx.lineTo(toNode.x, toNode.y);

        if (c.isBlocked) {
          // Blocked connection: dashed muted line
          ctx.setLineDash([3, 4]);
          ctx.strokeStyle = 'rgba(242, 139, 130, 0.28)';
          ctx.lineWidth = 1;
        } else {
          ctx.setLineDash([]);
          ctx.strokeStyle = c.color || 'rgba(255, 255, 255, 0.1)';
          ctx.globalAlpha = 0.22;
          ctx.lineWidth = 1;
        }
        ctx.stroke();
        ctx.setLineDash([]);
        ctx.globalAlpha = 1.0;
      });

      // 4. Draw Traveling Data Pulses (Only for unblocked routes)
      pulses.forEach((p) => {
        p.progress += p.speed;
        if (p.progress <= 1.0) {
          const px = p.fromX + (p.toX - p.fromX) * p.progress;
          const py = p.fromY + (p.toY - p.fromY) * p.progress;

          ctx.beginPath();
          ctx.arc(px, py, 2, 0, Math.PI * 2);
          ctx.shadowColor = p.color;
          ctx.shadowBlur = 6;
          ctx.fillStyle = p.color;
          ctx.fill();
          ctx.shadowBlur = 0;
        }
      });

      // 5. Draw Hub Concentric Ring for Primary Host
      const hubNode = nodes.find((n) => n.isPrimary);
      if (hubNode && visibleNodesMap.has(hubNode.host)) {
        ctx.beginPath();
        ctx.arc(hubNode.x, hubNode.y, hubNode.radius + 6, 0, Math.PI * 2);
        ctx.strokeStyle = 'rgba(138, 180, 248, 0.2)';
        ctx.lineWidth = 1;
        ctx.stroke();
      }

      // 6. Draw Nodes & Labels
      visibleNodesMap.forEach((n) => {
        const isHover = hoveredNode?.host === n.host;
        const isSelected = selectedNode?.host === n.host;

        // Selection / Hover Ring
        if (isHover || isSelected) {
          ctx.beginPath();
          ctx.arc(n.x, n.y, n.radius + 4, 0, Math.PI * 2);
          ctx.fillStyle = n.isBlocked ? 'rgba(242, 139, 130, 0.1)' : 'rgba(255, 255, 255, 0.08)';
          ctx.fill();
          ctx.strokeStyle = isSelected ? '#ffffff' : (n.isBlocked ? 'rgba(242, 139, 130, 0.5)' : 'rgba(255, 255, 255, 0.3)');
          ctx.lineWidth = 1;
          ctx.stroke();
        }

        // Node Circle
        ctx.beginPath();
        ctx.arc(n.x, n.y, n.radius, 0, Math.PI * 2);
        ctx.shadowColor = n.isBlocked ? '#f28b82' : n.color;
        ctx.shadowBlur = isHover || isSelected ? 12 : 5;
        ctx.fillStyle = n.isBlocked ? '#f28b82' : n.color;
        ctx.fill();
        ctx.shadowBlur = 0;

        // If blocked, draw a small inner shield cross
        if (n.isBlocked) {
          ctx.beginPath();
          ctx.moveTo(n.x - 3, n.y - 3);
          ctx.lineTo(n.x + 3, n.y + 3);
          ctx.moveTo(n.x + 3, n.y - 3);
          ctx.lineTo(n.x - 3, n.y + 3);
          ctx.strokeStyle = '#0d0e11';
          ctx.lineWidth = 1.5;
          ctx.stroke();
        }

        // Node Label
        ctx.font = '500 11px "JetBrains Mono", monospace';
        ctx.fillStyle = n.isBlocked
          ? 'rgba(242, 139, 130, 0.85)'
          : (isHover || isSelected ? '#ffffff' : 'rgba(235, 235, 245, 0.65)');
        ctx.textAlign = 'left';
        ctx.fillText(
          n.isBlocked ? `${n.host} [BLOCKED]` : n.host,
          n.x + n.radius + 7,
          n.y + 3.5
        );
      });

      ctx.restore();
      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, [nodes, connections, pulses, pan, scale, hoveredNode, selectedNode, activeCategories, viewMode]);

  // Mouse Interactions for Pan & Zoom
  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    isDraggingRef.current = true;
    dragStartRef.current = { x: e.clientX - pan.x, y: e.clientY - pan.y };
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    if (isDraggingRef.current) {
      setPan({
        x: e.clientX - dragStartRef.current.x,
        y: e.clientY - dragStartRef.current.y
      });
    }

    const rect = canvas.getBoundingClientRect();
    const mouseX = (e.clientX - rect.left - pan.x) / scale;
    const mouseY = (e.clientY - rect.top - pan.y) / scale;

    let found: GraphNode | null = null;
    for (const n of nodes) {
      if (!activeCategories[n.category]) continue;
      const dx = n.x - mouseX;
      const dy = n.y - mouseY;
      if (Math.sqrt(dx * dx + dy * dy) < n.radius + 6) {
        found = n;
        break;
      }
    }
    setHoveredNode(found);
  };

  const handleMouseUp = () => {
    isDraggingRef.current = false;
  };

  const handleCanvasClick = () => {
    if (hoveredNode) {
      setSelectedNode(hoveredNode);
    } else {
      setSelectedNode(null);
    }
  };

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const factor = 1.08;
    if (e.deltaY < 0) {
      setScale((s) => Math.min(2.5, s * factor));
    } else {
      setScale((s) => Math.max(0.4, s / factor));
    }
  };

  const toggleCategory = (cat: DomainCategory) => {
    setActiveCategories((prev) => ({ ...prev, [cat]: !prev[cat] }));
  };

  const blockedCount = nodes.filter((n) => n.isBlocked).length;

  return (
    <div className="flex-1 flex flex-col overflow-hidden bg-[#0d0e11] text-[#f2f3f5] h-full">
      {/* ── Minimalist Clean Header Bar ── */}
      <div className="h-12 bg-[#121316] border-b border-white/8 px-4 flex items-center justify-between shrink-0 select-none z-20">
        {/* Left: Active Host Info */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#8ab4f8]"></span>
            <span className="text-xs font-semibold text-white font-mono">
              {activePreset.primaryDomain}
            </span>
            <span
              className={`text-[9px] px-1.5 py-0.2 rounded font-mono font-medium ${
                activePreset.protocol === 'https:'
                  ? 'bg-[#81c995]/15 text-[#81c995]'
                  : 'bg-[#f28b82]/15 text-[#f28b82]'
              }`}
            >
              {activePreset.protocol.toUpperCase()}
            </span>
          </div>

          <span className="text-white/20">|</span>

          {/* Quick Telemetry Counts */}
          <div className="flex items-center gap-2 text-xs font-mono text-white/50">
            <span>
              <strong className="text-white font-semibold">{nodes.length}</strong> nodes
            </span>
            <span>·</span>
            <span>
              <strong className="text-white font-semibold">{connections.length}</strong> links
            </span>
          </div>
        </div>

        {/* Center: Clean Segmented View Mode Toggle */}
        <div className="flex items-center p-0.5 bg-[#18191d] rounded-lg border border-white/6 text-xs">
          <button
            onClick={() => setViewMode('map')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-md transition-colors font-medium ${
              viewMode === 'map'
                ? 'bg-white/10 text-white font-semibold shadow-sm'
                : 'text-white/50 hover:text-white'
            }`}
          >
            <Network className="w-3.5 h-3.5" />
            <span>Brain Map</span>
          </button>
          <button
            onClick={() => setViewMode('stream')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-md transition-colors font-medium ${
              viewMode === 'stream'
                ? 'bg-white/10 text-white font-semibold shadow-sm'
                : 'text-white/50 hover:text-white'
            }`}
          >
            <Send className="w-3.5 h-3.5" />
            <span>Outbound Streams ({posts.length})</span>
          </button>
        </div>

        {/* Right: Tracker Shield Toggle, Scenario & View Controls */}
        <div className="flex items-center gap-2">
          {/* Tracker Shield Quick Button */}
          <button
            onClick={onToggleTrackerShield}
            title={trackerSettings.enabled ? 'Tracker Shield Active (Click to Pause)' : 'Tracker Shield Paused (Click to Enable)'}
            className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-semibold rounded-lg border transition-colors ${
              trackerSettings.enabled
                ? 'bg-[#81c995]/15 border-[#81c995]/30 text-[#81c995]'
                : 'bg-white/5 border-white/10 text-white/50 hover:text-white'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>{trackerSettings.enabled ? `Shield: ${blockedCount} Blocked` : 'Shield: OFF'}</span>
          </button>

          {/* Scenario Selector Dropdown */}
          <div className="relative">
            <select
              value={activePreset.id}
              onChange={(e) => {
                const found = TRAFFIC_PRESETS.find((p) => p.id === e.target.value);
                if (found) onSelectPreset(found);
              }}
              className="h-8 bg-[#18191d] hover:bg-[#202127] border border-white/8 rounded-lg px-2.5 text-xs text-white/80 focus:outline-none focus:border-[#8ab4f8] transition-colors cursor-pointer pr-7 appearance-none"
            >
              {TRAFFIC_PRESETS.map((p) => (
                <option key={p.id} value={p.id} className="bg-[#18191d] text-white">
                  {p.name.split(' (')[0]}
                </option>
              ))}
            </select>
            <ChevronDown className="w-3 h-3 text-white/40 absolute right-2.5 top-2.5 pointer-events-none" />
          </div>

          {/* Filter Popover Toggle */}
          <div className="relative">
            <button
              onClick={() => setShowFilterMenu(!showFilterMenu)}
              className={`p-1.5 rounded-lg border transition-colors ${
                showFilterMenu
                  ? 'bg-white/15 text-white border-white/20'
                  : 'bg-[#18191d] text-white/60 hover:text-white border-white/8'
              }`}
              title="Filter Categories"
            >
              <Filter className="w-3.5 h-3.5" />
            </button>

            {/* Clean Filter Dropdown */}
            {showFilterMenu && (
              <div className="absolute right-0 top-10 bg-[#18191d] border border-white/12 rounded-xl p-3 shadow-2xl z-30 min-w-[200px] space-y-2 animate-in fade-in duration-100">
                <div className="text-[10px] uppercase font-semibold text-white/40 tracking-wider">
                  Filter Nodes
                </div>
                <div className="space-y-1 text-xs">
                  {(Object.keys(CATEGORY_COLORS) as DomainCategory[]).map((cat) => (
                    <button
                      key={cat}
                      onClick={() => toggleCategory(cat)}
                      className={`w-full flex items-center justify-between px-2 py-1 rounded transition-colors text-left ${
                        activeCategories[cat]
                          ? 'text-white hover:bg-white/5'
                          : 'text-white/30 hover:bg-white/5 line-through'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <span
                          className="w-2 h-2 rounded-full"
                          style={{ backgroundColor: CATEGORY_COLORS[cat] }}
                        ></span>
                        <span>{cat}</span>
                      </div>
                      <span className="text-[10px] text-white/30 font-mono">
                        {nodes.filter((n) => n.category === cat).length}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Zoom & Reset View */}
          <button
            onClick={() => setScale((s) => Math.min(2.5, s * 1.15))}
            className="p-1.5 bg-[#18191d] hover:bg-white/10 text-white/60 hover:text-white rounded-lg border border-white/8 transition-colors"
            title="Zoom In"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => setScale((s) => Math.max(0.4, s / 1.15))}
            className="p-1.5 bg-[#18191d] hover:bg-white/10 text-white/60 hover:text-white rounded-lg border border-white/8 transition-colors"
            title="Zoom Out"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={() => {
              setScale(1.0);
              setPan({ x: 0, y: 0 });
            }}
            className="p-1.5 bg-[#18191d] hover:bg-white/10 text-white/60 hover:text-white rounded-lg border border-white/8 transition-colors"
            title="Reset Canvas View"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* ── Main Viewport ── */}
      <div className="flex-1 relative overflow-hidden bg-[#0d0e11]">
        {viewMode === 'map' ? (
          /* Clean, Unobstructed Canvas Workspace */
          <div className="w-full h-full relative overflow-hidden">
            <canvas
              ref={canvasRef}
              onMouseDown={handleMouseDown}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              onClick={handleCanvasClick}
              onWheel={handleWheel}
              className="w-full h-full block cursor-grab active:cursor-grabbing"
            />

            {/* Clean, Subtle Legend Tray (Bottom Left) */}
            <div className="absolute bottom-3 left-3 bg-[#121316]/85 backdrop-blur-md border border-white/8 rounded-lg px-3 py-2 flex items-center gap-3 text-[11px] text-white/60 shadow-lg pointer-events-none select-none">
              <span className="text-[10px] uppercase font-semibold text-white/30 tracking-wider">
                Categories:
              </span>
              <div className="flex items-center gap-2.5">
                {[
                  { label: 'Primary', color: CATEGORY_COLORS.Primary },
                  { label: 'Auth', color: CATEGORY_COLORS.Auth },
                  { label: 'Trackers', color: CATEGORY_COLORS.Tracking },
                  { label: 'APIs', color: CATEGORY_COLORS.API },
                  { label: 'Analytics', color: CATEGORY_COLORS.Analytics },
                  { label: 'Services', color: CATEGORY_COLORS.Service }
                ].map((item) => (
                  <div key={item.label} className="flex items-center gap-1.5">
                    <span
                      className="w-2 h-2 rounded-full"
                      style={{ backgroundColor: item.color }}
                    ></span>
                    <span className="text-[11px]">{item.label}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Sleek Inspector Popover (Only visible when a node is clicked) */}
            {selectedNode && (
              <div className="absolute top-3 right-3 bg-[#18191d]/95 backdrop-blur-md border border-white/12 rounded-xl p-4 shadow-2xl min-w-[260px] max-w-sm space-y-3 z-30 animate-in fade-in duration-100">
                <div className="flex items-center justify-between">
                  <span
                    className={`text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded font-mono ${
                      selectedNode.isBlocked
                        ? 'bg-[#f28b82] text-black'
                        : 'text-black'
                    }`}
                    style={{ backgroundColor: selectedNode.isBlocked ? '#f28b82' : selectedNode.color }}
                  >
                    {selectedNode.isBlocked ? 'Blocked Tracker' : selectedNode.category}
                  </span>
                  <button
                    onClick={() => setSelectedNode(null)}
                    className="text-white/40 hover:text-white p-1 rounded transition-colors"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div>
                  <div className="text-xs font-mono font-bold text-white break-all">
                    {selectedNode.host}
                  </div>
                  <div className="text-[10px] text-white/40 mt-0.5">
                    {selectedNode.isPrimary
                      ? 'Primary Active Domain'
                      : selectedNode.isBlocked
                      ? 'Interception Active: All requests severed'
                      : 'Observed Network Destination'}
                  </div>
                </div>

                <div className="space-y-1.5 text-xs text-white/70 border-t border-white/8 pt-2">
                  <div className="flex justify-between">
                    <span>Observed Packets:</span>
                    <strong className="text-white font-mono">{selectedNode.count}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Shield Protection:</span>
                    <strong
                      className={`font-mono ${
                        selectedNode.isBlocked ? 'text-[#f28b82]' : 'text-[#81c995]'
                      }`}
                    >
                      {selectedNode.isBlocked ? 'Blocked (0 bytes sent)' : 'Allowed'}
                    </strong>
                  </div>
                  <div className="flex justify-between">
                    <span>Transport Protocol:</span>
                    <strong
                      className={`font-mono ${
                        selectedNode.isSecure ? 'text-[#81c995]' : 'text-[#f28b82]'
                      }`}
                    >
                      {selectedNode.isSecure ? 'HTTPS (Encrypted)' : 'HTTP (Plaintext ⚠️)'}
                    </strong>
                  </div>
                </div>

                {/* Interactive Tracker Blocking Action */}
                {!selectedNode.isPrimary && (
                  <div className="pt-2 border-t border-white/8 space-y-2">
                    <button
                      onClick={() => onToggleBlockDomain(selectedNode.host)}
                      className={`w-full py-1.5 text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-1.5 ${
                        selectedNode.isBlocked
                          ? 'bg-[#81c995] hover:bg-[#9fe0b0] text-black font-bold'
                          : 'bg-[#f28b82]/20 hover:bg-[#f28b82]/30 text-[#f28b82] border border-[#f28b82]/30'
                      }`}
                    >
                      {selectedNode.isBlocked ? (
                        <>
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Unblock Domain (Allow Traffic)</span>
                        </>
                      ) : (
                        <>
                          <Ban className="w-3.5 h-3.5" />
                          <span>Block Tracker Domain</span>
                        </>
                      )}
                    </button>
                    <button
                      onClick={() => {
                        onAuditDomain(selectedNode.host);
                        onNavigateTab('informant');
                      }}
                      className="w-full py-1.5 bg-white/5 hover:bg-white/10 text-white text-xs font-medium rounded-lg border border-white/8 transition-colors flex items-center justify-center gap-1.5"
                    >
                      <span>Audit Host Legitimacy</span>
                      <ExternalLink className="w-3 h-3" />
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        ) : (
          /* Clean Outbound Request Stream Table */
          <div className="w-full h-full p-6 overflow-y-auto space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-semibold text-white">Outbound Request Stream Telemetry</h3>
                <p className="text-xs text-white/50">
                  Real-time network requests and form submissions originating from the active session.
                </p>
              </div>
              <span className="text-xs font-mono text-white/40">
                {posts.length} streams recorded
              </span>
            </div>

            <div className="bg-[#121316] border border-white/8 rounded-xl overflow-hidden">
              <div className="divide-y divide-white/6 font-mono text-xs">
                {posts.map((post) => (
                  <div
                    key={post.id}
                    className={`p-3.5 flex items-center justify-between transition-colors ${
                      post.isBlocked
                        ? 'bg-[#f28b82]/5 text-[#f28b82]'
                        : !post.isSecure
                        ? 'bg-[#f28b82]/10 text-[#f28b82]'
                        : 'hover:bg-white/5 text-white/80'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <span
                        className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                          post.isBlocked
                            ? 'bg-[#f28b82]/20 text-[#f28b82]'
                            : post.method === 'POST'
                            ? 'bg-[#ffad66]/20 text-[#ffad66]'
                            : 'bg-white/10 text-white'
                        }`}
                      >
                        {post.isBlocked ? 'BLOCKED' : post.method}
                      </span>
                      <span className={`font-semibold ${post.isBlocked ? 'text-[#f28b82] line-through' : 'text-white'}`}>
                        {post.host}
                      </span>
                      <span className="text-white/40 truncate">{post.path}</span>
                    </div>

                    <div className="flex items-center gap-4 shrink-0 font-sans">
                      <span className="text-[11px] text-white/50">
                        {post.isBlocked ? 'Blocked by Tracker Shield (0 B)' : post.payloadType}
                      </span>

                      {post.isBlocked ? (
                        <button
                          onClick={() => onToggleBlockDomain(post.host)}
                          className="px-2.5 py-1 bg-[#81c995]/20 hover:bg-[#81c995]/30 text-[#81c995] rounded text-[11px] border border-[#81c995]/30 font-semibold transition-colors"
                        >
                          Unblock
                        </button>
                      ) : (
                        <button
                          onClick={() => onToggleBlockDomain(post.host)}
                          className="px-2.5 py-1 bg-white/5 hover:bg-[#f28b82]/20 text-white/60 hover:text-[#f28b82] rounded text-[11px] border border-white/8 transition-colors"
                        >
                          Block
                        </button>
                      )}

                      <button
                        onClick={() => {
                          onAuditDomain(post.host);
                          onNavigateTab('informant');
                        }}
                        className="px-2.5 py-1 bg-white/5 hover:bg-white/10 text-white rounded text-[11px] border border-white/8 transition-colors"
                      >
                        Audit
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
