import React from 'react';
import { AlertOctagon, KeyRound, ShieldAlert, X } from 'lucide-react';
import { WindowsToast } from '../types';

interface WindowsActionCenterToastProps {
  toasts: WindowsToast[];
  onDismiss: (id: string) => void;
  onAction?: (toast: WindowsToast) => void;
}

export const WindowsActionCenterToast: React.FC<WindowsActionCenterToastProps> = ({
  toasts,
  onDismiss,
  onAction
}) => {
  if (toasts.length === 0) return null;

  return (
    <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 max-w-sm w-full pointer-events-none">
      {toasts.map((toast) => {
        const isThreat = toast.type === 'threat';
        const isBreach = toast.type === 'breach';

        return (
          <div
            key={toast.id}
            className="pointer-events-auto bg-[#18191d]/95 backdrop-blur-xl border border-white/15 shadow-2xl rounded-xl p-3.5 text-[#f2f3f5] animate-in slide-in-from-bottom-5 duration-200"
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-2.5">
                <div
                  className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                    isThreat
                      ? 'bg-[#f28b82]/20 text-[#f28b82]'
                      : isBreach
                      ? 'bg-[#fdd663]/20 text-[#fdd663]'
                      : 'bg-[#8ab4f8]/20 text-[#8ab4f8]'
                  }`}
                >
                  {isThreat ? (
                    <ShieldAlert className="w-4 h-4" />
                  ) : isBreach ? (
                    <KeyRound className="w-4 h-4" />
                  ) : (
                    <AlertOctagon className="w-4 h-4" />
                  )}
                </div>

                <div className="space-y-0.5">
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] uppercase font-semibold text-white/50 tracking-wider">
                      Windows Security Alert
                    </span>
                    <span className="text-white/20">·</span>
                    <span className="text-[10px] text-white/40">Just now</span>
                  </div>
                  <h4 className="text-xs font-semibold text-white">{toast.title}</h4>
                  <p className="text-[11px] text-white/70 leading-normal">{toast.message}</p>
                </div>
              </div>

              <button
                onClick={() => onDismiss(toast.id)}
                className="text-white/40 hover:text-white p-1 rounded transition-colors"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>

            {onAction && (
              <div className="mt-3 pt-2.5 border-t border-white/8 flex justify-end gap-2">
                <button
                  onClick={() => onDismiss(toast.id)}
                  className="px-2.5 py-1 text-[11px] font-medium text-white/60 hover:text-white transition-colors"
                >
                  Dismiss
                </button>
                <button
                  onClick={() => {
                    onAction(toast);
                    onDismiss(toast.id);
                  }}
                  className={`px-3 py-1 text-[11px] font-semibold rounded transition-colors ${
                    isThreat
                      ? 'bg-[#f28b82] text-black hover:bg-[#ff9d94]'
                      : 'bg-[#8ab4f8] text-black hover:bg-[#aecbfa]'
                  }`}
                >
                  Review Details
                </button>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
};
