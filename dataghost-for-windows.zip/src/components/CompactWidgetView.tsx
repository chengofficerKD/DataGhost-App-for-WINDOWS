import React, { useRef, useEffect } from 'react';
import {
  ShieldCheck,
  ShieldAlert,
  KeyRound,
  Maximize2,
  RefreshCw,
  Lock,
  LockOpen,
  ArrowRight,
  ExternalLink
} from 'lucide-react';
import { LegitimacyResult, TrafficPreset, VaultSite, TrackerShieldSettings } from '../types';
import { CATEGORY_COLORS } from '../services/trafficSimulator';

interface CompactWidgetViewProps {
  onExpandToFullApp: () => void;
  currentLegitimacy: LegitimacyResult | null;
  activePreset: TrafficPreset;
  vaultSites: VaultSite[];
  onOpenGraph: () => void;
  onOpenVault: () => void;
  onAuditDomain: (domain: string) => void;
  trackerSettings?: TrackerShieldSettings;
  onOpenBlocker?: () => void;
}

export const CompactWidgetView: React.FC<CompactWidgetViewProps> = ({
  onExpandToFullApp,
  currentLegitimacy,
  activePreset,
  vaultSites,
  onOpenGraph,
  onOpenVault,
  onAuditDomain,
  trackerSettings,
  onOpenBlocker
}) => {
  const miniCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const isThreat = currentLegitimacy?.isThreat || activePreset.protocol === 'http:';
  const breachedCount = vaultSites.filter((s) => s.status === 'breached').length;
  const trackerCount = activePreset.nodes.filter((n) => n.category === 'Tracking').length;

  // Mini radar canvas draw
  useEffect(() => {
    const canvas = miniCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    canvas.width = Math.round(rect.width * dpr);
    canvas.height = Math.round(rect.height * dpr);

    ctx.save();
    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, rect.width, rect.height);

    const cx = rect.width / 2;
    const cy = rect.height / 2;
    const nodes = activePreset.nodes.slice(0, 8);

    // Connections
    nodes.slice(1).forEach((node, i) => {
      const angle = (i / (nodes.length - 1)) * Math.PI * 2;
      const dist = Math.min(rect.width * 0.35, rect.height * 0.35);
      const nx = cx + Math.cos(angle) * dist;
      const ny = cy + Math.sin(angle) * dist;

      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.lineTo(nx, ny);
      ctx.strokeStyle = CATEGORY_COLORS[node.category] || 'rgba(255, 255, 255, 0.15)';
      ctx.globalAlpha = 0.35;
      ctx.lineWidth = 1;
      ctx.stroke();

      // Node dot
      ctx.beginPath();
      ctx.arc(nx, ny, 3.5, 0, Math.PI * 2);
      ctx.fillStyle = CATEGORY_COLORS[node.category] || '#a0a2aa';
      ctx.globalAlpha = 1;
      ctx.fill();
    });

    // Center primary node
    ctx.beginPath();
    ctx.arc(cx, cy, 5.5, 0, Math.PI * 2);
    ctx.fillStyle = CATEGORY_COLORS['Primary'];
    ctx.fill();

    ctx.restore();
  }, [activePreset]);

  return (
    <div className="flex-1 flex items-center justify-center p-4 bg-[#08090b] overflow-y-auto">
      <div className="w-[320px] bg-[#121316] border border-white/10 rounded-2xl p-4 shadow-2xl space-y-3.5 select-none text-[#f2f3f5]">
        {/* Widget Top Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-5 h-5 rounded bg-[#8ab4f8]/20 flex items-center justify-center text-[#8ab4f8]">
              <ShieldCheck className="w-3.5 h-3.5" />
            </div>
            <span className="text-xs font-bold tracking-tight text-white">DataGhost Widget</span>
          </div>

          <button
            onClick={onExpandToFullApp}
            className="flex items-center gap-1 text-[11px] font-semibold text-[#8ab4f8] hover:text-white px-2 py-0.5 rounded hover:bg-white/5 transition-colors"
            title="Expand to Full Windows Application"
          >
            <span>Expand</span>
            <Maximize2 className="w-3 h-3" />
          </button>
        </div>

        {/* 1. Website Informant Card */}
        <div
          className={`p-3 rounded-xl border space-y-1.5 ${
            isThreat
              ? 'bg-[#f28b82]/10 border-[#f28b82]/30'
              : 'bg-[#18191d] border-white/8'
          }`}
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono font-semibold text-white">
                {activePreset.primaryDomain}
              </span>
            </div>
            {activePreset.protocol === 'https:' ? (
              <span className="text-[9px] px-1.5 py-0.2 rounded bg-[#81c995]/15 text-[#81c995] font-semibold flex items-center gap-1">
                <Lock className="w-2.5 h-2.5" />
                <span>HTTPS</span>
              </span>
            ) : (
              <span className="text-[9px] px-1.5 py-0.2 rounded bg-[#f28b82]/15 text-[#f28b82] font-semibold flex items-center gap-1">
                <LockOpen className="w-2.5 h-2.5" />
                <span>HTTP</span>
              </span>
            )}
          </div>

          <div className="text-xs font-semibold text-white">
            {isThreat ? '⚠️ Security Risk / Unencrypted' : '✓ No Known Threat Detected'}
          </div>

          <div className="text-[10px] text-white/50">
            Cloudflare Security DoH & ICANN RDAP verified.
          </div>
        </div>

        {/* 2. Data Detective Mini Radar */}
        <div className="bg-[#18191d] border border-white/8 rounded-xl p-3 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-semibold text-white">Data Detective Radar</span>
            <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-[#8ab4f8]/15 text-[#8ab4f8]">
              LIVE
            </span>
          </div>

          <div className="w-full h-20 bg-[#0d0e11] rounded-lg border border-white/6 overflow-hidden flex items-center justify-center relative">
            <canvas ref={miniCanvasRef} className="w-full h-full block" />
          </div>

          {/* Metrics */}
          <div className="grid grid-cols-3 gap-2 text-center pt-1 font-mono">
            <div className="p-1 bg-[#121316] rounded border border-white/6">
              <span className="text-xs font-bold text-white block">{activePreset.nodes.length}</span>
              <span className="text-[9px] text-white/40 block font-sans">Nodes</span>
            </div>
            <div className="p-1 bg-[#121316] rounded border border-white/6">
              <span className="text-xs font-bold text-[#fdd663] block">{trackerCount}</span>
              <span className="text-[9px] text-white/40 block font-sans">Trackers</span>
            </div>
            <div className="p-1 bg-[#121316] rounded border border-white/6">
              <span className="text-xs font-bold text-[#81c995] block">{activePreset.posts.length}</span>
              <span className="text-[9px] text-white/40 block font-sans">POSTs</span>
            </div>
          </div>

          <button
            onClick={onOpenGraph}
            className="w-full py-1.5 bg-[#8ab4f8] hover:bg-[#aecbfa] text-black text-xs font-semibold rounded-lg transition-colors flex items-center justify-center gap-1.5"
          >
            <span>Open Brain Map</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>

        {/* 3. Breach Vault Quick Row */}
        <div className="bg-[#18191d] border border-white/8 rounded-xl p-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <KeyRound className="w-4 h-4 text-[#8ab4f8]" />
            <div>
              <span className="text-xs font-semibold text-white block">Breach Vault</span>
              <span className="text-[10px] text-white/40">
                {breachedCount > 0 ? `${breachedCount} breached sites` : `${vaultSites.length} sites safe`}
              </span>
            </div>
          </div>

          <button
            onClick={onOpenVault}
            className="px-2.5 py-1 text-xs font-medium bg-white/10 hover:bg-white/15 text-white rounded transition-colors"
          >
            Inspect
          </button>
        </div>

        {/* 4. Tracker Shield Quick Row */}
        <div className="bg-[#18191d] border border-white/8 rounded-xl p-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-[#81c995]" />
            <div>
              <span className="text-xs font-semibold text-white block">Tracker Shield</span>
              <span className="text-[10px] text-white/40">
                {trackerSettings?.enabled ? `${trackerSettings.totalBlockedCount} blocked` : 'Protection paused'}
              </span>
            </div>
          </div>

          {onOpenBlocker && (
            <button
              onClick={onOpenBlocker}
              className="px-2.5 py-1 text-xs font-semibold bg-[#81c995]/20 hover:bg-[#81c995]/30 text-[#81c995] rounded border border-[#81c995]/30 transition-colors"
            >
              Rules
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
