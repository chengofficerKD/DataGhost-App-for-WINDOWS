import React, { useState } from 'react';
import {
  Shield,
  ShieldAlert,
  ShieldCheck,
  CheckCircle2,
  Plus,
  Trash2,
  ExternalLink,
  Flame,
  Zap,
  Info,
  Sliders,
  Radio,
  Lock,
  Layers,
  Search
} from 'lucide-react';
import { TrackerShieldSettings } from '../types';
import { formatDataSaved } from '../services/trackerBlockerService';

interface TrackerBlockerViewProps {
  settings: TrackerShieldSettings;
  onUpdateSettings: (newSettings: TrackerShieldSettings) => void;
  onNavigateTab: (tab: 'dashboard' | 'informant' | 'detective' | 'vault' | 'inspector' | 'guide' | 'blocker') => void;
}

export const TrackerBlockerView: React.FC<TrackerBlockerViewProps> = ({
  settings,
  onUpdateSettings,
  onNavigateTab
}) => {
  const [newDomainInput, setNewDomainInput] = useState('');
  const [activeTabMode, setActiveTabMode] = useState<'blocked' | 'whitelisted'>('blocked');
  const [feedback, setFeedback] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');

  const toggleShield = () => {
    const updated: TrackerShieldSettings = {
      ...settings,
      enabled: !settings.enabled
    };
    onUpdateSettings(updated);
    setFeedback(`Tracker Shield ${updated.enabled ? 'activated' : 'paused'}.`);
    setTimeout(() => setFeedback(null), 3000);
  };

  const setMode = (mode: 'balanced' | 'strict') => {
    const updated: TrackerShieldSettings = {
      ...settings,
      mode
    };
    onUpdateSettings(updated);
  };

  const handleAddDomain = (e: React.FormEvent) => {
    e.preventDefault();
    const domain = newDomainInput.trim().toLowerCase().replace(/^https?:\/\//i, '').split('/')[0];
    if (!domain || !domain.includes('.')) {
      setFeedback('Enter a valid domain name, e.g. "tracking-beacon.com"');
      setTimeout(() => setFeedback(null), 3000);
      return;
    }

    if (activeTabMode === 'blocked') {
      if (settings.blockedDomains.includes(domain)) {
        setFeedback(`"${domain}" is already blocked.`);
        setTimeout(() => setFeedback(null), 3000);
        return;
      }
      const updated: TrackerShieldSettings = {
        ...settings,
        blockedDomains: [domain, ...settings.blockedDomains],
        whitelistedDomains: settings.whitelistedDomains.filter((d) => d !== domain)
      };
      onUpdateSettings(updated);
      setNewDomainInput('');
      setFeedback(`Added "${domain}" to blocked trackers list.`);
    } else {
      if (settings.whitelistedDomains.includes(domain)) {
        setFeedback(`"${domain}" is already whitelisted.`);
        setTimeout(() => setFeedback(null), 3000);
        return;
      }
      const updated: TrackerShieldSettings = {
        ...settings,
        whitelistedDomains: [domain, ...settings.whitelistedDomains],
        blockedDomains: settings.blockedDomains.filter((d) => d !== domain)
      };
      onUpdateSettings(updated);
      setNewDomainInput('');
      setFeedback(`Added "${domain}" to allowed whitelist.`);
    }

    setTimeout(() => setFeedback(null), 3500);
  };

  const removeDomain = (domain: string, isWhitelist: boolean) => {
    if (isWhitelist) {
      onUpdateSettings({
        ...settings,
        whitelistedDomains: settings.whitelistedDomains.filter((d) => d !== domain)
      });
    } else {
      onUpdateSettings({
        ...settings,
        blockedDomains: settings.blockedDomains.filter((d) => d !== domain)
      });
    }
  };

  const displayDomains = activeTabMode === 'blocked' ? settings.blockedDomains : settings.whitelistedDomains;
  const filteredDomains = displayDomains.filter((d) =>
    searchTerm ? d.toLowerCase().includes(searchTerm.toLowerCase()) : true
  );

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-[#0d0e11] text-[#f2f3f5]">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="text-xs uppercase tracking-wider text-[#81c995] font-semibold">
              Windows Privacy Shield
            </span>
            <span className="text-white/20">·</span>
            <span className="text-xs text-white/50">Real-time Tracker Interceptor</span>
          </div>
          <h2 className="text-xl font-bold tracking-tight text-white">Tracker Blocker & Privacy Firewall</h2>
          <p className="text-xs text-white/60">
            Automatically intercepts third-party tracking pixels, advertising beacons, and telemetry streams
            before they transmit device fingerprints.
          </p>
        </div>

        {/* Master Shield Toggle */}
        <div className="flex items-center gap-3">
          <button
            onClick={toggleShield}
            className={`px-4 py-2 text-xs font-semibold rounded-lg flex items-center gap-2 transition-all shadow-md ${
              settings.enabled
                ? 'bg-[#81c995] hover:bg-[#9fe0b0] text-black font-bold'
                : 'bg-white/10 hover:bg-white/15 text-white/70'
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
            <span>{settings.enabled ? 'Tracker Shield: ACTIVE' : 'Tracker Shield: PAUSED'}</span>
          </button>
        </div>
      </div>

      {feedback && (
        <div className="p-3 bg-[#8ab4f8]/10 border border-[#8ab4f8]/25 rounded-lg text-xs text-[#8ab4f8] flex items-center gap-2 font-mono">
          <Info className="w-4 h-4 shrink-0" />
          <span>{feedback}</span>
        </div>
      )}

      {/* Metrics Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <div className="bg-[#121316] border border-white/8 rounded-xl p-3.5 space-y-1">
          <div className="flex items-center justify-between text-white/50 text-xs">
            <span>Trackers Blocked</span>
            <ShieldAlert className="w-4 h-4 text-[#81c995]" />
          </div>
          <div className="text-2xl font-bold font-mono text-white tabular-nums">
            {settings.totalBlockedCount}
          </div>
          <div className="text-[11px] text-white/40">Total session interceptions</div>
        </div>

        <div className="bg-[#121316] border border-white/8 rounded-xl p-3.5 space-y-1">
          <div className="flex items-center justify-between text-white/50 text-xs">
            <span>Data Saved</span>
            <Zap className="w-4 h-4 text-[#8ab4f8]" />
          </div>
          <div className="text-2xl font-bold font-mono text-[#8ab4f8] tabular-nums">
            {formatDataSaved(settings.dataSavedBytes)}
          </div>
          <div className="text-[11px] text-white/40">Bandwidth conserved</div>
        </div>

        <div className="bg-[#121316] border border-white/8 rounded-xl p-3.5 space-y-1">
          <div className="flex items-center justify-between text-white/50 text-xs">
            <span>Filter List Rules</span>
            <Layers className="w-4 h-4 text-[#ffad66]" />
          </div>
          <div className="text-2xl font-bold font-mono text-white tabular-nums">14,280+</div>
          <div className="text-[11px] text-white/40">EasyList Privacy & AdGuard</div>
        </div>

        <div className="bg-[#121316] border border-white/8 rounded-xl p-3.5 space-y-1">
          <div className="flex items-center justify-between text-white/50 text-xs">
            <span>Page Speed Boost</span>
            <Flame className="w-4 h-4 text-[#fdd663]" />
          </div>
          <div className="text-2xl font-bold font-mono text-[#fdd663] tabular-nums">~140ms</div>
          <div className="text-[11px] text-white/40">Average latency saved</div>
        </div>
      </div>

      {/* Shield Protection Modes */}
      <div className="bg-[#121316] border border-white/8 rounded-xl p-5 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold text-white flex items-center gap-2">
            <Sliders className="w-4 h-4 text-[#8ab4f8]" />
            <span>Protection Profiles</span>
          </h3>
          <span className="text-xs text-white/40">Select blocking intensity for Windows browsing</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Balanced Mode */}
          <div
            onClick={() => setMode('balanced')}
            className={`p-4 rounded-xl border cursor-pointer transition-all ${
              settings.mode === 'balanced'
                ? 'bg-[#18191d] border-[#81c995] ring-1 ring-[#81c995]/50'
                : 'bg-[#121316] border-white/8 hover:border-white/20'
            }`}
          >
            <div className="flex items-center justify-between pb-1">
              <span className="text-xs font-bold text-white flex items-center gap-2">
                <span>Balanced Protection</span>
                <span className="text-[9px] px-1.5 py-0.2 rounded bg-[#81c995]/20 text-[#81c995] uppercase font-mono">
                  Recommended
                </span>
              </span>
              <input
                type="radio"
                checked={settings.mode === 'balanced'}
                onChange={() => setMode('balanced')}
                className="accent-[#81c995]"
              />
            </div>
            <p className="text-xs text-white/60 leading-relaxed mt-1">
              Blocks cross-site ad trackers, tracking cookies, social pixels (Meta, TikTok), and data brokers.
              Guarantees zero web breakage on shopping or banking sites.
            </p>
          </div>

          {/* Strict Mode */}
          <div
            onClick={() => setMode('strict')}
            className={`p-4 rounded-xl border cursor-pointer transition-all ${
              settings.mode === 'strict'
                ? 'bg-[#18191d] border-[#8ab4f8] ring-1 ring-[#8ab4f8]/50'
                : 'bg-[#121316] border-white/8 hover:border-white/20'
            }`}
          >
            <div className="flex items-center justify-between pb-1">
              <span className="text-xs font-bold text-white flex items-center gap-2">
                <span>Strict Stealth Mode</span>
                <span className="text-[9px] px-1.5 py-0.2 rounded bg-[#8ab4f8]/20 text-[#8ab4f8] uppercase font-mono">
                  Aggressive
                </span>
              </span>
              <input
                type="radio"
                checked={settings.mode === 'strict'}
                onChange={() => setMode('strict')}
                className="accent-[#8ab4f8]"
              />
            </div>
            <p className="text-xs text-white/60 leading-relaxed mt-1">
              Blocks all third-party analytics, behavioral heatmaps, telemetry pings, and embedded widgets in addition
              to advertising networks. Maximum privacy footprint.
            </p>
          </div>
        </div>
      </div>

      {/* Custom Rules Management (Block / Whitelist) */}
      <div className="bg-[#121316] border border-white/8 rounded-xl p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-semibold text-white">Custom Domain Rules</h3>
            <p className="text-xs text-white/50">
              Manage custom domains to block or whitelist across your sessions.
            </p>
          </div>

          {/* Tab Selector */}
          <div className="flex items-center p-0.5 bg-[#18191d] rounded-lg border border-white/6 text-xs">
            <button
              onClick={() => setActiveTabMode('blocked')}
              className={`px-3 py-1 rounded-md transition-colors font-medium ${
                activeTabMode === 'blocked'
                  ? 'bg-[#f28b82]/20 text-[#f28b82] font-semibold'
                  : 'text-white/50 hover:text-white'
              }`}
            >
              Blocked Domains ({settings.blockedDomains.length})
            </button>
            <button
              onClick={() => setActiveTabMode('whitelisted')}
              className={`px-3 py-1 rounded-md transition-colors font-medium ${
                activeTabMode === 'whitelisted'
                  ? 'bg-[#81c995]/20 text-[#81c995] font-semibold'
                  : 'text-white/50 hover:text-white'
              }`}
            >
              Allowed Whitelist ({settings.whitelistedDomains.length})
            </button>
          </div>
        </div>

        {/* Add Rule Form */}
        <form onSubmit={handleAddDomain} className="flex gap-2">
          <div className="relative flex-1">
            <input
              type="text"
              value={newDomainInput}
              onChange={(e) => setNewDomainInput(e.target.value)}
              placeholder={
                activeTabMode === 'blocked'
                  ? 'e.g. adservice.google.com, tracking-beacon.com'
                  : 'e.g. trusted-analytics.com'
              }
              className="w-full h-10 bg-[#0d0e11] border border-white/10 rounded-lg px-3.5 text-xs text-white font-mono placeholder:text-white/30 focus:outline-none focus:border-[#8ab4f8] transition-colors"
            />
          </div>
          <button
            type="submit"
            className="h-10 px-5 bg-[#8ab4f8] hover:bg-[#aecbfa] text-black text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 shrink-0"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>{activeTabMode === 'blocked' ? 'Block Domain' : 'Allow Domain'}</span>
          </button>
        </form>

        {/* Search & Domain List */}
        <div className="space-y-2">
          {displayDomains.length > 4 && (
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-white/30 absolute left-3 top-2.5" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search domain rules..."
                className="w-full h-8 bg-[#18191d] border border-white/6 rounded-md pl-9 pr-3 text-[11px] text-white font-mono placeholder:text-white/30 focus:outline-none"
              />
            </div>
          )}

          <div className="divide-y divide-white/6 border border-white/6 rounded-lg bg-[#18191d] max-h-56 overflow-y-auto font-mono text-xs">
            {filteredDomains.length === 0 ? (
              <div className="p-4 text-center text-white/40 text-xs">
                No custom domains added to this list yet.
              </div>
            ) : (
              filteredDomains.map((dom) => (
                <div
                  key={dom}
                  className="p-2.5 px-3 flex items-center justify-between hover:bg-white/5 transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <span
                      className={`w-2 h-2 rounded-full ${
                        activeTabMode === 'blocked' ? 'bg-[#f28b82]' : 'bg-[#81c995]'
                      }`}
                    ></span>
                    <span className="text-white font-semibold">{dom}</span>
                  </div>

                  <button
                    onClick={() => removeDomain(dom, activeTabMode === 'whitelisted')}
                    className="p-1 hover:bg-white/10 rounded text-white/40 hover:text-[#f28b82] transition-colors"
                    title="Remove rule"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
