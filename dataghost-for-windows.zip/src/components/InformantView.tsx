import React, { useState } from 'react';
import {
  ShieldCheck,
  ShieldAlert,
  Search,
  Lock,
  LockOpen,
  Calendar,
  Database,
  ExternalLink,
  PlusCircle,
  Network,
  AlertTriangle,
  RefreshCw,
  CheckCircle2,
  HelpCircle,
  Check
} from 'lucide-react';
import { LegitimacyResult, VaultSite } from '../types';

interface InformantViewProps {
  currentResult: LegitimacyResult | null;
  onAuditDomain: (domain: string) => Promise<void>;
  isLoading: boolean;
  onAddToVault: (domain: string) => Promise<{ success: boolean; message: string }>;
  onOpenInDetective: (domain: string) => void;
  vaultSites: VaultSite[];
}

export const InformantView: React.FC<InformantViewProps> = ({
  currentResult,
  onAuditDomain,
  isLoading,
  onAddToVault,
  onOpenInDetective,
  vaultSites
}) => {
  const [inputUrl, setInputUrl] = useState(currentResult?.domain || '');
  const [addFeedback, setAddFeedback] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputUrl.trim()) return;
    onAuditDomain(inputUrl.trim());
  };

  const handleAdd = async () => {
    if (!currentResult?.domain) return;
    const res = await onAddToVault(currentResult.domain);
    setAddFeedback(res.message);
    setTimeout(() => setAddFeedback(null), 4000);
  };

  const isAlreadyInVault = currentResult
    ? vaultSites.some((s) => s.domain === currentResult.domain)
    : false;

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-[#0d0e11] text-[#f2f3f5]">
      {/* Header */}
      <div className="space-y-1">
        <div className="flex items-center gap-2">
          <span className="text-xs uppercase tracking-wider text-[#8ab4f8] font-semibold">
            Website Informant
          </span>
          <span className="text-white/20">·</span>
          <span className="text-xs text-white/50">Multi-Database Legitimacy Engine</span>
        </div>
        <h2 className="text-xl font-bold tracking-tight text-white">Domain Legitimacy & Threat Auditor</h2>
        <p className="text-xs text-white/60">
          Evaluates domains across Cloudflare Security DoH threat intelligence, ICANN RDAP registration history,
          TLS encryption status, and phishing heuristics.
        </p>
      </div>

      {/* Domain Input Form */}
      <div className="bg-[#121316] border border-white/8 rounded-xl p-4 space-y-3">
        <form onSubmit={handleSubmit} className="flex gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-white/40 absolute left-3.5 top-3" />
            <input
              type="text"
              value={inputUrl}
              onChange={(e) => setInputUrl(e.target.value)}
              placeholder="Enter domain or URL (e.g. xm.com, binance.com, or test phishing link)"
              className="w-full h-10 bg-[#0d0e11] border border-white/10 rounded-lg pl-10 pr-3.5 text-xs text-white font-mono placeholder:text-white/30 focus:outline-none focus:border-[#8ab4f8] transition-colors"
            />
          </div>
          <button
            type="submit"
            disabled={isLoading}
            className="h-10 px-6 bg-[#8ab4f8] hover:bg-[#aecbfa] text-black text-xs font-semibold rounded-lg transition-colors flex items-center gap-2 disabled:opacity-50"
          >
            {isLoading ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                <span>Auditing...</span>
              </>
            ) : (
              <>
                <ShieldCheck className="w-4 h-4" />
                <span>Run Audit</span>
              </>
            )}
          </button>
        </form>

        {/* Quick test pills */}
        <div className="flex flex-wrap items-center gap-2 pt-1 text-xs">
          <span className="text-white/40 text-[11px]">Test Samples:</span>
          {[
            { label: 'xm.com (Broker / Verified)', val: 'xm.com' },
            { label: 'paypal.com (Financial)', val: 'paypal.com' },
            { label: 'github.com (Developer)', val: 'github.com' },
            { label: 'paypal-security-update.xyz (Phishing)', val: 'paypal-security-update.xyz' },
            { label: 'http://insecure-login.test (HTTP)', val: 'http://insecure-login.test' }
          ].map((sample) => (
            <button
              key={sample.val}
              type="button"
              onClick={() => {
                setInputUrl(sample.val);
                onAuditDomain(sample.val);
              }}
              className="text-[11px] font-mono px-2 py-0.5 rounded bg-white/5 hover:bg-white/10 text-white/70 hover:text-white border border-white/6 transition-colors"
            >
              {sample.label}
            </button>
          ))}
        </div>
      </div>

      {/* Audit Result Display */}
      {currentResult && (
        <div className="space-y-6">
          {/* Main Verdict Card */}
          <div
            className={`border rounded-xl p-5 space-y-4 ${
              currentResult.isThreat
                ? 'bg-[#f28b82]/10 border-[#f28b82]/30'
                : 'bg-[#81c995]/10 border-[#81c995]/30'
            }`}
          >
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex items-start gap-3.5">
                <div
                  className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 ${
                    currentResult.isThreat
                      ? 'bg-[#f28b82]/20 text-[#f28b82]'
                      : 'bg-[#81c995]/20 text-[#81c995]'
                  }`}
                >
                  {currentResult.isThreat ? (
                    <ShieldAlert className="w-6 h-6" />
                  ) : (
                    <ShieldCheck className="w-6 h-6" />
                  )}
                </div>

                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-bold text-white text-base">
                      {currentResult.domain}
                    </span>
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded-full font-semibold uppercase tracking-wider ${
                        currentResult.isThreat
                          ? 'bg-[#f28b82] text-black'
                          : 'bg-[#81c995] text-black'
                      }`}
                    >
                      {currentResult.isThreat ? 'Threat Alert' : 'Verified Legit'}
                    </span>
                  </div>

                  <h3
                    className={`text-base font-bold ${
                      currentResult.isThreat ? 'text-[#f28b82]' : 'text-[#81c995]'
                    }`}
                  >
                    {currentResult.isThreat
                      ? currentResult.threatReason || 'Security Risk Detected'
                      : 'No Known Security Threats Detected'}
                  </h3>

                  <p className="text-xs text-white/70">
                    Category: <strong className="text-white">{currentResult.category}</strong>
                    {currentResult.registrationYear && ` · Active since ${currentResult.registrationYear}`}
                  </p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={handleAdd}
                  disabled={isAlreadyInVault}
                  className={`px-3 py-2 text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors ${
                    isAlreadyInVault
                      ? 'bg-white/10 text-white/40 cursor-default'
                      : 'bg-[#8ab4f8] hover:bg-[#aecbfa] text-black'
                  }`}
                >
                  {isAlreadyInVault ? <Check className="w-3.5 h-3.5" /> : <PlusCircle className="w-3.5 h-3.5" />}
                  <span>{isAlreadyInVault ? 'Monitored in Vault' : 'Add to Vault'}</span>
                </button>
                <button
                  onClick={() => onOpenInDetective(currentResult.domain)}
                  className="px-3 py-2 bg-white/10 hover:bg-white/15 text-white text-xs font-medium rounded-lg border border-white/10 transition-colors flex items-center gap-1.5"
                >
                  <Network className="w-3.5 h-3.5 text-[#8ab4f8]" />
                  <span>View in Graph</span>
                </button>
              </div>
            </div>

            {addFeedback && (
              <div className="text-xs text-[#8ab4f8] bg-[#8ab4f8]/10 p-2 rounded border border-[#8ab4f8]/20 flex items-center gap-1.5">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>{addFeedback}</span>
              </div>
            )}
          </div>

          {/* Database Breakdown Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* 1. Cloudflare Security DoH */}
            <div className="bg-[#121316] border border-white/8 rounded-xl p-4 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-white/80 flex items-center gap-1.5">
                  <Database className="w-3.5 h-3.5 text-[#8ab4f8]" />
                  <span>Cloudflare Security DoH</span>
                </span>
                <span
                  className={`text-[10px] px-1.5 py-0.5 rounded font-mono ${
                    currentResult.checks.dns === 'blocked'
                      ? 'bg-[#f28b82]/20 text-[#f28b82]'
                      : 'bg-[#81c995]/20 text-[#81c995]'
                  }`}
                >
                  {currentResult.checks.dns === 'blocked' ? 'BLOCKED' : 'CLEAN'}
                </span>
              </div>
              <p className="text-[11px] text-white/50 leading-relaxed">
                Queries Cloudflare 1.1.1.1 for Families threat filter. Catches active malware, phishing, and command-and-control servers.
              </p>
              <div className="text-[11px] text-white/70 font-mono pt-1">
                Status: {currentResult.checks.dns === 'blocked' ? '⚠️ 0.0.0.0 sinkholed' : '✓ Clean response'}
              </div>
            </div>

            {/* 2. ICANN RDAP Registration History */}
            <div className="bg-[#121316] border border-white/8 rounded-xl p-4 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-white/80 flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-[#55d6be]" />
                  <span>ICANN RDAP History</span>
                </span>
                <span className="text-[10px] px-1.5 py-0.5 rounded font-mono bg-white/10 text-white/80">
                  {currentResult.registrationYear ? `Est. ${currentResult.registrationYear}` : 'Checked'}
                </span>
              </div>
              <p className="text-[11px] text-white/50 leading-relaxed">
                Open registration database. Brand-new domains under 30 days old carry elevated phishing risk.
              </p>
              <div className="text-[11px] text-white/70 font-mono pt-1">
                {currentResult.ageDays !== undefined
                  ? `Domain Age: ~${currentResult.ageDays} days active`
                  : currentResult.registrationYear
                  ? `Registered in ${currentResult.registrationYear}`
                  : 'RDAP Record Verified'}
              </div>
            </div>

            {/* 3. Transport Security */}
            <div className="bg-[#121316] border border-white/8 rounded-xl p-4 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-white/80 flex items-center gap-1.5">
                  {currentResult.protocol === 'https:' ? (
                    <Lock className="w-3.5 h-3.5 text-[#81c995]" />
                  ) : (
                    <LockOpen className="w-3.5 h-3.5 text-[#f28b82]" />
                  )}
                  <span>Transport Protocol</span>
                </span>
                <span
                  className={`text-[10px] px-1.5 py-0.5 rounded font-mono ${
                    currentResult.protocol === 'https:'
                      ? 'bg-[#81c995]/20 text-[#81c995]'
                      : 'bg-[#f28b82]/20 text-[#f28b82]'
                  }`}
                >
                  {currentResult.protocol.toUpperCase()}
                </span>
              </div>
              <p className="text-[11px] text-white/50 leading-relaxed">
                {currentResult.protocol === 'https:'
                  ? 'Connection uses TLS encryption. Communications and data are protected from eavesdropping.'
                  : 'Insecure unencrypted HTTP. Passwords, session cookies, and personal data are sent in plaintext.'}
              </p>
              <div className="text-[11px] text-white/70 font-mono pt-1">
                {currentResult.protocol === 'https:' ? '✓ Encrypted In-Transit' : '⚠️ Plaintext Vulnerability'}
              </div>
            </div>
          </div>

          {/* Actionable Windows Guidance */}
          <div className="bg-[#121316] border border-white/8 rounded-xl p-5 space-y-3">
            <h3 className="text-xs font-semibold uppercase tracking-wider text-white/60">
              Security Recommendations for this Domain
            </h3>
            <div className="space-y-2 text-xs text-white/80">
              {currentResult.isThreat ? (
                <>
                  <div className="p-3 bg-[#f28b82]/10 border border-[#f28b82]/20 rounded-lg text-[#f28b82] space-y-1">
                    <strong>⚠️ High Risk: Do Not Enter Passwords or Credit Cards</strong>
                    <p className="text-[11px] text-white/80">
                      This site shows high threat indicators ({currentResult.threatReason}). Verify you did not click a deceptive link in an email or SMS.
                    </p>
                  </div>
                  <div className="flex items-center gap-2 text-white/70 text-[11px]">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#f28b82]"></span>
                    <span>Close the browser tab if you were asked for account credentials or verification codes.</span>
                  </div>
                </>
              ) : (
                <>
                  <div className="flex items-center gap-2 text-white/80 text-[11px]">
                    <CheckCircle2 className="w-4 h-4 text-[#81c995] shrink-0" />
                    <span>Domain holds established reputation with clean DoH checks and verified registration history.</span>
                  </div>
                  <div className="flex items-center gap-2 text-white/80 text-[11px]">
                    <CheckCircle2 className="w-4 h-4 text-[#81c995] shrink-0" />
                    <span>Safe for standard account login over verified HTTPS transport.</span>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
