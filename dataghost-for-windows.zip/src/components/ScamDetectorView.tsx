import React, { useState } from 'react';
import {
  UserX,
  PhoneCall,
  Mail,
  Coins,
  MessageSquareWarning,
  AlertTriangle,
  ShieldAlert,
  ShieldCheck,
  Search,
  Plus,
  Trash2,
  ExternalLink,
  Info,
  CheckCircle2,
  Ban,
  PhoneOff
} from 'lucide-react';
import { ScamAnalysisResult, ScamContactRecord } from '../types';
import { analyzeContactOrMessage } from '../services/scamDetectorService';

interface ScamDetectorViewProps {
  scamContacts: ScamContactRecord[];
  onAddContact: (contact: ScamContactRecord) => void;
  onRemoveContact: (id: string) => void;
}

export const ScamDetectorView: React.FC<ScamDetectorViewProps> = ({
  scamContacts,
  onAddContact,
  onRemoveContact
}) => {
  const [inputVal, setInputVal] = useState('');
  const [analysisResult, setAnalysisResult] = useState<ScamAnalysisResult | null>(null);
  const [filterType, setFilterType] = useState<string>('all');
  const [feedback, setFeedback] = useState<string | null>(null);

  const handleAnalyze = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputVal.trim()) return;
    const result = analyzeContactOrMessage(inputVal.trim());
    setAnalysisResult(result);
  };

  const handleSaveToRegistry = () => {
    if (!analysisResult) return;
    const existing = scamContacts.find((c) => c.target.toLowerCase() === analysisResult.target.toLowerCase());
    if (existing) {
      setFeedback(`"${analysisResult.target}" is already in your Scam Contacts Registry.`);
      setTimeout(() => setFeedback(null), 3000);
      return;
    }

    const newRecord: ScamContactRecord = {
      id: `scam_${Date.now()}`,
      target: analysisResult.target,
      type: analysisResult.type,
      threatLevel: analysisResult.threatLevel,
      riskScore: analysisResult.riskScore,
      scamCategory: analysisResult.category,
      carrierOrDomain: analysisResult.carrierDetails || 'Unknown Carrier',
      isVoip: analysisResult.carrierDetails?.includes('VOIP') || false,
      reportsCount: 1,
      lastReported: new Date().toISOString().split('T')[0],
      notes: analysisResult.summary,
      redFlags: analysisResult.redFlags
    };

    onAddContact(newRecord);
    setFeedback(`Saved "${analysisResult.target}" to Blocked Scam Registry.`);
    setTimeout(() => setFeedback(null), 3500);
  };

  const filteredContacts = scamContacts.filter((c) => {
    if (filterType !== 'all' && c.type !== filterType) return false;
    return true;
  });

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-[#0d0e11] text-[#f2f3f5]">
      {/* Header */}
      <div className="space-y-1">
        <div className="flex items-center gap-2">
          <span className="text-xs uppercase tracking-wider text-[#f28b82] font-semibold">
            Fraud & Social Engineering Defense
          </span>
          <span className="text-white/20">·</span>
          <span className="text-xs text-white/50">Consumer Protection Database</span>
        </div>
        <h2 className="text-xl font-bold tracking-tight text-white">Scammer Contact & Phishing Detector</h2>
        <p className="text-xs text-white/60">
          Check phone numbers, emails, SMS messages, and crypto addresses against consumer fraud databases,
          disposable VOIP registries, and social engineering patterns.
        </p>
      </div>

      {/* Input / Scanner Card */}
      <div className="bg-[#121316] border border-white/8 rounded-xl p-5 space-y-3">
        <form onSubmit={handleAnalyze} className="space-y-2">
          <span className="text-xs font-semibold text-white/80 block">
            Inspect Contact, Message, or Phone Number
          </span>
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-white/40 absolute left-3.5 top-3" />
              <input
                type="text"
                value={inputVal}
                onChange={(e) => setInputVal(e.target.value)}
                placeholder="Paste phone number (+1 800...), suspicious email, or copy-pasted SMS text"
                className="w-full h-10 bg-[#0d0e11] border border-white/10 rounded-lg pl-10 pr-3.5 text-xs text-white font-mono placeholder:text-white/30 focus:outline-none focus:border-[#8ab4f8] transition-colors"
              />
            </div>
            <button
              type="submit"
              className="h-10 px-6 bg-[#f28b82] hover:bg-[#ff9d94] text-black text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5 shrink-0"
            >
              <PhoneCall className="w-4 h-4" />
              <span>Analyze Threat</span>
            </button>
          </div>
        </form>

        {/* Quick Sample Presets */}
        <div className="flex flex-wrap items-center gap-2 pt-1 text-xs">
          <span className="text-white/40 text-[11px]">Test Samples:</span>
          {[
            { label: '+1 (800) 419-7431 (Tech Support Fraud)', val: '+1 (800) 419-7431' },
            { label: 'security-alert@microsoft-verification-live.online', val: 'security-alert@microsoft-verification-live.online' },
            { label: 'SMS: "Your USPS package is on hold, pay redelivery fee"', val: 'Your USPS package is on hold due to wrong address. Click usps-verify-hold.top to update' },
            { label: '0x71C...8491aF (Crypto Pig Butchering)', val: '0x71C8491aF1928374619283746192837461928374' }
          ].map((sample) => (
            <button
              key={sample.val}
              type="button"
              onClick={() => {
                setInputVal(sample.val);
                const res = analyzeContactOrMessage(sample.val);
                setAnalysisResult(res);
              }}
              className="text-[11px] font-mono px-2 py-0.5 rounded bg-white/5 hover:bg-white/10 text-white/70 hover:text-white border border-white/6 transition-colors"
            >
              {sample.label}
            </button>
          ))}
        </div>
      </div>

      {feedback && (
        <div className="p-3 bg-[#8ab4f8]/10 border border-[#8ab4f8]/25 rounded-lg text-xs text-[#8ab4f8] flex items-center gap-2 font-mono">
          <Info className="w-4 h-4 shrink-0" />
          <span>{feedback}</span>
        </div>
      )}

      {/* Analysis Output Result Card */}
      {analysisResult && (
        <div
          className={`border rounded-xl p-5 space-y-4 ${
            analysisResult.threatLevel === 'critical'
              ? 'bg-[#f28b82]/10 border-[#f28b82]/30'
              : analysisResult.threatLevel === 'suspicious'
              ? 'bg-[#fdd663]/10 border-[#fdd663]/30'
              : 'bg-[#81c995]/10 border-[#81c995]/30'
          }`}
        >
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="flex items-start gap-3.5">
              <div
                className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 ${
                  analysisResult.threatLevel === 'critical'
                    ? 'bg-[#f28b82]/20 text-[#f28b82]'
                    : analysisResult.threatLevel === 'suspicious'
                    ? 'bg-[#fdd663]/20 text-[#fdd663]'
                    : 'bg-[#81c995]/20 text-[#81c995]'
                }`}
              >
                {analysisResult.threatLevel === 'critical' ? (
                  <ShieldAlert className="w-6 h-6" />
                ) : analysisResult.threatLevel === 'suspicious' ? (
                  <AlertTriangle className="w-6 h-6" />
                ) : (
                  <ShieldCheck className="w-6 h-6" />
                )}
              </div>

              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="text-base font-bold font-mono text-white">
                    {analysisResult.target.length > 40
                      ? analysisResult.target.substring(0, 38) + '...'
                      : analysisResult.target}
                  </span>
                  <span
                    className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${
                      analysisResult.threatLevel === 'critical'
                        ? 'bg-[#f28b82] text-black'
                        : analysisResult.threatLevel === 'suspicious'
                        ? 'bg-[#fdd663] text-black'
                        : 'bg-[#81c995] text-black'
                    }`}
                  >
                    Risk Score: {analysisResult.riskScore}/100
                  </span>
                </div>

                <h3
                  className={`text-sm font-bold ${
                    analysisResult.threatLevel === 'critical'
                      ? 'text-[#f28b82]'
                      : analysisResult.threatLevel === 'suspicious'
                      ? 'text-[#fdd663]'
                      : 'text-[#81c995]'
                  }`}
                >
                  {analysisResult.summary}
                </h3>

                <p className="text-xs text-white/60">
                  Carrier / Source: <strong className="text-white">{analysisResult.carrierDetails}</strong>
                </p>
              </div>
            </div>

            <button
              onClick={handleSaveToRegistry}
              className="px-4 py-2 bg-[#f28b82] hover:bg-[#ff9d94] text-black text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5 shrink-0 self-start md:self-center"
            >
              <Ban className="w-3.5 h-3.5" />
              <span>Add to Blocklist</span>
            </button>
          </div>

          {/* Red Flags & Evidence */}
          <div className="bg-[#121316] border border-white/8 rounded-lg p-4 space-y-2">
            <span className="text-xs font-bold text-white uppercase tracking-wider block">
              Identified Threat Signals:
            </span>
            <ul className="space-y-1.5 text-xs text-white/80">
              {analysisResult.redFlags.map((flag, i) => (
                <li key={i} className="flex items-start gap-2">
                  <span className="text-[#f28b82] font-bold">✕</span>
                  <span>{flag}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Actionable Advice */}
          <div className="space-y-1 text-xs text-white/70">
            <span className="font-semibold text-white">Recommended Security Actions:</span>
            <ul className="list-disc pl-4 space-y-0.5 text-[11px]">
              {analysisResult.recommendations.map((rec, i) => (
                <li key={i}>{rec}</li>
              ))}
            </ul>
          </div>
        </div>
      )}

      {/* Scammer Contacts Registry Table */}
      <div className="bg-[#121316] border border-white/8 rounded-xl p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-semibold text-white">Blocked Scam Contacts & Number Registry</h3>
            <p className="text-xs text-white/50">
              Locally monitored telemarketing VOIPs, impersonation emails, and fraudulent crypto wallets.
            </p>
          </div>

          {/* Type Filter Buttons */}
          <div className="flex items-center p-0.5 bg-[#18191d] rounded-lg border border-white/6 text-xs">
            {['all', 'phone', 'email', 'crypto_address'].map((type) => (
              <button
                key={type}
                onClick={() => setFilterType(type)}
                className={`px-2.5 py-1 rounded capitalize font-medium transition-colors ${
                  filterType === type ? 'bg-white/10 text-white font-semibold' : 'text-white/50 hover:text-white'
                }`}
              >
                {type.replace('_', ' ')}
              </button>
            ))}
          </div>
        </div>

        <div className="space-y-2">
          {filteredContacts.map((contact) => (
            <div
              key={contact.id}
              className="p-3.5 bg-[#18191d] border border-white/6 rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-3"
            >
              <div className="space-y-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-mono font-bold text-[#f28b82] truncate">
                    {contact.target}
                  </span>
                  <span className="text-[10px] px-1.5 py-0.2 rounded bg-[#f28b82]/15 text-[#f28b82] font-semibold uppercase font-mono">
                    {contact.scamCategory.replace('_', ' ')}
                  </span>
                  {contact.isVoip && (
                    <span className="text-[9px] px-1.5 py-0.2 rounded bg-white/10 text-white/60 font-mono">
                      VOIP
                    </span>
                  )}
                </div>
                <p className="text-xs text-white/70">{contact.notes}</p>
                <div className="text-[10px] text-white/40 font-mono">
                  Carrier: {contact.carrierOrDomain} · Reported {contact.reportsCount} times
                </div>
              </div>

              <div className="flex items-center gap-2 shrink-0 self-end md:self-center">
                <a
                  href="https://reportfraud.ftc.gov"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-2.5 py-1.5 bg-white/5 hover:bg-white/10 text-white text-[11px] font-semibold rounded-lg border border-white/10 transition-colors flex items-center gap-1"
                >
                  <span>Report to FTC</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
                <button
                  onClick={() => onRemoveContact(contact.id)}
                  className="p-1.5 hover:bg-white/10 text-white/40 hover:text-[#f28b82] rounded transition-colors"
                  title="Remove from Blocklist"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
