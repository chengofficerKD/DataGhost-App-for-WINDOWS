import React, { useState } from 'react';
import { Activity, Lock, LockOpen, Search, Send, Filter, AlertTriangle } from 'lucide-react';
import { DomainCategory, TrafficPreset, TrackerShieldSettings } from '../types';
import { isDomainBlocked } from '../services/trackerBlockerService';

interface TrafficInspectorViewProps {
  activePreset: TrafficPreset;
  onAuditDomain: (domain: string) => void;
  onNavigateTab: (tab: 'dashboard' | 'informant' | 'detective' | 'vault' | 'inspector' | 'guide' | 'blocker') => void;
  trackerSettings?: TrackerShieldSettings;
  onToggleBlockDomain?: (domain: string) => void;
}

export const TrafficInspectorView: React.FC<TrafficInspectorViewProps> = ({
  activePreset,
  onAuditDomain,
  onNavigateTab,
  trackerSettings,
  onToggleBlockDomain
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  const filteredNodes = activePreset.nodes.filter((node) => {
    if (selectedCategory !== 'all' && node.category !== selectedCategory) return false;
    if (searchTerm && !node.host.toLowerCase().includes(searchTerm.toLowerCase())) return false;
    return true;
  });

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-[#0d0e11] text-[#f2f3f5]">
      {/* Header */}
      <div className="space-y-1">
        <div className="flex items-center gap-2">
          <span className="text-xs uppercase tracking-wider text-[#ffad66] font-semibold">
            Traffic Inspector
          </span>
          <span className="text-white/20">·</span>
          <span className="text-xs text-white/50">Outbound Packet Auditor</span>
        </div>
        <h2 className="text-xl font-bold tracking-tight text-white">Network Streams & Connection Inspector</h2>
        <p className="text-xs text-white/60">
          Deep telemetry inspection for outbound requests originating from the active session.
          Highlights unencrypted credential transmissions and commercial tracking beacons.
        </p>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-white/40 absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search hostnames or endpoints..."
            className="w-full h-10 bg-[#121316] border border-white/10 rounded-lg pl-10 pr-3.5 text-xs text-white font-mono placeholder:text-white/30 focus:outline-none focus:border-[#8ab4f8] transition-colors"
          />
        </div>

        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-white/40" />
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="h-10 bg-[#121316] border border-white/10 rounded-lg px-3 text-xs text-white focus:outline-none focus:border-[#8ab4f8]"
          >
            <option value="all">All Categories</option>
            <option value="Primary">Primary Site</option>
            <option value="Tracking">Trackers & Ads</option>
            <option value="Auth">Authentication</option>
            <option value="API">API Services</option>
            <option value="Analytics">Analytics</option>
            <option value="Essential">Essential CDN</option>
            <option value="Service">Recognized Services</option>
          </select>
        </div>
      </div>

      {/* Active Stream Table */}
      <div className="bg-[#121316] border border-white/8 rounded-xl overflow-hidden">
        <div className="p-3.5 border-b border-white/8 bg-[#18191d] flex items-center justify-between text-xs font-semibold text-white/60">
          <span>Observed Endpoints ({filteredNodes.length})</span>
          <span>Security Protocol</span>
        </div>

        <div className="divide-y divide-white/6 font-mono text-xs">
          {filteredNodes.map((node) => {
            const isBlocked = trackerSettings ? isDomainBlocked(node.host, node.category, trackerSettings) : false;

            return (
              <div
                key={node.host}
                className={`p-3.5 hover:bg-white/5 transition-colors flex items-center justify-between ${
                  isBlocked ? 'bg-[#f28b82]/5' : ''
                }`}
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className={`font-bold ${isBlocked ? 'text-[#f28b82] line-through' : 'text-white'}`}>
                      {node.host}
                    </span>
                    <span className="text-[10px] px-2 py-0.2 rounded bg-white/10 text-white/60 font-sans">
                      {node.category}
                    </span>
                    {isBlocked && (
                      <span className="text-[9px] px-1.5 py-0.2 rounded bg-[#f28b82]/20 text-[#f28b82] font-semibold uppercase">
                        Blocked
                      </span>
                    )}
                  </div>
                  <div className="text-[11px] text-white/40">
                    {isBlocked ? '0 bytes sent · Connection severed by Tracker Shield' : `${node.count} observed requests transmitted`}
                  </div>
                </div>

                <div className="flex items-center gap-3 shrink-0">
                  {node.isSecure ? (
                    <span className="flex items-center gap-1.5 text-xs text-[#81c995]">
                      <Lock className="w-3.5 h-3.5" />
                      <span>TLS Encrypted</span>
                    </span>
                  ) : (
                    <span className="flex items-center gap-1.5 text-xs text-[#f28b82] font-bold">
                      <LockOpen className="w-3.5 h-3.5" />
                      <span>Plaintext HTTP ⚠️</span>
                    </span>
                  )}

                  {onToggleBlockDomain && node.category !== 'Primary' && (
                    <button
                      onClick={() => onToggleBlockDomain(node.host)}
                      className={`px-2.5 py-1 rounded text-[11px] font-sans border transition-colors ${
                        isBlocked
                          ? 'bg-[#81c995]/20 text-[#81c995] border-[#81c995]/30 hover:bg-[#81c995]/30'
                          : 'bg-white/5 hover:bg-[#f28b82]/20 text-white/60 hover:text-[#f28b82] border-white/10'
                      }`}
                    >
                      {isBlocked ? 'Allow' : 'Block'}
                    </button>
                  )}

                  <button
                    onClick={() => {
                      onAuditDomain(node.host);
                      onNavigateTab('informant');
                    }}
                    className="px-2.5 py-1 bg-white/5 hover:bg-white/10 text-white rounded text-[11px] font-sans border border-white/10 transition-colors"
                  >
                    Audit
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
