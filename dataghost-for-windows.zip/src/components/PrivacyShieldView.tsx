import React, { useState } from 'react';
import {
  Camera,
  CameraOff,
  Mic,
  MicOff,
  MapPin,
  MapPinOff,
  ShieldCheck,
  ShieldAlert,
  AlertTriangle,
  Lock,
  Unlock,
  Activity,
  Info,
  Clock,
  Eye,
  EyeOff
} from 'lucide-react';
import { HardwarePrivacyStatus } from '../types';

interface PrivacyShieldViewProps {
  privacyStatus: HardwarePrivacyStatus;
  onUpdatePrivacyStatus: (newStatus: HardwarePrivacyStatus) => void;
}

export const PrivacyShieldView: React.FC<PrivacyShieldViewProps> = ({
  privacyStatus,
  onUpdatePrivacyStatus
}) => {
  const [feedback, setFeedback] = useState<string | null>(null);

  const toggleCamera = () => {
    const updated = {
      ...privacyStatus,
      cameraLocked: !privacyStatus.cameraLocked
    };
    onUpdatePrivacyStatus(updated);
    setFeedback(`Webcam sensor ${updated.cameraLocked ? 'HARDWARE LOCKED (Zero Access)' : 'Unlocked'}.`);
    setTimeout(() => setFeedback(null), 3000);
  };

  const toggleMic = () => {
    const updated = {
      ...privacyStatus,
      micLocked: !privacyStatus.micLocked
    };
    onUpdatePrivacyStatus(updated);
    setFeedback(`Microphone stream ${updated.micLocked ? 'MUTED & INTERCEPTED' : 'Unlocked'}.`);
    setTimeout(() => setFeedback(null), 3000);
  };

  const toggleLocation = () => {
    const updated = {
      ...privacyStatus,
      locationLocked: !privacyStatus.locationLocked
    };
    onUpdatePrivacyStatus(updated);
    setFeedback(`Windows Location telemetry ${updated.locationLocked ? 'BLOCKED' : 'Allowed'}.`);
    setTimeout(() => setFeedback(null), 3000);
  };

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-[#0d0e11] text-[#f2f3f5]">
      {/* Header */}
      <div className="space-y-1">
        <div className="flex items-center gap-2">
          <span className="text-xs uppercase tracking-wider text-[#55d6be] font-semibold">
            Hardware Eavesdropping Protection
          </span>
          <span className="text-white/20">·</span>
          <span className="text-xs text-white/50">Sensor Privacy Guardian</span>
        </div>
        <h2 className="text-xl font-bold tracking-tight text-white">Camera & Microphone Eavesdrop Shield</h2>
        <p className="text-xs text-white/60">
          Hardware-level simulation to prevent silent surveillance by spyware, remote trojans, and invasive
          background applications.
        </p>
      </div>

      {feedback && (
        <div className="p-3 bg-[#55d6be]/10 border border-[#55d6be]/25 rounded-lg text-xs text-[#55d6be] flex items-center gap-2 font-mono">
          <Info className="w-4 h-4 shrink-0" />
          <span>{feedback}</span>
        </div>
      )}

      {/* Hardware Kill Switches Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Camera Shield */}
        <div
          className={`p-5 rounded-xl border flex flex-col justify-between space-y-4 transition-all ${
            privacyStatus.cameraLocked
              ? 'bg-[#18191d] border-[#81c995] ring-1 ring-[#81c995]/30'
              : 'bg-[#121316] border-white/8 hover:border-white/15'
          }`}
        >
          <div className="flex items-center justify-between">
            <div
              className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                privacyStatus.cameraLocked ? 'bg-[#81c995]/20 text-[#81c995]' : 'bg-white/10 text-white/60'
              }`}
            >
              {privacyStatus.cameraLocked ? <CameraOff className="w-5 h-5" /> : <Camera className="w-5 h-5" />}
            </div>

            <span
              className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${
                privacyStatus.cameraLocked ? 'bg-[#81c995]/20 text-[#81c995]' : 'bg-[#f28b82]/20 text-[#f28b82]'
              }`}
            >
              {privacyStatus.cameraLocked ? 'Hardware Locked' : 'Open / Unlocked'}
            </span>
          </div>

          <div>
            <h3 className="text-sm font-bold text-white">Webcam Privacy Lock</h3>
            <p className="text-xs text-white/50 leading-relaxed mt-1">
              Disables USB and integrated camera driver feeds. Prevents silent recording by malicious processes.
            </p>
          </div>

          <button
            onClick={toggleCamera}
            className={`w-full py-2 rounded-lg text-xs font-bold transition-colors flex items-center justify-center gap-2 ${
              privacyStatus.cameraLocked
                ? 'bg-[#81c995] hover:bg-[#9fe0b0] text-black'
                : 'bg-white/10 hover:bg-white/15 text-white'
            }`}
          >
            {privacyStatus.cameraLocked ? <Lock className="w-3.5 h-3.5" /> : <Unlock className="w-3.5 h-3.5" />}
            <span>{privacyStatus.cameraLocked ? 'Camera Locked (Protected)' : 'Lock Camera Now'}</span>
          </button>
        </div>

        {/* Microphone Shield */}
        <div
          className={`p-5 rounded-xl border flex flex-col justify-between space-y-4 transition-all ${
            privacyStatus.micLocked
              ? 'bg-[#18191d] border-[#81c995] ring-1 ring-[#81c995]/30'
              : 'bg-[#121316] border-white/8 hover:border-white/15'
          }`}
        >
          <div className="flex items-center justify-between">
            <div
              className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                privacyStatus.micLocked ? 'bg-[#81c995]/20 text-[#81c995]' : 'bg-white/10 text-white/60'
              }`}
            >
              {privacyStatus.micLocked ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
            </div>

            <span
              className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${
                privacyStatus.micLocked ? 'bg-[#81c995]/20 text-[#81c995]' : 'bg-[#f28b82]/20 text-[#f28b82]'
              }`}
            >
              {privacyStatus.micLocked ? 'Microphone Muted' : 'Open / Unlocked'}
            </span>
          </div>

          <div>
            <h3 className="text-sm font-bold text-white">Audio Wiretap Defense</h3>
            <p className="text-xs text-white/50 leading-relaxed mt-1">
              Interrupts audio buffer input to ensure ambient room conversations are never captured in the background.
            </p>
          </div>

          <button
            onClick={toggleMic}
            className={`w-full py-2 rounded-lg text-xs font-bold transition-colors flex items-center justify-center gap-2 ${
              privacyStatus.micLocked
                ? 'bg-[#81c995] hover:bg-[#9fe0b0] text-black'
                : 'bg-white/10 hover:bg-white/15 text-white'
            }`}
          >
            {privacyStatus.micLocked ? <Lock className="w-3.5 h-3.5" /> : <Unlock className="w-3.5 h-3.5" />}
            <span>{privacyStatus.micLocked ? 'Microphone Muted (Protected)' : 'Lock Microphone Now'}</span>
          </button>
        </div>

        {/* Location Telemetry Shield */}
        <div
          className={`p-5 rounded-xl border flex flex-col justify-between space-y-4 transition-all ${
            privacyStatus.locationLocked
              ? 'bg-[#18191d] border-[#81c995] ring-1 ring-[#81c995]/30'
              : 'bg-[#121316] border-white/8 hover:border-white/15'
          }`}
        >
          <div className="flex items-center justify-between">
            <div
              className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                privacyStatus.locationLocked ? 'bg-[#81c995]/20 text-[#81c995]' : 'bg-white/10 text-white/60'
              }`}
            >
              {privacyStatus.locationLocked ? <MapPinOff className="w-5 h-5" /> : <MapPin className="w-5 h-5" />}
            </div>

            <span
              className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${
                privacyStatus.locationLocked ? 'bg-[#81c995]/20 text-[#81c995]' : 'bg-[#f28b82]/20 text-[#f28b82]'
              }`}
            >
              {privacyStatus.locationLocked ? 'Location Cloaked' : 'Open / Unlocked'}
            </span>
          </div>

          <div>
            <h3 className="text-sm font-bold text-white">Geolocation Cloak</h3>
            <p className="text-xs text-white/50 leading-relaxed mt-1">
              Blocks Windows Geolocation API and Wi-Fi BSSID mapping queries from exposing your exact physical location.
            </p>
          </div>

          <button
            onClick={toggleLocation}
            className={`w-full py-2 rounded-lg text-xs font-bold transition-colors flex items-center justify-center gap-2 ${
              privacyStatus.locationLocked
                ? 'bg-[#81c995] hover:bg-[#9fe0b0] text-black'
                : 'bg-white/10 hover:bg-white/15 text-white'
            }`}
          >
            {privacyStatus.locationLocked ? <Lock className="w-3.5 h-3.5" /> : <Unlock className="w-3.5 h-3.5" />}
            <span>{privacyStatus.locationLocked ? 'Location Cloaked (Protected)' : 'Lock Location Now'}</span>
          </button>
        </div>
      </div>

      {/* Sensor Access Audit Log */}
      <div className="bg-[#121316] border border-white/8 rounded-xl p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-semibold text-white">Sensor Access & Permission Audit Log</h3>
            <p className="text-xs text-white/50">
              Recent attempts by applications to access your microphone, camera, or coordinates.
            </p>
          </div>
          <span className="text-xs font-mono text-white/40">Real-time driver interceptor</span>
        </div>

        <div className="divide-y divide-white/6 border border-white/6 rounded-lg bg-[#18191d] font-mono text-xs">
          {privacyStatus.recentAppPermissions.map((perm, i) => (
            <div key={i} className="p-3 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div
                  className={`w-2 h-2 rounded-full ${
                    perm.blocked ? 'bg-[#f28b82]' : 'bg-[#81c995]'
                  }`}
                ></div>
                <div className="space-y-0.5">
                  <span className="text-white font-semibold">{perm.app}</span>
                  <div className="text-[10px] text-white/40 font-sans">
                    Requested: <strong className="text-white capitalize">{perm.type}</strong>
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <span
                  className={`text-[10px] px-2 py-0.5 rounded font-bold uppercase ${
                    perm.blocked
                      ? 'bg-[#f28b82]/20 text-[#f28b82] border border-[#f28b82]/30'
                      : 'bg-[#81c995]/20 text-[#81c995]'
                  }`}
                >
                  {perm.blocked ? 'BLOCKED' : 'ALLOWED'}
                </span>
                <span className="text-[10px] text-white/40 font-sans">
                  {Math.round((Date.now() - perm.timestamp) / 60000)}m ago
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
