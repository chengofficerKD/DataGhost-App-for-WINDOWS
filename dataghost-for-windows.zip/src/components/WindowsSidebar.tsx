import React from 'react';
import {
  LayoutDashboard,
  ShieldAlert,
  Network,
  KeyRound,
  Activity,
  BookOpen,
  CheckCircle2,
  AlertTriangle,
  UserX,
  Flame,
  Bug,
  CameraOff
} from 'lucide-react';

export type NavTab =
  | 'dashboard'
  | 'informant'
  | 'detective'
  | 'blocker'
  | 'scam'
  | 'trace'
  | 'malware'
  | 'privacy'
  | 'vault'
  | 'inspector'
  | 'guide';

interface WindowsSidebarProps {
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  breachCount: number;
  threatCount: number;
  blockedTrackerCount: number;
  malwareCount?: number;
}

export const WindowsSidebar: React.FC<WindowsSidebarProps> = ({
  activeTab,
  onSelectTab,
  breachCount,
  threatCount,
  blockedTrackerCount,
  malwareCount = 0
}) => {
  const navItems: {
    id: NavTab;
    label: string;
    icon: React.FC<{ className?: string }>;
    badge?: number | string;
    badgeColor?: string;
  }[] = [
    { id: 'dashboard', label: 'Overview', icon: LayoutDashboard },
    {
      id: 'informant',
      label: 'Website Informant',
      icon: ShieldAlert,
      badge: threatCount > 0 ? threatCount : undefined,
      badgeColor: 'bg-[#f28b82] text-black font-bold'
    },
    { id: 'detective', label: 'Data Detective', icon: Network },
    {
      id: 'blocker',
      label: 'Tracker Shield',
      icon: CheckCircle2,
      badge: blockedTrackerCount > 0 ? `${blockedTrackerCount}` : undefined,
      badgeColor: 'bg-[#81c995]/20 text-[#81c995] font-semibold border border-[#81c995]/30'
    },
    {
      id: 'scam',
      label: 'Scammer Detector',
      icon: UserX
    },
    {
      id: 'trace',
      label: 'Trace Shredder',
      icon: Flame
    },
    {
      id: 'malware',
      label: 'Malware Inspector',
      icon: Bug,
      badge: malwareCount > 0 ? malwareCount : undefined,
      badgeColor: 'bg-[#f28b82] text-black font-bold'
    },
    {
      id: 'privacy',
      label: 'Camera/Mic Shield',
      icon: CameraOff
    },
    {
      id: 'vault',
      label: 'Breach Vault',
      icon: KeyRound,
      badge: breachCount > 0 ? breachCount : undefined,
      badgeColor: 'bg-[#f28b82] text-black font-bold'
    },
    { id: 'inspector', label: 'Traffic Inspector', icon: Activity },
    { id: 'guide', label: 'Windows Guide', icon: BookOpen }
  ];

  return (
    <aside className="w-56 bg-[#121316] border-r border-white/8 flex flex-col justify-between p-2 select-none shrink-0 h-full overflow-y-auto">
      <div className="space-y-1">
        <div className="px-3 py-1.5 text-[10px] font-semibold tracking-wider uppercase text-white/40">
          Security Modules
        </div>

        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onSelectTab(item.id)}
              className={`w-full flex items-center justify-between px-3 py-1.5 rounded-lg text-xs font-medium transition-all text-left ${
                isActive
                  ? 'bg-white/10 text-white font-semibold shadow-sm'
                  : 'text-white/70 hover:bg-white/5 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-2.5 truncate">
                <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-[#8ab4f8]' : 'text-white/50'}`} />
                <span className="truncate">{item.label}</span>
              </div>
              {item.badge && (
                <span className={`text-[10px] px-1.5 py-0.2 rounded-full shrink-0 ${item.badgeColor || 'bg-white/20 text-white'}`}>
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Bottom Service Card */}
      <div className="p-2.5 bg-[#18191d] rounded-lg border border-white/6 space-y-1.5 mt-2 shrink-0">
        <div className="flex items-center gap-2 text-xs font-medium text-white/90">
          <CheckCircle2 className="w-3.5 h-3.5 text-[#81c995]" />
          <span>Active Protection</span>
        </div>
        <p className="text-[10px] text-white/50 leading-relaxed">
          Cloudflare DoH, HIBP Vault, Scam Registry & Spyware Guard active.
        </p>
      </div>
    </aside>
  );
};
