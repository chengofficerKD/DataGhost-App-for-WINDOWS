import React from 'react';
import { Shield, Sparkles, Sun, Moon, LayoutGrid, Maximize2, Minus, X, Minimize2 } from 'lucide-react';

interface WindowsTitleBarProps {
  isDarkMode: boolean;
  onToggleDarkMode: () => void;
  isWidgetMode: boolean;
  onToggleWidgetMode: () => void;
  isMaximized: boolean;
  onToggleMaximize: () => void;
  activeTab: string;
}

export const WindowsTitleBar: React.FC<WindowsTitleBarProps> = ({
  isDarkMode,
  onToggleDarkMode,
  isWidgetMode,
  onToggleWidgetMode,
  isMaximized,
  onToggleMaximize,
  activeTab
}) => {
  return (
    <header className="h-10 w-full bg-[#121316] text-[#a0a2aa] border-b border-white/8 flex items-center justify-between px-3 select-none shrink-0 z-50">
      {/* Left: App Identity */}
      <div className="flex items-center gap-2.5">
        <div className="w-5 h-5 rounded-md bg-[#8ab4f8]/15 flex items-center justify-center text-[#8ab4f8]">
          <Shield className="w-3.5 h-3.5 stroke-[2.2]" />
        </div>
        <div className="flex items-center gap-2 text-xs font-semibold text-[#f2f3f5] tracking-tight">
          <span>DataGhost</span>
          <span className="text-[10px] font-normal text-white/40 hidden sm:inline">Desktop Suite</span>
        </div>
        <span className="text-white/20 text-xs hidden sm:inline">|</span>
        <div className="hidden md:flex items-center gap-1.5 text-[11px] text-[#81c995] font-medium bg-[#81c995]/10 px-2 py-0.5 rounded-full border border-[#81c995]/20">
          <span className="w-1.5 h-1.5 rounded-full bg-[#81c995] animate-pulse"></span>
          <span>Shield Active</span>
        </div>
      </div>

      {/* Center: Contextual View Indicator */}
      <div className="hidden lg:flex items-center text-xs text-white/50 font-medium">
        <span>Windows Protection Engine</span>
        <span className="mx-2 text-white/20">·</span>
        <span className="text-white/80 capitalize">{activeTab.replace('_', ' ')}</span>
      </div>

      {/* Right: Quick Controls & Windows Window Controls */}
      <div className="flex items-center gap-1">
        {/* Toggle Widget / Full App */}
        <button
          onClick={onToggleWidgetMode}
          title={isWidgetMode ? 'Switch to Full Desktop Suite' : 'Switch to Compact Windows Widget'}
          className={`flex items-center gap-1.5 px-2 py-1 text-[11px] font-medium rounded transition-colors ${
            isWidgetMode
              ? 'bg-[#8ab4f8]/20 text-[#8ab4f8] border border-[#8ab4f8]/30'
              : 'hover:bg-white/5 text-white/70 hover:text-white'
          }`}
        >
          <LayoutGrid className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">{isWidgetMode ? 'Desktop View' : 'Widget View'}</span>
        </button>

        {/* Theme Toggle */}
        <button
          onClick={onToggleDarkMode}
          title={isDarkMode ? 'Switch to Light Theme' : 'Switch to Dark Theme'}
          className="p-1.5 hover:bg-white/5 rounded text-white/60 hover:text-white transition-colors"
        >
          {isDarkMode ? <Sun className="w-3.5 h-3.5" /> : <Moon className="w-3.5 h-3.5" />}
        </button>

        <div className="h-4 w-[1px] bg-white/10 mx-1"></div>

        {/* Windows Window Buttons */}
        <button
          onClick={() => {}}
          title="Minimize"
          className="w-8 h-8 flex items-center justify-center hover:bg-white/10 text-white/60 hover:text-white transition-colors"
        >
          <Minus className="w-3.5 h-3.5" />
        </button>
        <button
          onClick={onToggleMaximize}
          title={isMaximized ? 'Restore' : 'Maximize'}
          className="w-8 h-8 flex items-center justify-center hover:bg-white/10 text-white/60 hover:text-white transition-colors"
        >
          {isMaximized ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
        </button>
        <button
          onClick={() => {}}
          title="Close"
          className="w-8 h-8 flex items-center justify-center hover:bg-[#e81123] text-white/60 hover:text-white transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
};
