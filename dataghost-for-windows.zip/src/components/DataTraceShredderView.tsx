import React, { useState } from 'react';
import {
  FileText,
  Flame,
  Trash2,
  Copy,
  Check,
  Send,
  Lock,
  LockOpen,
  ShieldAlert,
  ShieldCheck,
  AlertOctagon,
  RefreshCw,
  Plus,
  ExternalLink,
  Info
} from 'lucide-react';
import { DataTraceItem, ErasureRequestTemplate } from '../types';
import { generateErasureRequest, simulateSystemTracePurge } from '../services/traceEraserService';

interface DataTraceShredderViewProps {
  traces: DataTraceItem[];
  onAddTrace: (trace: DataTraceItem) => void;
  onRemoveTrace: (id: string) => void;
  onUpdateTraceStatus: (id: string, status: DataTraceItem['erasureStatus']) => void;
}

export const DataTraceShredderView: React.FC<DataTraceShredderViewProps> = ({
  traces,
  onAddTrace,
  onRemoveTrace,
  onUpdateTraceStatus
}) => {
  const [selectedTrace, setSelectedTrace] = useState<DataTraceItem | null>(traces[0] || null);
  const [userFullName, setUserFullName] = useState('');
  const [userEmail, setUserEmail] = useState('');
  const [legalBasis, setLegalBasis] = useState<'GDPR_ART_17' | 'CCPA_SEC_1798'>('GDPR_ART_17');

  const [isPurging, setIsPurging] = useState(false);
  const [purgeResult, setPurgeResult] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [newDomainInput, setNewDomainInput] = useState('');

  const currentTemplate: ErasureRequestTemplate | null = selectedTrace
    ? generateErasureRequest(
        selectedTrace.domain,
        userEmail,
        userFullName,
        selectedTrace.dataTypesExposed,
        legalBasis
      )
    : null;

  const handleCopyLetter = () => {
    if (!currentTemplate) return;
    navigator.clipboard.writeText(currentTemplate.body);
    setCopied(true);
    setTimeout(() => setCopied(false), 3000);
  };

  const handleRunPurge = async () => {
    if (!selectedTrace) return;
    setIsPurging(true);
    const result = await simulateSystemTracePurge(selectedTrace.domain);
    setIsPurging(false);

    setPurgeResult(
      `Purged ${result.cookiesPurged} tracking cookies, invalidated ${result.tokensInvalidated} session tokens, and flushed Windows DNS resolver cache.`
    );
    setTimeout(() => setPurgeResult(null), 6000);
  };

  const handleAddNewDomain = (e: React.FormEvent) => {
    e.preventDefault();
    const domain = newDomainInput.trim().toLowerCase().replace(/^https?:\/\//i, '').split('/')[0];
    if (!domain || !domain.includes('.')) return;

    const newTrace: DataTraceItem = {
      id: `trace_${Date.now()}`,
      domain,
      dataTypesExposed: ['Email', 'Passwords', 'IP Address'],
      exposureDate: new Date().toISOString().split('T')[0],
      isHttpUnencrypted: false,
      erasureStatus: 'not_requested',
      notes: 'Manually logged exposure on external site.'
    };

    onAddTrace(newTrace);
    setSelectedTrace(newTrace);
    setNewDomainInput('');
  };

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-6 bg-[#0d0e11] text-[#f2f3f5]">
      {/* Header */}
      <div className="space-y-1">
        <div className="flex items-center gap-2">
          <span className="text-xs uppercase tracking-wider text-[#ffad66] font-semibold">
            Digital Footprint Shredder
          </span>
          <span className="text-white/20">·</span>
          <span className="text-xs text-white/50">Data Deletion & Trace Eraser</span>
        </div>
        <h2 className="text-xl font-bold tracking-tight text-white">
          Unsafe Site Exposure & Trace Deletion Assistant
        </h2>
        <p className="text-xs text-white/60">
          Clean residual browser session tokens, flush Windows DNS resolver caches, and generate formal
          GDPR Art. 17 / CCPA Right to Erasure legal notices to demand complete data deletion from unsafe servers.
        </p>
      </div>

      {/* Add New Exposure Record Bar */}
      <div className="bg-[#121316] border border-white/8 rounded-xl p-4 space-y-2">
        <span className="text-xs font-semibold text-white/80 block">
          Log an Unsafe Website Exposure
        </span>
        <form onSubmit={handleAddNewDomain} className="flex gap-2">
          <div className="relative flex-1">
            <input
              type="text"
              value={newDomainInput}
              onChange={(e) => setNewDomainInput(e.target.value)}
              placeholder="Enter site domain where you uploaded data or credentials (e.g. questionable-forms.com)"
              className="w-full h-10 bg-[#0d0e11] border border-white/10 rounded-lg px-3.5 text-xs text-white font-mono placeholder:text-white/30 focus:outline-none focus:border-[#8ab4f8] transition-colors"
            />
          </div>
          <button
            type="submit"
            className="h-10 px-5 bg-[#ffad66] hover:bg-[#ffbe85] text-black text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5 shrink-0"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Track Exposure</span>
          </button>
        </form>
      </div>

      {purgeResult && (
        <div className="p-3 bg-[#81c995]/15 border border-[#81c995]/30 rounded-xl text-xs text-[#81c995] flex items-center gap-2 font-mono">
          <Flame className="w-4 h-4 shrink-0 text-[#ffad66]" />
          <span>{purgeResult}</span>
        </div>
      )}

      {/* Main Split: Left Exposure List | Right Shredder & Legal Notice Generator */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Exposure List (5 cols) */}
        <div className="lg:col-span-5 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-white/60 uppercase tracking-wider">
              Exposed Websites ({traces.length})
            </span>
          </div>

          <div className="space-y-2">
            {traces.map((trace) => {
              const isSelected = selectedTrace?.id === trace.id;

              return (
                <div
                  key={trace.id}
                  onClick={() => setSelectedTrace(trace)}
                  className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-[#18191d] border-[#ffad66] ring-1 ring-[#ffad66]/40'
                      : 'bg-[#121316] border-white/8 hover:border-white/15'
                  }`}
                >
                  <div className="flex items-center justify-between pb-1">
                    <span className="text-xs font-mono font-bold text-white truncate">
                      {trace.domain}
                    </span>
                    {trace.isHttpUnencrypted ? (
                      <span className="text-[9px] px-1.5 py-0.2 rounded bg-[#f28b82]/20 text-[#f28b82] font-semibold">
                        HTTP Plaintext
                      </span>
                    ) : (
                      <span className="text-[9px] px-1.5 py-0.2 rounded bg-white/10 text-white/50 font-mono">
                        HTTPS
                      </span>
                    )}
                  </div>

                  <p className="text-[11px] text-white/60 leading-normal">{trace.notes}</p>

                  <div className="flex flex-wrap gap-1 pt-1.5">
                    {trace.dataTypesExposed.map((dt) => (
                      <span
                        key={dt}
                        className="text-[9px] px-1.5 py-0.2 rounded bg-white/5 text-white/70 border border-white/6 font-mono"
                      >
                        {dt}
                      </span>
                    ))}
                  </div>

                  <div className="flex items-center justify-between pt-2 mt-2 border-t border-white/6 text-[10px] text-white/40">
                    <span>Exposed: {trace.exposureDate}</span>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onRemoveTrace(trace.id);
                      }}
                      className="hover:text-[#f28b82] transition-colors"
                      title="Delete record"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Shredder & Formal Erasure Notice (7 cols) */}
        {selectedTrace ? (
          <div className="lg:col-span-7 space-y-4">
            {/* Action 1: Local Trace Shredder Button Card */}
            <div className="bg-[#121316] border border-white/8 rounded-xl p-5 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                    <Flame className="w-4 h-4 text-[#ffad66]" />
                    <span>Local Device Trace Shredder</span>
                  </h3>
                  <p className="text-xs text-white/50">
                    Wipes session tokens, cached form fields, tracking cookies, and flushes Windows DNS cache for{' '}
                    <strong className="text-white font-mono">{selectedTrace.domain}</strong>.
                  </p>
                </div>

                <button
                  onClick={handleRunPurge}
                  disabled={isPurging}
                  className="px-4 py-2 bg-[#ffad66] hover:bg-[#ffbe85] text-black text-xs font-bold rounded-lg transition-colors flex items-center gap-1.5 shrink-0 disabled:opacity-50"
                >
                  <Flame className={`w-3.5 h-3.5 ${isPurging ? 'animate-bounce' : ''}`} />
                  <span>{isPurging ? 'Shredding Traces...' : 'Shred Local Traces'}</span>
                </button>
              </div>
            </div>

            {/* Action 2: Formal Legal Erasure Demand Generator */}
            <div className="bg-[#121316] border border-white/8 rounded-xl p-5 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                    <FileText className="w-4 h-4 text-[#8ab4f8]" />
                    <span>Formal Data Erasure Demand Letter</span>
                  </h3>
                  <p className="text-xs text-white/50">
                    Legally binding demand under international privacy statutes requiring permanent database deletion.
                  </p>
                </div>

                {/* Legal Basis Switcher */}
                <div className="flex items-center p-0.5 bg-[#18191d] rounded-lg border border-white/6 text-xs">
                  <button
                    onClick={() => setLegalBasis('GDPR_ART_17')}
                    className={`px-2.5 py-1 rounded transition-colors font-semibold ${
                      legalBasis === 'GDPR_ART_17'
                        ? 'bg-white/10 text-white'
                        : 'text-white/40 hover:text-white'
                    }`}
                  >
                    GDPR Art. 17
                  </button>
                  <button
                    onClick={() => setLegalBasis('CCPA_SEC_1798')}
                    className={`px-2.5 py-1 rounded transition-colors font-semibold ${
                      legalBasis === 'CCPA_SEC_1798'
                        ? 'bg-white/10 text-white'
                        : 'text-white/40 hover:text-white'
                    }`}
                  >
                    CCPA § 1798
                  </button>
                </div>
              </div>

              {/* Personalization Fields */}
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="text-[10px] uppercase font-semibold text-white/50 block mb-1">
                    Your Full Name:
                  </label>
                  <input
                    type="text"
                    value={userFullName}
                    onChange={(e) => setUserFullName(e.target.value)}
                    placeholder="e.g. John Doe"
                    className="w-full h-8 bg-[#0d0e11] border border-white/10 rounded px-2.5 text-xs text-white focus:outline-none focus:border-[#8ab4f8]"
                  />
                </div>
                <div>
                  <label className="text-[10px] uppercase font-semibold text-white/50 block mb-1">
                    Your Associated Email:
                  </label>
                  <input
                    type="email"
                    value={userEmail}
                    onChange={(e) => setUserEmail(e.target.value)}
                    placeholder="e.g. user@example.com"
                    className="w-full h-8 bg-[#0d0e11] border border-white/10 rounded px-2.5 text-xs text-white focus:outline-none focus:border-[#8ab4f8]"
                  />
                </div>
              </div>

              {/* Generated Letter Preview */}
              {currentTemplate && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs text-white/60">
                    <span className="font-mono text-[11px]">To: {currentTemplate.recipientEmail}</span>
                    <button
                      onClick={handleCopyLetter}
                      className="px-2.5 py-1 bg-white/10 hover:bg-white/15 text-white rounded flex items-center gap-1.5 transition-colors font-medium text-[11px]"
                    >
                      {copied ? <Check className="w-3.5 h-3.5 text-[#81c995]" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copied ? 'Copied to Clipboard' : 'Copy Letter'}</span>
                    </button>
                  </div>

                  <pre className="p-3.5 bg-[#0d0e11] border border-white/8 rounded-lg font-mono text-[11px] text-white/80 whitespace-pre-wrap max-h-64 overflow-y-auto leading-relaxed select-text">
                    {currentTemplate.body}
                  </pre>

                  <div className="flex items-center justify-between pt-1">
                    <a
                      href={`mailto:${currentTemplate.recipientEmail}?subject=${encodeURIComponent(
                        currentTemplate.subject
                      )}&body=${encodeURIComponent(currentTemplate.body)}`}
                      className="text-xs text-[#8ab4f8] hover:underline flex items-center gap-1 font-semibold"
                    >
                      <Send className="w-3 h-3" />
                      <span>Open in Default Mail Client</span>
                    </a>

                    <button
                      onClick={() => onUpdateTraceStatus(selectedTrace.id, 'request_sent')}
                      className="text-xs px-2.5 py-1 bg-white/5 hover:bg-white/10 rounded border border-white/10 text-white/70"
                    >
                      Mark Request as Sent
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        ) : (
          <div className="lg:col-span-7 bg-[#121316] border border-white/8 rounded-xl p-8 text-center text-white/40 text-xs">
            Select an exposed site on the left to shred traces and generate legal erasure notices.
          </div>
        )}
      </div>
    </div>
  );
};
